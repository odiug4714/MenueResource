#ifndef __TOUCH_H
#define __TOUCH_H

#include "stm32f10x.h"
#include "basedefs.h"
#include "mySPI.h"


//#define Touch_SPI_Device   // SPI- oder manmual driven
                             // wegkommentieren

// Dimensions
#define cTouchHeight 320
#define cTouchWidth  240

// IO-Pins
#ifdef Touch_SPI_Device // SPI interface

#define Touch_SPI         SPI1
#define Touch_SPI_PINS    cSPI_PinPack_1

#define PORT_Touch_CS     GPIOB
#define PIN_Touch_CS      GPIO_Pin_0  // Output: Chipselect (active low)

#define PORT_Touch_Penirq GPIOA
#define PIN_Touch_Penirq  GPIO_Pin_4  // Input: IRQ Chip (active low)

#else

#define PORT_Touch_DCLK   GPIOA
#define PIN_Touch_DCLK    GPIO_Pin_5  // Output: Clockinput Chip

#define PORT_Touch_CS     GPIOB
#define PIN_Touch_CS      GPIO_Pin_0  // Output: Chipselect (active low)

#define PORT_Touch_DIN    GPIOA
#define PIN_Touch_DIN     GPIO_Pin_7  // Output:  Datainput Chip

#define PORT_Touch_DOUT   GPIOA
#define PIN_Touch_DOUT    GPIO_Pin_6  // Input:  Dataoutput Chip

#define PORT_Touch_Penirq GPIOA
#define PIN_Touch_Penirq  GPIO_Pin_4  // Input: IRQ Chip (active low)

#endif

typedef struct
{
  // SPI-Interface
  HSPI_t        TouchSPI;

  // Ports (SPI- und paralleles Interface)
  GPIO_TypeDef  *CS_Port;
  uns16      CS_Pin;
  GPIO_TypeDef  *PIRQ_Port;
  uns16      PIRQ_Pin;

  // nur f. paralleles Interface
  GPIO_TypeDef  *DIN_Port;
  uns16      DIN_Pin;
  GPIO_TypeDef  *DOUT_Port;
  uns16      DOUT_Pin;
  GPIO_TypeDef  *DCLK_Port;
  uns16      DCLK_Pin;

  // private
  uns16      Width,  // dimension
             Height,
             Cfx,    // scale factor
             Cfy,
             Cvx,    // adjustment
             Cvy,
             SimX,   // simulation koords
             SimY;
  uns8       Orientation, // screen orientation
             fsimulate;   // touch simulation active

} Touch_Handle_t;

// Orientations
#define Touch_PORTRAIT         0
#define Touch_LANDSCAPE        1
#define Touch_PORTRAIT_MIRROR  2
#define Touch_LANDSCAPE_MIRROR 3

void Touch_Init (void);
void Touch_Init_Custom (Touch_Handle_t *pTH);
void Touch_Calibrate (uns16 cfx, uns16 cvx, uns16 cfy, uns16 cvy);
void Touch_SetParams (uns8 orientation, uns16 width, uns16 height);
void Touch_Simulate (uns16 x, uns16 y);
uns8 Touch_Koords (uns16 *px, uns16 *py);

#endif





