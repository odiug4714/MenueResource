#ifndef _combase_h
#define _combase_h

#include <stdint.h>

#define cMsgBufItems 9
#define cCmdBufItems 2

#define cNoCmd      0

#define cCMDSpeed    0x80
#define cCMDHall     0x81
#define cCMDPas      0x82
#define cCMDHallSum  0x83
#define cCMDCurrI    0x84
#define cCMDUBat     0x85
#define cCMDHallRes  0x86
#define cCMDSysIdle  0x87

#define cCMDIADVal   0xa0
#define cCMDPowLevel 0xa1

#define cMaxParamCmdCnt  2

uint8_t EncodeMsg (uint8_t cmd, int32_t data, uint8_t *pMsgBuf);
uint8_t DecodeMsg (uint8_t *pcmd, int32_t *pdata, uint8_t *pMsgBuf);
uint8_t EncodeCmdMsg (uint8_t cmd, uint8_t *pMsgBuf);
uint8_t DecodeCmdMsg (uint8_t *pMsgBuf);

#endif
