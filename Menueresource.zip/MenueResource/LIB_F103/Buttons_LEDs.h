#ifndef BUTTONS_LEDS_H
#define BUTTONS_LEDS_H

#include "stm32f10x_conf.h"

#define cLEDBut_ActiveLow  0
#define cLEDBut_ActiveHigh 1

typedef struct
{
  GPIO_TypeDef *Port;
  uint16_t     Pin;
  uint8_t      active;
} HLED_t;

typedef struct
{
  GPIO_TypeDef *Port;
  uint16_t     Pin;
  uint8_t      active;
} HButton_t;

void InitLED (HLED_t *HLED, GPIO_TypeDef *Port, uint16_t Pin, uint8_t active);
void LEDAn (HLED_t *HLED);
void LEDAus (HLED_t *HLED);
void SetLED (HLED_t *HLED, uint8_t anaus);
uint8_t IsLEDAn (HLED_t *HLED);
void LEDToggle (HLED_t *HLED);
void InitButton (HButton_t *HBut, GPIO_TypeDef *Port, uint16_t Pin, uint8_t active);
uint8_t ButtonPressed (HButton_t *HBut);

#endif
