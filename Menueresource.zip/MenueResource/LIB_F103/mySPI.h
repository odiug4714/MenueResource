#ifndef mySPI_H
#define mySPI_H

#include "stm32f10x.h"

/*
        |PINPACK 1              |PINPACK 2
SPIX    |MOSI   MISO    SCK     |MOSI   MISO    SCK
        |
SPI1    |PA7    PA6     PA5     |PB5    PB4     PB3
SPI2    |PB15   PB14    PB13
*/

#define cSPI_PinPack_1    0 // Select PinPack1 from Pinout table for specific SPI
#define cSPI_PinPack_2    1 // Select PinPack2 from Pinout table for specific SPI

#define cSPI_Mode_0		  0 // Clock polarity low, clock phase 1st edge
#define cSPI_Mode_1		  1 // Clock polarity low, clock phase 2nd edge
#define cSPI_Mode_2		  2 // Clock polarity high, clock phase 1st edge
#define cSPI_Mode_3		  3 // Clock polarity high, clock phase 2nd edge

#define cSPI_Timeout      100000

#define SPI_IS_BUSY(SPIx)                 (((SPIx)->SR & (SPI_SR_TXE | SPI_SR_RXNE)) == 0 || ((SPIx)->SR & SPI_SR_BSY))
#define SPI_CHECK_ENABLED(SPIx)           if (!((SPIx)->CR1 & SPI_CR1_SPE)) { return; }
#define SPI_CHECK_ENABLED_RESP(SPIx, val) if (!((SPIx)->CR1 & SPI_CR1_SPE)) { return (val); }

typedef struct
{
  SPI_TypeDef* SPIx;
  uint8_t      pinpack,
               timeout;
} HSPI_t;

void InitSPI (HSPI_t *HSPI);
void InitSPICustom (HSPI_t *HSPI, uint8_t SPI_Mode, uint16_t DataSize,
                    uint16_t SPI_BaudRatePrescaler, uint16_t SPI_MasterSlave, uint16_t SPI_FirstBit);
uint16_t SPI_GetPrescalerFromMaxFrequency (HSPI_t *HSPI, uint32_t MAX_SPI_Frequency);
void SPI_Set8Bit (HSPI_t *HSPI);
void SPI_Set16Bit (HSPI_t *HSPI);
void SPI_SetDataSize (HSPI_t *HSPI, uint16_t DataSize);
uint8_t SPI_Send (HSPI_t *HSPI, uint8_t data);
void SPI_SendBytes (HSPI_t *HSPI, uint8_t* dataOut, uint8_t* dataIn, uint32_t num);
void SPI_WriteBytes (HSPI_t *HSPI, uint8_t* dataOut, uint32_t num);
void SPI_ReadBytes (HSPI_t *HSPI, uint8_t *dataIn, uint32_t num);
uint16_t SPI_Send16 (HSPI_t *HSPI, uint8_t data);
void SPI_SendWords (HSPI_t *HSPI, uint16_t* dataOut, uint16_t* dataIn, uint32_t num);
void SPI_WriteWords (HSPI_t *HSPI, uint16_t* dataOut, uint32_t num);
void SPI_ReadWords (HSPI_t *HSPI, uint16_t* dataIn, uint32_t num);

#endif
