/*--------------------------------------------------------------------------  */
/*  RTC controls for STM32                                                    */
/*  Copyright (c) 2009, Martin Thomas 4/2009, 3BSD-license                    */
/*  partly based on code from STMircoelectronics, Peter Dannegger, "LaLaDumm" */
/*--------------------------------------------------------------------------  */

#include "stm32f10x_conf.h"
#include "rtcF10x.h"

#define FIRSTYEAR   2000		// start year
#define FIRSTDAY    6			// 0 = Sunday

const uint8_t DaysInMonth [] = { 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

/*******************************************************************************
* Function Name  : isDST
* Description    : checks if given time is in Daylight Saving time-span.
* Input          : time-struct, must be fully populated including weekday
* Output         : none
* Return         : false: no DST ("winter"), true: in DST ("summer")
*  DST according to German standard
*  Based on code from Peter Dannegger found in the microcontroller.net forum.
*******************************************************************************/
static uint8_t isDST(const RTC_t *t)
{
	uint8_t month = t->month;

	if (month < 3 || month > 10)	// month 1, 2, 11, 12
		return 0;				// -> Winter

	uint8_t wday = t->wday;

	if (t->mday - wday >= 25 && (wday || t->hour >= 2))
	{	// after last Sunday 2:00
		if (month == 10)			// October -> Winter
			return 0;
	}
	else
	{	// before last Sunday 2:00
		if (month == 3)				// March -> Winter
			return 0;
	}
	return 1;
}

/*******************************************************************************
* Function Name  : adjustDST
* Description    : adjusts time to DST if needed
* Input          : non DST time-struct, must be fully populated including weekday
* Output         : time-stuct gets modified
* Return         : false: no DST ("winter"), true: in DST ("summer")
*  DST according to German standard
*  Based on code from Peter Dannegger found in the mikrocontroller.net forum.
*******************************************************************************/
uint8_t RTCadjustDST(RTC_t *t)
{
	if (isDST(t))
	{
        uint8_t hour = t->hour,
                day = t->mday,
                wday = t->wday,
                month = t->month;
		t->dst = 1;
		hour++;				// add one hour
		if (hour == 24)
		{	// next day
			hour = 0;
			wday++;			// next weekday
			if (wday == 7)
			{
				wday = 0;
			}
			if (day == DaysInMonth[month - 1])
			{	// next month
				day = 0;
				month++;
			}
			day++;
		}
		t->month = month;
		t->hour = hour;
		t->mday = day;
		t->wday = wday;
		return 1;
	}
	else
	{
		t->dst = 0;
		return 0;
	}
}

/*******************************************************************************
* Function Name  : counter_to_struct
* Description    : populates time-struct based on counter-value
* Input          : - counter-value (unit seconds, 0 -> 1.1.2000 00:00:00),
*                  - Pointer to time-struct
* Output         : time-struct gets populated, DST not taken into account here
* Return         : none
*  Based on code from Peter Dannegger found in the mikrocontroller.net forum.
*******************************************************************************/
void RTCcounter_to_struct (uint32_t sec, RTC_t *t)
{
	uint8_t month = 1;
    uint16_t dayofyear = 365;

	t->sec = sec % 60;
	sec /= 60;
	t->minute = sec % 60;
	sec /= 60;
	t->hour = sec % 24;
	uint16_t day = (uint16_t)(sec / 24);

	t->wday = (day + FIRSTDAY) % 7;		// weekday

	uint8_t year = FIRSTYEAR % 100;				// 0..99
	uint8_t leap400 = 4 - ((FIRSTYEAR - 1) / 100 & 3);	// 4, 3, 2, 1

	for (;;)
	{
		dayofyear = 365;
		if ((year & 3) == 0)
		{
			dayofyear = 366;		// leap year
			if (year == 0 || year == 100 || year == 200)
			{	// 100 year exception
				if (--leap400)		// 400 year exception
					dayofyear = 365;
			}
		}
		if (day < dayofyear)
			break;
		day -= dayofyear;
		year++;						// 00..136 / 99..235
	}
	t->year = year + FIRSTYEAR / 100 * 100;	// + century

	if (dayofyear & 1 && day > 58) 	// no leap year and after 28.2.
		day++;					// skip 29.2.

	for ( ; day >= DaysInMonth[month - 1]; month++)
		day -= DaysInMonth[month - 1];

	t->month = month;				// 1..12
	t->mday = day + 1;				// 1..31
}

/*******************************************************************************
* Function Name  : struct_to_counter
* Description    : calculates second-counter from populated time-struct
* Input          : Pointer to time-struct
* Output         : none
* Return         : counter-value (unit seconds, 0 -> 1.1.2000 00:00:00),
*  Based on code from "LalaDumm" found in the mikrocontroller.net forum.
*******************************************************************************/
uint32_t RTCstruct_to_counter (const RTC_t *t)
{
	uint16_t year = t->year;

	/* Calculate days of years before */
	uint32_t result = (uint32_t)year * 365;
	if (t->year >= 1) {
		result += (year + 3) / 4;
		result -= (year - 1) / 100;
		result += (year - 1) / 400;
	}

	/* Start with 2000 a.d. */
	result -= 730485UL;

	/* Make month an array index */
	uint16_t idx = t->month - 1;

	/* Loop thru each month, adding the days */
	for (uint8_t i = 0; i < idx; i++)
		result += DaysInMonth[i];

	/* Leap year? adjust February */
	if (year % 400 == 0 || (year % 4 == 0 && year % 100 != 0))
    {
	}
	else if (t->month > 1)
		result--;

	/* Add remaining days */
	result += t->mday;

	/* Convert to seconds, add all the other stuff */
	result = (result - 1) * 86400L
		+ (uint32_t)t->hour * 3600
		+ (uint32_t)t->minute * 60
		+ t->sec;

	return result;
}

/*******************************************************************************
* Function Name  : rtc_gettime
* Description    : populates structure from HW-RTC, takes DST into account
* Input          : None
* Output         : time-struct gets modified
* Return         : always true/not used
*******************************************************************************/
void RTCGetTime (RTC_t *rtc)
{
	uint32_t t = RTC_GetCounter();
	RTCcounter_to_struct(t, rtc); // get non DST time
	RTCadjustDST(rtc);
}

/*******************************************************************************
* Function Name  : my_RTC_SetCounter
* Description    : sets the hardware-counter
* Input          : new counter-value
* Output         : None
* Return         : None
*******************************************************************************/
void my_RTC_SetCounter(uint32_t cnt)
{
	/* Wait until last write operation on RTC registers has finished */
	RTC_WaitForLastTask();
	/* Change the current time */
	RTC_SetCounter(cnt);
	/* Wait until last write operation on RTC registers has finished */
	RTC_WaitForLastTask();
}

void my_RTC_SetAlarm (uint32_t cnt)
{
	/* Wait until last write operation on RTC registers has finished */
	RTC_WaitForLastTask();
	/* Change the current time */
	RTC_SetAlarm(cnt);
	/* Wait until last write operation on RTC registers has finished */
	RTC_WaitForLastTask();
}

/*******************************************************************************
* Function Name  : rtc_settime
* Description    : sets HW-RTC with values from time-struct, takes DST into
*                  account, HW-RTC always running in non-DST time
* Input          : None
* Output         : None
* Return         : not used
*******************************************************************************/
void RTCSetTime (RTC_t *rtc)
{
	RTC_t ts;

	uint32_t cnt = RTCstruct_to_counter(rtc); // non-DST counter-value
	RTCcounter_to_struct(cnt, &ts);  // normalize struct (for weekday)
	if (isDST(&ts))
	  cnt -= 60 * 60; // Subtract one hour

	PWR_BackupAccessCmd(ENABLE);
 	my_RTC_SetCounter(cnt);
 	PWR_BackupAccessCmd(DISABLE);
}

void RTCSetAlarm (RTC_t *rtc)
{
	uint32_t cnt;
	RTC_t    ts;

    rtc->hour = rtc->alhour;
    rtc->minute = rtc->almin;
    rtc->sec = rtc->alsec;

	cnt = RTCstruct_to_counter(rtc); // non-DST counter-value
	RTCcounter_to_struct(cnt, &ts);  // normalize struct (for weekday)
	if (isDST(&ts))
	  cnt -= 60 * 60; // Subtract one hour

	PWR_BackupAccessCmd(ENABLE);
	my_RTC_SetAlarm (cnt);
	PWR_BackupAccessCmd(DISABLE);
}

/*******************************************************************************
* Function Name  : rtc_init
* Description    : initializes HW RTC,
*                  sets default time-stamp if RTC has not been initialized before
* Input          : None
* Output         : None
* Return         : not used
*  Based on code from a STM RTC example in the StdPeriph-Library package
*******************************************************************************/
void InitRTC (void)
{
    NVIC_InitTypeDef aNVIC;

    if (BKP_ReadBackupRegister(BKP_DR1) != 0xA5A5)
    {
      // Backup data register value is not correct or not yet programmed
      // (when the first time the program is executed)

      RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);
      PWR_BackupAccessCmd(ENABLE);
      BKP_DeInit ();
      RCC_BackupResetCmd(ENABLE);
      RCC_BackupResetCmd(DISABLE);

      RCC_LSEConfig(RCC_LSE_ON);
      while ((RCC->BDCR & RCC_BDCR_LSERDY) != RCC_BDCR_LSERDY)
      { }

      RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);
      RTC_SetPrescaler(0x7FFF);
      RCC_RTCCLKCmd(ENABLE);
      RTC_WaitForSynchro();

      BKP_WriteBackupRegister(BKP_DR1, 0xA5A5);
    }

    RTC_ClearITPendingBit (RTC_IT_ALR);                   // Clear RTC Alarm Flag
    aNVIC.NVIC_IRQChannelPreemptionPriority = 0;
    aNVIC.NVIC_IRQChannelSubPriority = 0;
    aNVIC.NVIC_IRQChannelCmd = ENABLE;
    aNVIC.NVIC_IRQChannel = RTC_IRQn;
    NVIC_Init (&aNVIC);

    RTC_ClearITPendingBit (RTC_IT_ALR);                   // Clear RTC Alarm Flag
}
