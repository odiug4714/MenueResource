#ifndef _myUSART_H
#define _myUSART_H

#include "stm32f10x.h"
#include "basedefs.h"

/*
         |PINSPACK 1   |PINSPACK 2
         |RX    TX     |RX    TX
USART1   |PA10  PA9    |PB7   PB6
USART2   |PA3   PA2
USART3   |PB11  PB10
*/

#define cUSART_Pinpack_1 0
#define cUSART_Pinpack_2 1

void InitUsart (USART_TypeDef *USARTx, uint8_t pinpack, uint32_t Baudrate);
void UsartSend (USART_TypeDef *USARTx, char *ptext);
void UsartWrtBuf (USART_TypeDef *USARTx, uint8_t *pbuf, uint8_t len);

__weak void Usart1ReceiveCallBack (char c);
__weak void Usart2ReceiveCallBack (char c);
__weak void Usart3ReceiveCallBack (char c);

#endif
