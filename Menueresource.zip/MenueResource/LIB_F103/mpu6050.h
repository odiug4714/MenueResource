#ifndef MPU6050_H
#define MPU6050_H

#include "stm32f10x.h"
#include "myI2C.h"

// Defaults
#define	MPU6050_I2C					I2C2
#define MPU6050_I2C_PINPACK		    cI2C_PinPack_1
#define MPU6050_I2C_CLOCK			100000
#define MPU6050_I2C_ADDR			0xD0

// MPU6050 registers
#define MPU6050_I_AM				0x68  //0x70
#define MPU6050_AUX_VDDIO			0x01
#define MPU6050_SMPLRT_DIV			0x19
#define MPU6050_CONFIG				0x1A
#define MPU6050_GYRO_CONFIG			0x1B
#define MPU6050_ACCEL_CONFIG		0x1C
#define MPU6050_MOT_THR     		0x1F
#define MPU6050_MOT_DUR             0x20
#define MPU6050_ZRMOT_THR           0x21
#define MPU6050_ZRMOT_DUR           0x22
#define MPU6050_INT_PIN_CFG			0x37
#define MPU6050_INT_ENABLE			0x38
#define MPU6050_INT_STATUS			0x3A
#define MPU6050_ACCEL_XOUT_H		0x3B
#define MPU6050_ACCEL_XOUT_L		0x3C
#define MPU6050_ACCEL_YOUT_H		0x3D
#define MPU6050_ACCEL_YOUT_L		0x3E
#define MPU6050_ACCEL_ZOUT_H		0x3F
#define MPU6050_ACCEL_ZOUT_L		0x40
#define MPU6050_TEMP_OUT_H			0x41
#define MPU6050_TEMP_OUT_L			0x42
#define MPU6050_GYRO_XOUT_H			0x43
#define MPU6050_GYRO_XOUT_L			0x44
#define MPU6050_GYRO_YOUT_H			0x45
#define MPU6050_GYRO_YOUT_L			0x46
#define MPU6050_GYRO_ZOUT_H			0x47
#define MPU6050_GYRO_ZOUT_L			0x48
#define MPU6050_MOT_DETECT_STATUS	0x61
#define MPU6050_SIGNAL_PATH_RESET	0x68
#define MPU6050_MOT_DETECT_CTRL		0x69
#define MPU6050_USER_CTRL			0x6A
#define MPU6050_PWR_MGMT_1			0x6B
#define MPU6050_PWR_MGMT_2			0x6C
#define MPU6050_FIFO_COUNTH			0x72
#define MPU6050_FIFO_COUNTL			0x73
#define MPU6050_FIFO_R_W			0x74
#define MPU6050_WHO_AM_I			0x75

#define MPU6050_INTCFG_INT_LEVEL_BIT        7
#define MPU6050_INTCFG_INT_OPEN_BIT         6
#define MPU6050_INTCFG_LATCH_INT_EN_BIT     5
#define MPU6050_INTCFG_INT_RD_CLEAR_BIT     4
#define MPU6050_INTCFG_FSYNC_INT_LEVEL_BIT  3
#define MPU6050_INTCFG_FSYNC_INT_EN_BIT     2
#define MPU6050_INTCFG_I2C_BYPASS_EN_BIT    1
#define MPU6050_INTCFG_CLKOUT_EN_BIT        0

#define MPU6050_INTMODE_ACTIVEHIGH  0x00
#define MPU6050_INTMODE_ACTIVELOW   0x01

#define MPU6050_INTDRV_PUSHPULL     0x00
#define MPU6050_INTDRV_OPENDRAIN    0x01

#define MPU6050_INTLATCH_50USPULSE  0x00
#define MPU6050_INTLATCH_WAITCLEAR  0x01

#define MPU6050_INTCLEAR_STATUSREAD 0x00
#define MPU6050_INTCLEAR_ANYREAD    0x01

#define MPU6050_INTERRUPT_FF_BIT            7
#define MPU6050_INTERRUPT_MOT_BIT           6
#define MPU6050_INTERRUPT_ZMOT_BIT          5
#define MPU6050_INTERRUPT_FIFO_OFLOW_BIT    4
#define MPU6050_INTERRUPT_I2C_MST_INT_BIT   3
#define MPU6050_INTERRUPT_PLL_RDY_INT_BIT   2
#define MPU6050_INTERRUPT_DMP_INT_BIT       1
#define MPU6050_INTERRUPT_DATA_RDY_BIT      0

#define MPU6050_DLPF_BW_256         0x00
#define MPU6050_DLPF_BW_188         0x01
#define MPU6050_DLPF_BW_98          0x02
#define MPU6050_DLPF_BW_42          0x03
#define MPU6050_DLPF_BW_20          0x04
#define MPU6050_DLPF_BW_10          0x05
#define MPU6050_DLPF_BW_5           0x06

#define MPU6050_ACCEL_FS_2          0x00
#define MPU6050_ACCEL_FS_4          0x01
#define MPU6050_ACCEL_FS_8          0x02
#define MPU6050_ACCEL_FS_16         0x03

#define MPU6050_GYRO_FS_250         0x00
#define MPU6050_GYRO_FS_500         0x01
#define MPU6050_GYRO_FS_1000        0x02
#define MPU6050_GYRO_FS_2000        0x03

#define MPU6050_CFG_DLPF_CFG_BIT                2
#define MPU6050_CFG_DLPF_CFG_LENGTH             3
#define MPU6050_ACONFIG_AFS_SEL_BIT             4
#define MPU6050_ACONFIG_AFS_SEL_LENGTH          2
#define MPU6050_GCONFIG_FS_SEL_BIT              4
#define MPU6050_GCONFIG_FS_SEL_LENGTH           2

#define MPU6050_DETECT_ACCEL_ON_DELAY_BIT       5
#define MPU6050_DETECT_ACCEL_ON_DELAY_LENGTH    2
#define MPU6050_INTERRUPT_ZMOT_BIT              5
#define MPU6050_ACONFIG_ACCEL_HPF_BIT           2
#define MPU6050_ACONFIG_ACCEL_HPF_LENGTH        3

#define MPU6050_MOTION_MOT_XNEG_BIT     7
#define MPU6050_MOTION_MOT_XPOS_BIT     6
#define MPU6050_MOTION_MOT_YNEG_BIT     5
#define MPU6050_MOTION_MOT_YPOS_BIT     4
#define MPU6050_MOTION_MOT_ZNEG_BIT     3
#define MPU6050_MOTION_MOT_ZPOS_BIT     2
#define MPU6050_MOTION_MOT_ZRMOT_BIT    0

// Gyro sensitivities in 10 x �/s
#define cMPU6050_GYRO_SENS_250		1310
#define cMPU6050_GYRO_SENS_500		655
#define cMPU6050_GYRO_SENS_1000		328
#define cMPU6050_GYRO_SENS_2000		164

// Acc sensitivities in g
#define cMPU6050_ACCE_SENS_2G		16384
#define cMPU6050_ACCE_SENS_4G	    8192
#define cMPU6050_ACCE_SENS_8G		4096
#define cMPU6050_ACCE_SENS_16G		2048

#define cMPU6050_Device_0           0    // AD0 pin is set to low
#define cMPU6050_Device_1           0x02 // AD0 pin is set to high

#define cMPU6050_ResOk              0    // Everything OK
#define cMPU6050_ResNoDevice        1    // There is no device with valid slave address
#define cMPU6050_ResDeviceInvalid   2    // Connected device with address is not MPU6050

#define cMPU6050_Acc_2G             0    // Range is +- 2G
#define cMPU6050_Acc_4G             1    // Range is +- 4G
#define cMPU6050_Acc_8G             2    // Range is +- 8G
#define cMPU6050_Acc_16G            3    // Range is +- 16G

#define cMPU6050_Gyro_250s          0    // Range is +- 250 degrees/s
#define cMPU6050_Gyro_500s          1    // Range is +- 500 degrees/s
#define cMPU6050_Gyro_1000s         2    // Range is +- 1000 degrees/s
#define cMPU6050_Gyro_2000s         3    // Range is +- 2000 degrees/s

typedef struct
{
    HI2C_t  HI2C;            // I2C-Handle
	/* Private */
	int32_t Gyro_Mult,       // Gyroscope factor from raw data to degrees/s
	        Acc_Mult;        // Accelerometer factor from raw data to "g"
	/* Public */
	int16_t AccX,            // Accelerometer value X axis
	        AccY,            // Accelerometer value Y axis
	        AccZ,            // Accelerometer value Z axis
	        GyroX,           // Gyroscope value X axis
	        GyroY,           // Gyroscope value Y axis
	        GyroZ,           // Gyroscope value Z axis
	        SmartAccX,
	        SmartAccY,
	        SmartAccZ,
	        SmartGyroX,
	        SmartGyroY,
	        SmartGyroZ,
	        Delta;
	int32_t Temp;            // Temperature in degrees
} MPU6050_t;

uint8_t MPU6050_Init (MPU6050_t* MPU, uint8_t AccSense, uint8_t GyroSense);
void    MPU6050_ReadAcc (MPU6050_t* MPU);
void    MPU6050_ReadGyro (MPU6050_t* MPU);
void    MPU6050_ReadTemp (MPU6050_t* MPU);
void    MPU6050_ReadAll (MPU6050_t* MPU);
void    MPU6050_AccToG (MPU6050_t* MPU);
void    MPU6050_GyroToDeg (MPU6050_t* MPU);
uint8_t MPU6050_Sleep (MPU6050_t* MPU);
void    MPU6050_SetMotionParas (MPU6050_t* MPU, uint8_t threshold, uint8_t duration);
uint8_t MPU6050_MotionDetected (MPU6050_t* MPU);
void    MPU6050_SetSense (MPU6050_t* MPU, uint8_t AccSense, uint8_t GyroSense);


#endif
