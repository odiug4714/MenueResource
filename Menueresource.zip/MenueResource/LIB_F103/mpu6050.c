#include "mpu6050.h"

uint8_t MPU6050_Sleep (MPU6050_t* MPU)
{
  WriteI2C (&MPU->HI2C, MPU6050_PWR_MGMT_2, 0x00, cNoRepeatedStart);
  return ReadI2C (&MPU->HI2C, MPU6050_INT_STATUS, cNoRepeatedStart);
}

void MPU6050_SetMotionParas (MPU6050_t* MPU, uint8_t threshold, uint8_t duration)
{
  WriteI2C (&MPU->HI2C, MPU6050_MOT_THR, threshold, cNoRepeatedStart);
  WriteI2C (&MPU->HI2C, MPU6050_MOT_DUR, duration, cNoRepeatedStart);
}

static void MPU6050_EnableMotionInt (MPU6050_t* MPU)
{
 // frequency settings
  WriteI2C (&MPU->HI2C, MPU6050_SMPLRT_DIV, 4, cNoRepeatedStart);
  WriteBitsI2C (&MPU->HI2C, MPU6050_CONFIG, MPU6050_CFG_DLPF_CFG_BIT,
                MPU6050_CFG_DLPF_CFG_LENGTH, MPU6050_DLPF_BW_20, cNoRepeatedStart);
  // motion settings
  WriteBitsI2C (&MPU->HI2C, MPU6050_MOT_DETECT_CTRL, MPU6050_DETECT_ACCEL_ON_DELAY_BIT,
                MPU6050_DETECT_ACCEL_ON_DELAY_LENGTH, 3, cNoRepeatedStart);
  WriteBitsI2C (&MPU->HI2C, MPU6050_ACCEL_CONFIG, MPU6050_ACONFIG_ACCEL_HPF_BIT,
                MPU6050_ACONFIG_ACCEL_HPF_LENGTH, 1, cNoRepeatedStart);
  MPU6050_SetMotionParas (MPU, 10, 1);
  // interrupt settings
  WriteBitI2C (&MPU->HI2C, MPU6050_INT_PIN_CFG, MPU6050_INTCFG_INT_LEVEL_BIT,
               MPU6050_INTMODE_ACTIVEHIGH, cNoRepeatedStart);
  WriteBitI2C (&MPU->HI2C, MPU6050_INT_PIN_CFG, MPU6050_INTCFG_INT_OPEN_BIT,
               MPU6050_INTDRV_PUSHPULL, cNoRepeatedStart);
  WriteBitI2C (&MPU->HI2C, MPU6050_INT_PIN_CFG, MPU6050_INTCFG_LATCH_INT_EN_BIT,
               MPU6050_INTLATCH_50USPULSE, cNoRepeatedStart);
  WriteBitI2C (&MPU->HI2C, MPU6050_INT_ENABLE,
               MPU6050_INTERRUPT_MOT_BIT, 1, cNoRepeatedStart);             // 1 -> Motion-Int enable
}

uint8_t MPU6050_MotionDetected (MPU6050_t* MPU)
{
  uint8_t b = ReadI2C (&MPU->HI2C, MPU6050_MOT_DETECT_STATUS, cNoRepeatedStart);
  return b & ((1<<MPU6050_MOTION_MOT_XPOS_BIT) | (1<<MPU6050_MOTION_MOT_XNEG_BIT) | (1<<MPU6050_MOTION_MOT_YPOS_BIT) |
              (1<<MPU6050_MOTION_MOT_YNEG_BIT) | (1<<MPU6050_MOTION_MOT_ZPOS_BIT) | (1<<MPU6050_MOTION_MOT_ZNEG_BIT));
}

void MPU6050_SetSense (MPU6050_t* MPU, uint8_t AccSense, uint8_t GyroSense)
{
    WriteBitsI2C (&MPU->HI2C, MPU6050_ACCEL_CONFIG, MPU6050_ACONFIG_AFS_SEL_BIT,
                  MPU6050_ACONFIG_AFS_SEL_LENGTH, AccSense, cNoRepeatedStart);
    WriteBitsI2C (&MPU->HI2C, MPU6050_GYRO_CONFIG, MPU6050_GCONFIG_FS_SEL_BIT,
                  MPU6050_GCONFIG_FS_SEL_LENGTH, GyroSense, cNoRepeatedStart);
}


uint8_t MPU6050_Init (MPU6050_t* MPU, uint8_t AccSense, uint8_t GyroSense)
{
	// Initialize I2C
    InitI2C (&MPU->HI2C);
	// Wakeup MPU6050
	WriteI2C (&MPU->HI2C, MPU6050_PWR_MGMT_1, 0x00, cNoRepeatedStart);
	/*
	// Check if device is connected
	if (! IsDeviceConnectedI2C (MPU->I2Cx, MPU->Address))
    {
      return cMPU6050_ResNoDevice;
	}
	*/
	// Check who I am
	uint8_t id = ReadI2C (&MPU->HI2C, MPU6050_WHO_AM_I, cNoRepeatedStart);
    if (id != MPU6050_I_AM)
	{
		// Return error
		return cMPU6050_ResDeviceInvalid;
	}
	// Config accelerometer, gyro
	MPU6050_SetSense (MPU, AccSense, GyroSense);
	// Set sensitivities for multiplying gyro and accelerometer data
	switch (AccSense)
	{
		case cMPU6050_Acc_2G:  MPU->Acc_Mult = cMPU6050_ACCE_SENS_2G;  break;
		case cMPU6050_Acc_4G:  MPU->Acc_Mult = cMPU6050_ACCE_SENS_4G;  break;
		case cMPU6050_Acc_8G:  MPU->Acc_Mult = cMPU6050_ACCE_SENS_8G;  break;
		case cMPU6050_Acc_16G: MPU->Acc_Mult = cMPU6050_ACCE_SENS_16G;
        default:
			break;
	}
	switch (GyroSense)
	{
		case cMPU6050_Gyro_250s:  MPU->Gyro_Mult = cMPU6050_GYRO_SENS_250;  break;
		case cMPU6050_Gyro_500s:  MPU->Gyro_Mult = cMPU6050_GYRO_SENS_500;  break;
		case cMPU6050_Gyro_1000s: MPU->Gyro_Mult = cMPU6050_GYRO_SENS_1000; break;
		case cMPU6050_Gyro_2000s: MPU->Gyro_Mult = cMPU6050_GYRO_SENS_2000;
		default:
			break;
	}
	MPU6050_EnableMotionInt (MPU);

    MPU->Delta = 100;
	return cMPU6050_ResOk;
}


void MPU6050_ReadAcc (MPU6050_t* MPU)
{
	uint8_t data [6];
	// Read accelerometer data
	WriteCmdI2C (&MPU->HI2C, MPU6050_ACCEL_XOUT_H, cRepeatedStart);
	ReadBufI2C (&MPU->HI2C, data, 6);
	// Format
	MPU->AccX = data [0] << 8 | data [1];
	MPU->AccY = data [2] << 8 | data [3];
	MPU->AccZ = data [4] << 8 | data [5];
}

void MPU6050_ReadGyro (MPU6050_t* MPU)
{
	uint8_t data [6];
	// Read gyroscope data
	WriteCmdI2C (&MPU->HI2C, MPU6050_GYRO_XOUT_H, cRepeatedStart);
	ReadBufI2C (&MPU->HI2C, data, 6);
	// Format
	MPU->GyroX = data [0] << 8 | data [1];
	MPU->GyroY = data [2] << 8 | data [3];
	MPU->GyroZ = data [4] << 8 | data [5];
}

void MPU6050_ReadTemp (MPU6050_t* MPU)
{
	uint8_t data [2];
	// Read temperature
	WriteCmdI2C (&MPU->HI2C, MPU6050_TEMP_OUT_H, cRepeatedStart);
	ReadBufI2C (&MPU->HI2C, data, 2);
	// Format temperature
	int32_t temp = (data[0] << 8 | data[1]);
	MPU->Temp = (10 * temp) / 34 + 3653; // in 1/100 degees
}

void MPU6050_ReadAll (MPU6050_t* MPU)
{
	uint8_t data [14];
	// Read full raw data, 14bytes
	WriteCmdI2C (&MPU->HI2C, MPU6050_ACCEL_XOUT_H, cRepeatedStart);
	ReadBufI2C (&MPU->HI2C, data, 14);
	// Format accelerometer data
	MPU->AccX = data [0] << 8 | data [1];
	MPU->AccY = data [2] << 8 | data [3];
	MPU->AccZ = data [4] << 8 | data [5];
	// Format temperature
	int32_t temp = data [6] << 8 | data [7];
	MPU->Temp = (10 * temp) / 34 + 3653; // in 1/100 degees
	// Format gyroscope data
	MPU->GyroX = data [8] << 8 | data [9];
	MPU->GyroY = data [10] << 8 | data [11];
	MPU->GyroZ = data [12] << 8 | data [13];

	if (MPU->AccX > MPU->SmartAccX + MPU->Delta || MPU->AccX < MPU->SmartAccX - MPU->Delta)
      MPU->SmartAccX = MPU->AccX;
	if (MPU->AccY > MPU->SmartAccY + MPU->Delta || MPU->AccY < MPU->SmartAccY - MPU->Delta)
      MPU->SmartAccY = MPU->AccY;
	if (MPU->AccZ > MPU->SmartAccZ + MPU->Delta || MPU->AccZ < MPU->SmartAccZ - MPU->Delta)
      MPU->SmartAccZ = MPU->AccZ;

	if (MPU->GyroX > MPU->SmartGyroX + MPU->Delta || MPU->GyroX < MPU->SmartGyroX - MPU->Delta)
      MPU->SmartGyroX = MPU->GyroX;
	if (MPU->GyroY > MPU->SmartGyroY + MPU->Delta || MPU->GyroY < MPU->SmartGyroY - MPU->Delta)
      MPU->SmartGyroY = MPU->GyroY;
	if (MPU->GyroZ > MPU->SmartGyroZ + MPU->Delta || MPU->GyroZ < MPU->SmartGyroZ - MPU->Delta)
      MPU->SmartGyroZ = MPU->GyroZ;
}

void MPU6050_AccToG (MPU6050_t* MPU)
{
    MPU->AccX = (MPU->AccX * 100) / MPU->Acc_Mult;
    MPU->AccY = (MPU->AccY * 100) / MPU->Acc_Mult;
    MPU->AccZ = (MPU->AccZ * 100) / MPU->Acc_Mult;
}

void MPU6050_GyroToDeg (MPU6050_t* MPU)
{
    MPU->GyroX = (MPU->GyroX * 100) / MPU->Gyro_Mult;
    MPU->GyroY = (MPU->GyroY * 100) / MPU->Gyro_Mult;
    MPU->GyroZ = (MPU->GyroZ * 100) / MPU->Gyro_Mult;
}
