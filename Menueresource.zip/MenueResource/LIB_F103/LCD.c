//---------------------------------------------------------------------------------
// Displaydriver 2.4/2.8/3.2 inch TFT with ILI9341
// Autor: Guido Kahle and others
//---------------------------------------------------------------------------------
#include "stm32f10x.h"
#include "delay.h"
#include "basedefs.h"
#include "myGPIO.h"
#include "lcd.h"

// Level 1 Commands
#define LCD_RESET               0x01   // Software Reset
#define LCD_READ_DISPLAY_ID     0x04   // Read display identification information
#define LCD_RDDST               0x09   // Read Display Status
#define LCD_RDDPM               0x0A   // Read Display Power Mode
#define LCD_RDDMADCTL           0x0B   // Read Display MADCTL
#define LCD_RDDCOLMOD           0x0C   // Read Display Pixel Format
#define LCD_RDDIM               0x0D   // Read Display Image Format
#define LCD_RDDSM               0x0E   // Read Display Signal Mode
#define LCD_RDDSDR              0x0F   // Read Display Self-Diagnostic Result
#define LCD_SPLIN               0x10   // Enter Sleep Mode
#define LCD_SLEEP_OUT           0x11   // Sleep out register
#define LCD_PTLON               0x12   // Partial Mode ON
#define LCD_NORMAL_MODE_ON      0x13   // Normal Display Mode ON
#define LCD_DINVOFF             0x20   // Display Inversion OFF
#define LCD_DINVON              0x21   // Display Inversion ON
#define LCD_GAMMA               0x26   // Gamma register
#define LCD_DISPLAY_OFF         0x28   // Display off register
#define LCD_DISPLAY_ON          0x29   // Display on register
#define LCD_COLUMN_ADDR         0x2A   // Colomn address register
#define LCD_PAGE_ADDR           0x2B   // Page address register
#define LCD_GRAM                0x2C   // GRAM register
#define LCD_RGBSET              0x2D   // Color SET
#define LCD_RAMRD               0x2E   // Memory Read
#define LCD_PLTAR               0x30   // Partial Area
#define LCD_VSCRDEF             0x33   // Vertical Scrolling Definition
#define LCD_TEOFF               0x34   // Tearing Effect Line OFF
#define LCD_TEON                0x35   // Tearing Effect Line ON
#define LCD_MAC                 0x36   // Memory Access Control register
#define LCD_VSCRSADD            0x37   // Vertical Scrolling Start Address
#define LCD_IDMOFF              0x38   // Idle Mode OFF
#define LCD_IDMON               0x39   // Idle Mode ON
#define LCD_PIXEL_FORMAT        0x3A   // Pixel Format register
#define LCD_WRITE_MEM_CONTINUE  0x3C   // Write Memory Continue
#define LCD_READ_MEM_CONTINUE   0x3E   // Read Memory Continue
#define LCD_SET_TEAR_SCANLINE   0x44   // Set Tear Scanline
#define LCD_GET_SCANLINE        0x45   // Get Scanline
#define LCD_WDB                 0x51   // Write Brightness Display register
#define LCD_RDDISBV             0x52   // Read Display Brightness
#define LCD_WCD                 0x53   // Write Control Display register
#define LCD_RDCTRLD             0x54   // Read CTRL Display
#define LCD_WRCABC              0x55   // Write Content Adaptive Brightness Control
#define LCD_RDCABC              0x56   // Read Content Adaptive Brightness Control
#define LCD_WRITE_CABC          0x5E   // Write CABC Minimum Brightness
#define LCD_READ_CABC           0x5F   // Read CABC Minimum Brightness
#define LCD_READ_ID1            0xDA   // Read ID1
#define LCD_READ_ID2            0xDB   // Read ID2
#define LCD_READ_ID3            0xDC   // Read ID3

// Level 2 Commands
#define LCD_RGB_INTERFACE       0xB0   // RGB Interface Signal Control
#define LCD_FRMCTR1             0xB1   // Frame Rate Control (In Normal Mode)
#define LCD_FRMCTR2             0xB2   // Frame Rate Control (In Idle Mode)
#define LCD_FRMCTR3             0xB3   // Frame Rate Control (In Partial Mode)
#define LCD_INVTR               0xB4   // Display Inversion Control
#define LCD_BPC                 0xB5   // Blanking Porch Control register
#define LCD_DFC                 0xB6   // Display Function Control register
#define LCD_ETMOD               0xB7   // Entry Mode Set
#define LCD_BACKLIGHT1          0xB8   // Backlight Control 1
#define LCD_BACKLIGHT2          0xB9   // Backlight Control 2
#define LCD_BACKLIGHT3          0xBA   // Backlight Control 3
#define LCD_BACKLIGHT4          0xBB   // Backlight Control 4
#define LCD_BACKLIGHT5          0xBC   // Backlight Control 5
#define LCD_BACKLIGHT7          0xBE   // Backlight Control 7
#define LCD_BACKLIGHT8          0xBF   // Backlight Control 8
#define LCD_POWER1              0xC0   // Power Control 1 register
#define LCD_POWER2              0xC1   // Power Control 2 register
#define LCD_VCOM1               0xC5   // VCOM Control 1 register
#define LCD_VCOM2               0xC7   // VCOM Control 2 register
#define LCD_NVMWR               0xD0   // NV Memory Write
#define LCD_NVMPKEY             0xD1   // NV Memory Protection Key
#define LCD_RDNVM               0xD2   // NV Memory Status Read
#define LCD_READ_ID4            0xD3   // Read ID4
#define LCD_PGAMMA              0xE0   // Positive Gamma Correction register
#define LCD_NGAMMA              0xE1   // Negative Gamma Correction register
#define LCD_DGAMCTRL1           0xE2   // Digital Gamma Control 1
#define LCD_DGAMCTRL2           0xE3   // Digital Gamma Control 2
#define LCD_INTERFACE           0xF6   // Interface control register

// Extended register commands
#define LCD_POWERA              0xCB   // Power control A register
#define LCD_POWERB              0xCF   // Power control B register
#define LCD_DTCA                0xE8   // Driver timing control A
#define LCD_DTCB                0xEA   // Driver timing control B
#define LCD_POWER_SEQ           0xED   // Power on sequence register
#define LCD_3GAMMA_EN           0xF2   // 3 Gamma enable register
#define LCD_PRC                 0xF7   // Pump ratio control register

#define cTime                   30     // Delay

// Forwards
static void LCD_SendCommand (uns8 data);
static void LCD_SendData8 (uns8 data);
static void LCD_SendData16 (uns16 data);
static uns8 LCD_SetAddress (uns16 x1, uns16 y1, uns16 x2, uns16 y2);

// Globals
static LCD_Handle_t HLCD;      // LCD-Init-Handle
static LCDOptions_t LCD_Opts;  // LCD Options

// Pin controls
#define LCD_RST_SET   GPIO_SetBits (HLCD.LCD_RSTPort, HLCD.LCD_RSTPin)
#define LCD_RST_RESET GPIO_ResetBits (HLCD.LCD_RSTPort, HLCD.LCD_RSTPin)
#define LCD_CS_SET    GPIO_SetBits (HLCD.LCD_CSPort, HLCD.LCD_CSPin)
#define LCD_CS_RESET  GPIO_ResetBits (HLCD.LCD_CSPort, HLCD.LCD_CSPin)
#define LCD_DC_SET    GPIO_SetBits (HLCD.LCD_DCPort, HLCD.LCD_DCPin)
#define LCD_DC_RESET  GPIO_ResetBits (HLCD.LCD_DCPort, HLCD.LCD_DCPin)
#define LCD_RD_SET    GPIO_SetBits (HLCD.LCD_RDPort, HLCD.LCD_RDPin)
#define LCD_RD_RESET  GPIO_ResetBits (HLCD.LCDRD_Port, HLCD.LCD_RDPin)
#define LCD_WR_SET    GPIO_SetBits (HLCD.LCD_WRPort, HLCD.LCD_WRPin)
#define LCD_WR_RESET  GPIO_ResetBits (HLCD.LCD_WRPort, HLCD.LCD_WRPin)
#define LCD_BL_ON     GPIO_ResetBits (HLCD.LCD_BLPort, HLCD.LCD_BLPin)
#define LCD_BL_OFF    GPIO_SetBits (HLCD.LCD_BLPort, HLCD.LCD_BLPin)

// LDC-Init commands
static const uns8 LCD_InitCmds [] =
{
  // Power control A
  6,  LCD_POWERA, 0x39, 0x2C, 0x00, 0x34, 0x02,
  // Power control B
  4,  LCD_POWERB, 0x00, 0xC1, 0x30,
  // Driver timing control A
  4,  LCD_DTCA, 0x85, 0x00, 0x78,
  // Driver timing control B
  3,  LCD_DTCB, 0x00, 0x00,
  // Power on sequence control
  5,  LCD_POWER_SEQ, 0x64, 0x03, 0x12, 0x81,
  // Pump ratio control
  2,  LCD_PRC, 0x20,
  // Power control 1
  2,  LCD_POWER1, 0x23,
  // Power control 2
  2,  LCD_POWER2, 0x10,
  // VCOM control 1
  3,  LCD_VCOM1, 0x3E, 0x28,
  // VCOM cotnrol 2
  2,  LCD_VCOM2, 0x86,
  // Memory access control
  2,  LCD_MAC, 0x48,
  // Pixel format set
  2,  LCD_PIXEL_FORMAT, 0x55,
  // Frame rate control
  3,  LCD_FRMCTR1, 0x00, 0x18,
  // Display function control
  4,  LCD_DFC, 0x08, 0x82, 0x27,
  // 3Gamma function disable
  2,  LCD_3GAMMA_EN, 0x00,
  // Gamma curve selected
  2,  LCD_GAMMA, 0x01,
  // Set positive & negatve gamma
  16, LCD_PGAMMA, 0x0F, 0x31, 0x2B, 0x0C, 0x0E, 0x08, 0x4E, 0xF1, 0x37, 0x07, 0x10, 0x03, 0x0E, 0x09, 0x00,
  16, LCD_NGAMMA, 0x00, 0x0E, 0x14, 0x03, 0x11, 0x07, 0x31, 0xC1, 0x48, 0x08, 0x0F, 0x0C, 0x31, 0x36, 0x0F,
  0
};

//----------------------------------------------------------------------------------------
#ifdef LCD_SPI_Device  // serial SPI interface
//----------------------------------------------------------------------------------------

static void LCD_SendCommand (uns8 data)
{
  LCD_DC_RESET;
  SPI_Send (&HLCD.LCDSPI, data);
}

static void LCD_SendData8 (uns8 data)
{
  LCD_DC_SET;
  SPI_Send (&HLCD.LCDSPI, data);
}

static void LCD_SendData16 (uns16 data)
{
  LCD_DC_SET;
  SPI_Send (&HLCD.LCDSPI, data >> 8);
  SPI_Send (&HLCD.LCDSPI, data);
}

static void LCD_DMAWait (void)
{
  while (SPI_I2S_GetFlagStatus (HLCD.LCDSPI.SPIx, SPI_I2S_FLAG_BSY) == SET)
    ;
}

static void LCD_DMASend16 (uns16 *pdata, uns32 cnt, uns8 stream)
{
  DMA_InitTypeDef aDMA;

  DMA_StructInit (&aDMA);
  aDMA.DMA_PeripheralBaseAddr = (uns32) &HLCD.LCDSPI.SPIx->DR;
  aDMA.DMA_Priority           = DMA_Priority_Medium;
  aDMA.DMA_MemoryBaseAddr     = (uns32) pdata;
  aDMA.DMA_BufferSize         = cnt;
  if (stream) // stream data for character line fill
  {
    aDMA.DMA_Mode             = DMA_Mode_Normal;
    aDMA.DMA_MemoryInc        = DMA_MemoryInc_Enable;
  }
  else        // color fill
  {
    aDMA.DMA_Mode             = DMA_Mode_Circular;
    aDMA.DMA_MemoryInc        = DMA_MemoryInc_Disable;
  }
  aDMA.DMA_DIR                = DMA_DIR_PeripheralDST;
  aDMA.DMA_MemoryDataSize     = DMA_MemoryDataSize_HalfWord;
  aDMA.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
  DMA_Init (HLCD.DMASPI_TXChan, &aDMA);
  DMA_Cmd (HLCD.DMASPI_TXChan, ENABLE);
}

static void LCD_DMA_Fill (uns16 x0, uns16 y0, uns16 x1, uns16 y1, uns16 color)
{
  uns32 pixelcount = (x1 - x0 + 1) * (y1 - y0 + 1);
  if (pixelcount > 0 && pixelcount <= LCD_PIXELS)
  {
    if (LCD_SetAddress (x0, y0, x1, y1))
    {
      LCD_SendCommand (LCD_GRAM);
      LCD_DC_SET;
      SPI_Set16Bit (&HLCD.LCDSPI);
      // Send first 65535 bytes, SPI MUST be in 16-bit mode
      LCD_DMASend16 (&color, (pixelcount > 0xffff) ? 0xffff : pixelcount, 0);
      LCD_DMAWait ();          // Wait till done
      if (pixelcount > 0xffff) // Send remaining data
      {
        LCD_DMASend16 (&color, pixelcount - 0xffff, 0);
        LCD_DMAWait ();         // Wait till done
      }
      SPI_Set8Bit (&HLCD.LCDSPI);
    }

    /*
    // Debug
    LCD_SendCommand (LCD_GRAM);
    for (uns32 i = 0; i < pixelcount; i++) // standard fill
      LCD_SendData16 (color);
    */
  }
}

static void LCD_CharFill (uns16 BufLen)
{
  LCD_SendCommand (LCD_GRAM);
  LCD_DC_SET;
  SPI_Set16Bit (&HLCD.LCDSPI);
  LCD_DMASend16 (HLCD.PixelBuf, BufLen, 1);
  LCD_DMAWait ();   // Wait till done
  SPI_Set8Bit (&HLCD.LCDSPI);
}

void LCD_Fill (uns16 x1, uns16 y1, uns16 w, uns16 h, uns16 color)
{
  LCD_DMA_Fill (x1, y1, x1 + w, y1 + h, color);
}

static void DMA1_ChannelX_IRQHandler (void)
{
  if (DMA_GetITStatus (HLCD.DMA_TX_Ready) == SET)
  {
    DMA_Cmd (HLCD.DMASPI_TXChan, DISABLE);
    DMA_ClearITPendingBit (HLCD.DMA_TX_Ready);
  }
}

void DMA1_Channel3_IRQHandler (void)
{
  DMA1_ChannelX_IRQHandler ();
}

void DMA1_Channel5_IRQHandler (void)
{
  DMA1_ChannelX_IRQHandler ();
}

static void LCD_DMAInit (void)
{
  RCC_AHBPeriphClockCmd (RCC_AHBPeriph_DMA1, ENABLE);

  // TX
  NVIC_EnableIRQ (HLCD.DMASPI_TX_IRQ);
  DMA_ITConfig (HLCD.DMASPI_TXChan, DMA_IT_TC, ENABLE);

  // RX
  //NVIC_EnableIRQ (DMA1_Channel4_IRQn);
  //DMA_ITConfig (DMA1_Channel4, DMA_IT_TC, ENABLE);

  SPI_I2S_DMACmd (HLCD.LCDSPI.SPIx, SPI_I2S_DMAReq_Tx, ENABLE);
  //SPI_I2S_DMACmd (HLCD.LCDSPI.SPIx, SPI_I2S_DMAReq_Rx, ENABLE);
}


static void LCD_ILI9341_Init ()
{
  PIO_Init (HLCD.LCD_DCPort, HLCD.LCD_DCPin, GPIO_Mode_Out_PP, GPIO_Speed_10MHz);
  PIO_Init (HLCD.LCD_CSPort, HLCD.LCD_CSPin, GPIO_Mode_Out_PP, GPIO_Speed_10MHz);
  PIO_Init (HLCD.LCD_RSTPort, HLCD.LCD_RSTPin, GPIO_Mode_Out_PP, GPIO_Speed_10MHz);
  LCD_CS_SET;             // deactivate CS
  InitSPI (&HLCD.LCDSPI);
  LCD_DMAInit ();         // Init DMA for SPI
}

//----------------------------------------------------------------------------------------
#else // parallel interface
//----------------------------------------------------------------------------------------

static void LCD_SendData (uns16 data)
{
  // f�r einen 16-Bit-Port:
  // GPIO_Write (GPIO_LCDLowData, data);
  // Delay (1);
  // LCD_WR_RESET;
  // Delay (1);
  // LCD_WR_SET;
  //
  // chinesische Pinanordnung (v�llig chaotisch, verteilt auf 2 16-Bit-Ports):
  // low 16 bit data port  bits: 0,1,4,5,7,8,9,10
  // high 16 bit data port bits: 8,9,10,11,12,13,14,15
  uns16 od = GPIO_ReadOutputData (HLCD.LCD_LowDataPort),
           reg = od & 0xe000;
  reg |= data & 0x0003;
  reg |= (data << 2) & 0x0030;
  reg |= (data << 3) & 0x0780;
  GPIO_Write (HLCD.LCD_LowDataPort, reg);
  Delay (1);
  od = GPIO_ReadOutputData (HLCD.LCD_HighDataPort);
  reg = od & 0x00ff;
  reg |= data & 0xff00;
  GPIO_Write (HLCD.LCD_HighDataPort, reg);
  Delay (1);
  LCD_WR_RESET;
  Delay (1);
  LCD_WR_SET;
}

static void LCD_SendData16 (uns16 data)
{
  LCD_DC_SET;
  LCD_SendData (data);
}

static void LCD_SendData8 (uns8 data)
{
  LCD_DC_SET;
  LCD_SendData (data);
}

static void LCD_SendCommand (uns8 data)
{
  LCD_DC_RESET;
  LCD_SendData (data);
}

void LCD_Fill (uns16 x1, uns16 y1, uns16 x2, uns16 y2, uns16 color)
{
  LCD_SetAddress (x1, y1, x2, y2);
  for (uns16 i = x1; i < x2; i++)
    for (uns16 j = y1; j < y2; j++)
      LCD_SendData16 (color);
}

static void ILI9341_Init ()
{
  PIO_Init (HLCD.LCD_DCPort, HLCD.LCD_DCPin, GPIO_Mode_Out_PP, GPIO_Speed_10MHz);
  PIO_Init (HLCD.LCD_CSPort, HLCD.LCD_CSPin, GPIO_Mode_Out_PP, GPIO_Speed_10MHz);
  PIO_Init (HLCD.LCD_RSTPort, HLCD.LCD_RSTPin, GPIO_Mode_Out_PP, GPIO_Speed_10MHz);
  PIO_Init (HLCD.LCD_WRPort, HLCD.LCD_WRPin, GPIO_Mode_Out_PP, GPIO_Speed_10MHz);
  PIO_Init (HLCD.LCD_RDPort, HLCD.LCD_RDPin, GPIO_Mode_IPU, GPIO_Speed_10MHz);
  PIO_Init (HLCD.LCD_LowDataPort, GPIO_Pin_All, GPIO_Mode_Out_PP, GPIO_Speed_10MHz);
  PIO_Init (HLCD.LCD_HighDataPort, GPIO_Pin_All, GPIO_Mode_Out_PP, GPIO_Speed_10MHz);

  LCD_CS_SET;   // deactivate CS
  LCD_RD_SET;
  LCD_WR_SET;
}

//----------------------------------------------------------------------------------------
#endif
//----------------------------------------------------------------------------------------

static uns8 LCD_SetAddress (uns16 x1, uns16 y1, uns16 x2, uns16 y2)
{
  LCDOptions_t *pLO = LCD_GetOpts ();
  if (x1 < pLO->width && x2 < pLO->width && y1 < pLO->height && y2 < pLO->height)
  {
    LCD_SendCommand (LCD_COLUMN_ADDR);
    LCD_SendData16 (x1);
    LCD_SendData16 (x2);

    LCD_SendCommand (LCD_PAGE_ADDR);
    LCD_SendData16 (y1);
    LCD_SendData16 (y2);
    return 1;
  }
  return 0;
}

void LCD_PowerUp (void)
{
  LCD_SendCommand (LCD_SLEEP_OUT);
}

void LCD_PowerDown (void)
{
  LCD_SendCommand (LCD_DISPLAY_OFF);
  LCD_SendCommand (LCD_SPLIN);
}


LCDOptions_t* LCD_GetOpts (void)
{
  return &LCD_Opts;
}

void LCD_SetParams (uns8 orientation, uns16 width, uns16 height)
{
  LCD_SendCommand (LCD_MAC);
  LCD_SendData8 (orientation);
  if (orientation == ORIENTATION_PORTRAIT || orientation == ORIENTATION_PORTRAIT_MIRROR)
  {
    LCD_Opts.width = width;
    LCD_Opts.height = height;
  }
  else
  {
    LCD_Opts.width = height;
    LCD_Opts.height = width;
  }
}

void LCD_SetBackLight (uns8 onoff)
{
  if (onoff)
    LCD_BL_ON;
  else
    LCD_BL_OFF;
}

static void LCD_Config (void)
{
  const uns8 *pcmd = LCD_InitCmds;
  uns8       ncount = *pcmd++;

  while (ncount--)
  {
    LCD_SendCommand (*pcmd++);
    for (uns8 i = 0; i < ncount; i++)
      LCD_SendData8 (*pcmd++);
    ncount = *pcmd++;
  }
}

static void LCD_SelectFont (uns8 afontno)
{
  LCD_Opts.FontNo = afontno;
  if (afontno == 3)
  {
    LCD_Opts.ZWMax = cZW3Max;
    LCD_Opts.ZHMax = cZH3Max;
    LCD_Opts.ZSAnz = cZS3Anz;
    LCD_Opts.pfont = font3;
  }
  else if (afontno == 2)
  {
    LCD_Opts.ZWMax = cZW2Max;
    LCD_Opts.ZHMax = cZH2Max;
    LCD_Opts.ZSAnz = cZS2Anz;
    LCD_Opts.pfont = font2;
  }
  else
  {
    LCD_Opts.ZWMax = cZW1Max;
    LCD_Opts.ZHMax = cZH1Max;
    LCD_Opts.ZSAnz = cZS1Anz;
    LCD_Opts.pfont = font1;
  }
}

static void InitLCD (void)
{
  LCD_ILI9341_Init ();
  PIO_Init (HLCD.LCD_BLPort, HLCD.LCD_BLPin, GPIO_Mode_Out_PP, GPIO_Speed_2MHz);
  LCD_BL_OFF;

  // Reset LCD
  LCD_RST_RESET;
  Delayms (cTime);
  LCD_RST_SET;
  Delayms (cTime);
  // Activate CS
  LCD_CS_RESET;
  // Software reset
  LCD_SendCommand (LCD_RESET);
  Delayms (2*cTime);
  // Send configuration commands
  LCD_Config ();
  LCD_PowerUp ();
  Delayms (5*cTime);

  // Set default settings
  LCD_Opts.BACK_COLOR = BLACK;
  LCD_SelectFont (cFont2);     // standard font
  LCD_SetParams (ORIENTATION_LANDSCAPE_MIRROR, LCD_WIDTH, LCD_HEIGHT);
  LCD_SendCommand (LCD_DISPLAY_ON);
  //LCD_BL_ON;
}

void LCD_Init_Custom (LCD_Handle_t *pHLCD)
{
  HLCD = *pHLCD;
  InitLCD ();
}

void LCD_Init (void)
{
#ifdef LCD_SPI_Device
  HLCD.LCDSPI.SPIx = LCD_SPI;
  HLCD.LCDSPI.pinpack = LCD_SPI_PINS;
  HLCD.DMASPI_TXChan = DMASPI_TX_Channel;
  HLCD.DMASPI_TX_IRQ = DMASPI_TX_Channel_IRQ;
  HLCD.DMA_TX_Ready = DMASPI_TXReady;
#endif
  HLCD.LCD_CSPort = LCD_CS_PORT;
  HLCD.LCD_CSPin = LCD_CS_PIN;
  HLCD.LCD_DCPort = LCD_DC_PORT;
  HLCD.LCD_DCPin = LCD_DC_PIN;
  HLCD.LCD_RSTPort = LCD_RST_PORT;
  HLCD.LCD_RSTPin = LCD_RST_PIN;
  HLCD.LCD_BLPort = LCD_BL_PORT;
  HLCD.LCD_BLPin = LCD_BL_PIN;
#ifndef LCD_SPI_Device
  HLCD.LCD_WRPort = LCD_WR_PORT;
  HLCD.LCD_WRPin = LCD_WR_PIN;
  HLCD.LCD_RDPort = LCD_RD_PORT;
  HLCD.LCD_RDPin = LCD_RD_PIN;
  HLCD.LCD_LowDataPort = LCD_LOWDATA_PORT;
  HLCD.LCD_HighDataPort = LCD_HIGHDATA_PORT;
#endif

  InitLCD ();
}

void LCD_Clear (uns16 color)
{
  LCD_Fill (0, 0, LCD_Opts.width - 1, LCD_Opts.height - 1, color);
}

uns16 LCD_GetBackColor (void)
{
  return LCD_Opts.BACK_COLOR;
}

void LCD_SetBackCol (uns16 color)
{
  LCD_Opts.BACK_COLOR = color;
}

void LCD_DrawPoint (uns16 x, uns16 y, uns16 color)
{
  LCD_SetAddress (x, y, x, y);
  LCD_SendCommand (LCD_GRAM);
  LCD_SendData16 (color);
}

void LCD_DrawBigPoint (uns16 x, uns16 y, uns16 color)
{
  LCD_Fill (x-1, y-1, 2, 2, color);
}

void LCD_DrawLine (uns16 x1, uns16 y1, uns16 x2, uns16 y2, uns16 color)
{
  if (x1 == x2 || y1 == y2) // horizontal / vertical lines
  {
    LCD_Fill (x1, y1, x2 - x1, y2 - y1, color);
    return;
  }
  int16 x = x1, y = y1,
        dx = x2 - x1,
        dy = y2 - y1,
        dist = dx,
        incx = 0, incy = 0,
        xerr = 0, yerr = 0;

  if (dx > 0)
    incx = 1;
  else if (dx < 0)
  {
    incx = -1;
    dx = -dx;
  }
  if (dy > 0)
    incy = 1;
  else if (dy < 0)
  {
    incy = -1;
    dy = -dy;
  }
  if (dx < dy)
    dist = dy;
  for (uns16 i = 0; i <= dist; i++)
  {
    xerr += dx;
    yerr += dy;
    if (xerr > dist)
    {
      xerr -= dist;
      x += incx;
    }
    if (yerr > dist)
    {
      yerr -= dist;
      y += incy;
    }
    LCD_DrawPoint (x, y, color);
  }
}

void LCD_DrawBigLine (uns16 x, uns16 y, uns16 len, uns8 hor, uns16 color)
{
  if (hor) // 1 = horizontal, 0 = vertical
    LCD_Fill (x, y-1, len, 2, color);
  else
    LCD_Fill (x-1, y, 2, len, color);
}

void LCD_DrawRect (uns16 x1, uns16 y1, uns16 w, uns16 h, uns16 color)
{
  uns16 x2 = x1 + w,
        y2 = y1 + h;
  LCD_DrawLine (x1, y1, x2, y1, color);
  LCD_DrawLine (x1, y1, x1, y2, color);
  LCD_DrawLine (x1, y2, x2, y2, color);
  LCD_DrawLine (x2, y1, x2, y2, color);
}


// draw/fill circles and round rects
static void LCD_Rounds (int16 x0, int16 y0, int16 x1, int16 y1,
                        uns16 r, uns8 filled, uns16 color)
{
  int16 err = -r, xc = r, yc = 0;
  while (xc >= yc)
  {
    if (filled)
    {
      LCD_DrawLine (x0 - xc, y0 - yc, x0, y0 - yc, color);
      LCD_DrawLine (x0 - yc, y0 - xc, x0, y0 - xc, color);
      LCD_DrawLine (x0 - xc, y1 + yc, x0, y1 + yc, color);
      LCD_DrawLine (x0 - yc, y1 + xc, x0, y1 + xc, color);
      LCD_DrawLine (x1, y0 - yc, x1 + xc, y0 - yc, color);
      LCD_DrawLine (x1, y0 - xc, x1 + yc, y0 - xc, color);
      LCD_DrawLine (x1, y1 + yc, x1 + xc, y1 + yc, color);
      LCD_DrawLine (x1, y1 + xc, x1 + yc, y1 + xc, color);
    }
    else
    {
      LCD_DrawPoint (x0 - xc, y0 - yc, color);
      LCD_DrawPoint (x0 - yc, y0 - xc, color);
      LCD_DrawPoint (x0 - xc, y1 + yc, color);
      LCD_DrawPoint (x0 - yc, y1 + xc, color);
      LCD_DrawPoint (x1 + xc, y0 - yc, color);
      LCD_DrawPoint (x1 + yc, y0 - xc, color);
      LCD_DrawPoint (x1 + xc, y1 + yc, color);
      LCD_DrawPoint (x1 + yc, y1 + xc, color);
    }
    err += yc++;
    err += yc;
    if (err >= 0)
    {
      xc--;
      err -= xc + xc;
    }
  }
}

void LCD_DrawRoundRect (uns16 x, uns16 y, uns16 w, uns16 h, uns16 r, uns16 color)
{
  if (r == 0)
    LCD_DrawRect (x, y, w, h, color);
  else
  {
    int16 x1 = x + w, y1 = y + h;
    LCD_DrawLine (x,   y+r, x,     y+h-r, color);
    LCD_DrawLine (x+r, y1,  x+w-r, y1,    color);
    LCD_DrawLine (x1,  y+r, x1,    y+h-r, color);
    LCD_DrawLine (x+r, y,   x+w-r, y,     color);
    LCD_Rounds (x + r, y + r, x1 - r, y1 - r, r, 0, color);
  }
}

void LCD_FillRoundRect (uns16 x, uns16 y, uns16 w, uns16 h, uns16 r, uns16 color)
{
  if (r == 0)
    LCD_Fill (x, y, w, h, color);
  else
  {
    int16 x1 = x + w, y1 = y + h;
    LCD_Fill (x,     y+r, r,       h-r-r, color);
    LCD_Fill (x1-r,  y+r, r,       h-r-r, color);
    LCD_Fill (x+r+1, y,   w-r-r,   h,   color);
    LCD_Rounds (x + r, y + r, x1 - r, y1 - r, r, 1, color);
  }
}

void LCD_DrawCircle (uns16 x, uns16 y, uns8 r, uns16 color)
{
  LCD_Rounds (x, y, x, y, r, 0, color);
}

void LCD_FillCircle (uns16 x, uns16 y, uns16 r, uns16 color)
{
  LCD_Rounds (x, y, x, y, r, 1, color);
}

uns16 LCD_GetTextLen (uns16 strlen, uns8 zoom, uns8 fontno)
{
  if (fontno != LCD_Opts.FontNo)
    LCD_SelectFont (fontno);
  return strlen * LCD_Opts.ZWMax * zoom;
}

// very fast DMA char fill routine
void LCD_ShowString (uns16 x, uns16 y, tStr str, uns8 zoom, uns8 fontno, uns16 color)
{
  if (fontno != LCD_Opts.FontNo)
    LCD_SelectFont (fontno);
  if (zoom > 4)
    zoom = 4;
  else if (zoom < 1)
    zoom = 1;
  uns16 HMax = (fontno == 2) ? LCD_Opts.ZHMax + 1 : LCD_Opts.ZHMax,
        WMax = (fontno == 2) ? LCD_Opts.ZWMax + 1 : LCD_Opts.ZWMax,
        col, BufCnt, linelen, lineofs,
        totalsize = HMax * WMax * zoom * zoom;
  uns8  completefill = totalsize < cMaxPixelBuf,
        pixcode, pos, charofs = (fontno == 2) ? 1 : 0;

  for (uns8 i = 0; i < str.len; i++)
  {
    BufCnt = 0; linelen = 0; lineofs = 0;
    if (x > LCD_Opts.width - LCD_Opts.ZWMax)
    {
      x = 0;
      y += LCD_Opts.ZHMax;
    }
    if (y > LCD_Opts.height - LCD_Opts.ZHMax)
      y = 0;
    char c = *str.pstr;
    c -= ' ';
    if (fontno == 3 && c > 0) // skip firstt 12 chars
      c -= 12;
    uns16 charidx = (uns16) c * LCD_Opts.ZHMax;
    for (pos = 0; pos < HMax; pos++)
    {
      if (fontno == 2 && pos == 0) // font2 margin correction
        pixcode = 0x00;
      else if (c < LCD_Opts.ZSAnz)
        pixcode = LCD_Opts.pfont [charidx + pos - charofs];
      else
        pixcode = 0xff;
      for (uns8 bitpos = 0; bitpos < WMax; bitpos++)
      {
        uns8 b;
        if (fontno == 2)  // font2 margin correction
        {
          if (bitpos == WMax - 1)
            b = 0;
          else
            b = pixcode & 0x20;
        }
        else
          b = pixcode & 0x01;
        if (b)
          col = color;
        else
          col = LCD_Opts.BACK_COLOR;
        for (uns8 i = 0; i < zoom; i++)
          HLCD.PixelBuf [BufCnt++] = col;
        if (LCD_Opts.FontNo == 2)
          pixcode <<= 1;
        else
          pixcode >>= 1;
      }
      linelen = BufCnt;
      if (zoom > 1)
      {
        for (uns16 i = lineofs; i < linelen; i++)
          HLCD.PixelBuf [BufCnt++] = HLCD.PixelBuf [i];
      }
      if (zoom > 2)
      {
        uns16 len = linelen << 1;
        for (uns16 i = lineofs; i < len; i++)
          HLCD.PixelBuf [BufCnt++] = HLCD.PixelBuf [i];
      }
      if (completefill) // complete char
      {
        lineofs = BufCnt;
        if (BufCnt >= totalsize && BufCnt < cMaxPixelBuf && LCD_SetAddress (x, y, x + WMax * zoom - 1, y + HMax * zoom - 1))
          LCD_CharFill (BufCnt);
      }
      else // char line
      {
        if (BufCnt < cMaxPixelBuf && LCD_SetAddress (x, y + pos * zoom, x + linelen-1, y + (pos + 1) * zoom))
          LCD_CharFill (BufCnt);
        BufCnt = 0;
        linelen = 0;
      }
    }
    x += zoom * LCD_Opts.ZWMax;
    str.pstr++;
  }
}

void LCD_ShowNum (uns16 x, uns16 y, int32 val, uns8 zoom, uns8 fontno, uns16 format, uns16 color)
{
  char str [13];
  ValToStr (val, str, format);
  LCD_ShowString (x, y, Init_tStr (str), zoom, fontno, color);
}

void LCD_ShowValue (uns16 x, uns16 y, int32 val, uns8 zoom, uns8 fontno,
                    uns16 format, uns16 color, uns8 *pbuf, uns8 *pinit)
{
  char str [13];
  tStr s;
  uns8 len = GetValueLen (format);
  if (fontno != LCD_Opts.FontNo)
    LCD_SelectFont (fontno);
  if (*pinit) // Init. char buffer
  {
    *pinit = 0;
    for (uns8 i = 0; i < len; i++)
    {
      pbuf [i] = ' ';
      str [i] = ' ';
    }
    str [len] = 0;
    LCD_ShowString (x, y, Init_tStr (str), zoom, fontno, color);
  }
  s.len = 1;
  ValToStr (val, str, format);
  for (uns8 i = 0; i < len; i++)
  {
    if (str [i] != pbuf [i]) // only show chars that changed
    {
      s.pstr = &str [i];
      LCD_ShowString (x, y, s, zoom, fontno, color);
      pbuf [i] = str [i];
    }
    x += zoom * LCD_Opts.ZWMax;
  }
}

void LCD_DrawTouchPoint (uns16 x, uns16 y, uns16 color)
{
  if (x > 5 && x < LCD_Opts.width - 5)
    LCD_DrawLine (x-5, y, x+5, y, color);
  if (y > 5 && y < LCD_Opts.height - 5)
    LCD_DrawLine (x, y-5, x, y+5, color);
  LCD_DrawBigPoint (x, y, color);
}

void LCD_SetVerticalScrolling (uns16 startY, uns16 endY)
{
  LCD_SendCommand (LCD_VSCRDEF);
  LCD_SendData8 (startY);
  LCD_SendData8 (LCD_Opts.height - startY - endY);
  LCD_SendData8 (endY);
}

void LCD_Scroll (uns16 v)
{
  LCD_SendCommand (LCD_VSCRSADD);
  LCD_SendData8 (v);
}
