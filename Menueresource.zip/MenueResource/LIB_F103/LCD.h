#ifndef __LCD_H
#define __LCD_H

#include "stm32f10x_conf.h"
#include "font.h"
#include "mySPI.h"


#define LCD_SPI_Device   // SPI- oder Parallel-Port
                         // uncomment f. parallel display

// LCD Backlight
#define LCD_BL_PORT      GPIOA
#define LCD_BL_PIN       GPIO_Pin_10

#ifdef LCD_SPI_Device // IO-Pins SPI-Display

#define LCD_SPI          SPI2
#define LCD_SPI_PINS     cSPI_PinPack_1

#define LCD_CS_PORT      GPIOB
#define LCD_CS_PIN       GPIO_Pin_12
#define LCD_DC_PORT      GPIOA
#define LCD_DC_PIN       GPIO_Pin_8
#define LCD_RST_PORT     GPIOA
#define LCD_RST_PIN      GPIO_Pin_9

#define DMASPI_TX_Channel      DMA1_Channel5      // DMA1SPI2 TX
#define DMASPI_TX_Channel_IRQ  DMA1_Channel5_IRQn // DMA1SPI2 TX Interrupt
#define DMASPI_TXReady         DMA1_IT_TC5        // Flag DMA-Transfer Channel 5 complete

#else                 // IO-Pins Parallelport

#define LCD_LOWDATA_PORT  GPIOD       // low 16 bit data port  bits: 0,1,4,5,7,8,9,10
#define LCD_HIGHDATA_PORT GPIOE       // high 16 bit data port bits: 8,9,10,11,12,13,14,15

#define LCD_DC_PORT      GPIOD
#define LCD_DC_PIN       GPIO_Pin_13 // 1=Data, 0=Command
#define LCD_WR_PORT      GPIOD
#define LCD_WR_PIN       GPIO_Pin_14 // write Data on rising edge
#define LCD_RD_PORT      GPIOD
#define LCD_RD_PIN       GPIO_Pin_3  // read Data on rising edge
#define LCD_CS_PORT      GPIOE
#define LCD_CS_PIN       GPIO_Pin_7  // Chip select Pin (active low)
#define LCD_RST_PORT     GPIOD
#define LCD_RST_PIN      GPIO_Pin_15 // Reset Pin (active low)

#endif

#define cMaxPixelBuf 320 // max. size for font=3, zoom = 4

typedef struct // LCD handle
{
  // SPI-Interface
  HSPI_t       LCDSPI;
  // SPI-DMA
  DMA_Channel_TypeDef *DMASPI_TXChan;
  IRQn_Type    DMASPI_TX_IRQ;
  uns32        DMA_TX_Ready;
  // Ports (SPI- und paralleles Interface)
  GPIO_TypeDef *LCD_CSPort;
  uns16        LCD_CSPin;
  GPIO_TypeDef *LCD_DCPort;
  uns16        LCD_DCPin;
  GPIO_TypeDef *LCD_RSTPort;
  uns16        LCD_RSTPin;
  GPIO_TypeDef *LCD_BLPort;
  uns16        LCD_BLPin;
  // nur f. paralleles Interface
  GPIO_TypeDef *LCD_WRPort;
  uns16        LCD_WRPin;
  GPIO_TypeDef *LCD_RDPort;
  uns16        LCD_RDPin;
  GPIO_TypeDef *LCD_LowDataPort,
               *LCD_HighDataPort;
  // private: buffer for char pixels (one char or char line) for DMA
  uns16        PixelBuf [cMaxPixelBuf];
} LCD_Handle_t;

// LCD dimensions
#define LCD_WIDTH        240                      // pixel width
#define LCD_HEIGHT       320                      // pixel height
#define LCD_PIXELS       (LCD_WIDTH * LCD_HEIGHT) // no. of pixels

// Colors
#define WHITE            0xFFFF
#define BLACK         	 0x0000
#define RED           	 0xF800
#define GREEN         	 0x07E0
#define BLUE         	 0x001F
#define MAGENTA       	 0xF81F
#define CYAN          	 0x7FFF
#define YELLOW        	 0xFFE0
#define BROWN 			 0X71C0
#define GRAY  			 0X8430
#define ORANGE			 0XFD40
#define DARKBLUE      	 0X01CF
#define LIGHTBLUE      	 0X7D7C
#define GRAYBLUE       	 0X5458
#define LIGHTGREEN     	 0X841F
#define LGRAY 			 0XC618
#define LGRAYBLUE        0XA651
#define LBBLUE           0X2B12
#define LYELLOW        	 0xCE2E
#define DARKRED      	 0X6000
#define DARKGRAY  		 0X52A9
#define DARKGREEN  		 0X0380

// Orientations for LCD
#define ORIENTATION_PORTRAIT         0x48
#define ORIENTATION_LANDSCAPE        0x28
#define ORIENTATION_PORTRAIT_MIRROR  0x88
#define ORIENTATION_LANDSCAPE_MIRROR 0xE8

typedef struct           // font / screen descriptor
{
  uns16      width,      // screen
             height,
             ZWMax,      // font character size
             ZHMax,
             ZSAnz,      // no. of font characters
             BACK_COLOR; // background color
  uns8       FontNo;     // curr. font no.
  const uns8 *pfont;     // reference to current font
} LCDOptions_t;

void LCD_Init (void);
void LCD_Init_Custom (LCD_Handle_t *pHLCD);

void LCD_PowerUp (void);
void LCD_PowerDown (void);

void LCD_SetBackLight (uns8 onoff);
void LCD_SetParams (uns8 orientation, uns16 width, uns16 height);
LCDOptions_t* LCD_GetOpts (void);

void LCD_Clear (uns16 color);
void LCD_Fill (uns16 x1, uns16 y1, uns16 w, uns16 h, uns16 color);

void LCD_SetBackCol (uns16 color);
uns16 LCD_GetBackColor (void);

void LCD_DrawPoint (uns16 x, uns16 y, uns16 color);
void LCD_DrawBigPoint (uns16 x, uns16 y, uns16 color);

void LCD_DrawLine (uns16 x1, uns16 y1, uns16 x2, uns16 y2, uns16 color);
void LCD_DrawBigLine (uns16 x, uns16 y, uns16 len, uns8 hor, uns16 color);

void LCD_DrawRect (uns16 x1, uns16 y1, uns16 w, uns16 h, uns16 color);
void LCD_DrawRoundRect (uns16 x, uns16 y, uns16 w, uns16 h, uns16 r, uns16 color);
void LCD_FillRoundRect (uns16 x, uns16 y, uns16 w, uns16 h, uns16 r, uns16 color);

void LCD_DrawCircle (uns16 x, uns16 y, uns8 r, uns16 color);
void LCD_FillCircle (uns16 x, uns16 y, uns16 r, uns16 color);

uns16 LCD_GetTextLen (uns16 strlen, uns8 zoom, uns8 fontno);
void LCD_ShowString (uns16 x, uns16 y, tStr str, uns8 zoom, uns8 fontno, uns16 color);

void LCD_ShowNum (uns16 x, uns16 y, int32 val, uns8 zoom, uns8 fontno, uns16 format, uns16 color);
void LCD_ShowValue (uns16 x, uns16 y, int32 val, uns8 zoom, uns8 fontno,
                    uns16 format, uns16 color, uns8 *pbuf, uns8 *pinit);

void LCD_DrawTouchPoint (uns16 x, uns16 y, uns16 color);

void LCD_SetVerticalScrolling (uns16 startY, uns16 endY);
void LCD_Scroll (uns16 v);

#endif

