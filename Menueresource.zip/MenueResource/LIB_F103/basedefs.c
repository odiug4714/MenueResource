#include "basedefs.h"

static uns32 SWTimers [cMaxTimers];

int32 vmax (int32 a, int32 b)
{
  if (a > b)
    return a;
  return b;
}

int32 vmin (int32 a, int32 b)
{
  if (a < b)
    return a;
  return b;
}

int32 MinMaxVal (int32 v, int32 vmin, int32 vmax)
{
  if (v < vmin)
    v = vmin;
  else if (v > vmax)
    v = vmax;
  return v;
}

int32 MinMaxValZyk (int32 v, int32 vmin, int32 vmax)
{
  if (v < vmin)
    v = vmax;
  else if (v > vmax)
    v = vmin;
  return v;
}

int32 ValConvert (int32 inputval, uns16 format)
{
  uns8  nk = format & 0x0f;
  int32 v = 1;
  for (uns8 i = 0; i < nk; i++)
    v *= 10;
  inputval <<= 10; // * 1024
  inputval /= v;
  return inputval;
}

void DecTimers (void)
{
  for (uns8 i = 0; i < cMaxTimers; i++)
  {
    if (SWTimers [i] > 0)
      SWTimers [i]--;
  }
}

void SetTimer (uns8 TimIndex, uns32 Time)
{
  SWTimers [TimIndex] = Time;
}

uns8 TimerExpired (uns8 TimIndex, uns32 NewTime)
{
  uns8 b = SWTimers [TimIndex] == 0;
  if (b)
    SWTimers [TimIndex] = NewTime;
  return b;
}

uns16 StrLen (const char* str)
{
  const char *p = str;
  uns16 l = 0;
  while (*p++)
    l++;
  return l;
}

void StrCopy (char* srcstr, char* deststr)
{
  char *p = srcstr;
  char *q = deststr;
  while (*p)
    *q++ = *p++;
  *q = 0;
}

char* StrCat (char* srcstr, char* str)
{
  char *p = srcstr;
  while (*p)
    p++;
  StrCopy (str, p);
  return srcstr;
}

void NextStr (char** pstr, char delim, char* resstr)
{
  char *s = *pstr, *sr = resstr;
  while (**pstr)
  {
     if (**pstr == delim)
     {
       while (s != *pstr)
         *sr++ = *s++;
       *sr = 0;
       (*pstr)++;
       return;
     }
     (*pstr)++;
  }
  while (*s)
    *sr++ = *s++;
  *sr = 0;
}

uns8 GetValueLen (uns16 format)
{
  uns8 len,
       nk = format & 0x0f;
  if (format & cHex)
    len = ((format & 0xff) >> 4) + 2 * ((format & 0x200) > 0);
  else
    len = ((format & 0xff) >> 4) + nk + (nk > 0);
  return len;
}

static void ValToHexStr (uns32 val, char *pstr, uns16 format)
{
  uns8 len = GetValueLen (format),
       c = ' ', ofs = 0;
  if (format & cLeadingZeros)
    c = '0';
  if (format & cHex0x)
  {
    pstr [0] = '0';
    pstr [1] = 'x';
    ofs = 2;
  }
  pstr [len] = 0;
  for (int8_t i = len - 1; i >= ofs; i--)
  {
    if (val == 0 && i != len - 1)
      pstr [i] = c;
    else
    {
      uns8 v = val & 0x0000000f;
      val >>= 4;
	  if (v < 10)
        pstr [i] = v + '0';
      else if (format & 4)
        pstr [i] = v - 10 + 'A';
      else
        pstr [i] = v - 10 + 'a';
    }
  }
}

void ValToStr (int32 val, char *pstr, uns16 format)
{
  if (format & cHex)
    ValToHexStr (val, pstr, format);
  else
  {
    uns8 nk = format & 0x0f,
         len = GetValueLen (format),
         c = ' ', sign = 0;
    int8 expo = - nk;

    if (format & cLeadingZeros)
      c = '0';
    if (val < 0)
    {
      val = -val;
      sign = 1;
    }
    uns8 firstchar = len;
    pstr [len] = 0;
    for (int8 i = len - 1; i >= 0; i--)
    {
      if (expo > 0 && val == 0 && i != len - 1)
      {
        pstr [i] = c;
        if (firstchar == len)
          firstchar = i;
      }
      else
      {
        int32 v = val / 10;
        pstr [i] = (val - v * 10) + '0';
        val = v;
      }
      if (expo == -1)
        pstr [--i] = '.';
      expo++;
    }
    if (sign && firstchar != len)
      pstr [firstchar] = '-';
  }
}

int32_t StrToVal (const char* str)
{
  const char *p = str, *q;
  int32_t    v, e = 1, base = 10;
  uns8    fminus = 0;

  while (*p == ' ')
    p++;
  q = p;
  if (*q == '0')
  {
    q++;
    if (*q == 'x' || *q == 'X')
      base = 16;
  }
  if (*p == '-')
  {
    if (base != 16)
      fminus = 1;
    else
      return cMaxInt;
  }
  q = p;
  while (*p)
    p++;
  while (p > q)
  {
    char c = *(--p);
    if (c != ' ')
    {
      if (c >= '0' && c <= '9')
        v += (c - '0') * e;
      else if (base == 16 && c >= 'a' && c <= 'f')
        v += (c - 'a' + 10) * e;
      else if (base == 16 && c >= 'A' && c <= 'F')
        v += (c - 'A' + 10) * e;
      else
        return cMaxInt;
      e *= base;
    }
  }
  if (fminus)
    v = -v;
  if (e == 1)
    return cMaxInt;
  return v;
}


//------------------------------------------------------------------------
// tStr-Funktionen
//------------------------------------------------------------------------
tStr Init_tStr (const char *p)
{
  tStr str;
  str.pstr = p;
  str.len = StrLen (p);
  return str;
}

uns8 IsIn_tStr (const char *s, tStr str)
{
  while (*str.pstr == ' ' && str.len > 0)
  {
    str.len--;
    str.pstr++;
  }
  uns16 len = StrLen (s);
  if (len == str.len)
  {
    for (uns16 i = 0; i < len; i++)
    {
      if (*s++ != *str.pstr++)
        return 0;
    }
    return 1;
  }
  return 0;
}

uns8 tStr_In_tStr (tStr s, tStr str)
{
  uns16 len = vmin (s.len, str.len);
  for (uns16 i = 0; i < len; i++)
  {
    if (*s.pstr++ != *str.pstr++)
      return 0;
  }
  return 1;
}

int32 tStrToVal (tStr str)
{
  const char *p = str.pstr, *q;
  char       c;
  int32      v = 0, e = 1, base = 10;
  uns8       fminus = 0;
  uns16      l = str.len;

  if (l == 0)
    return cMaxInt;
  while (*p == ' ')
    p++;
  q = p;
  if (*q == '0')
  {
    if (l > 1)
    {
      c = *(q+1);
      if (c == 'x' || c == 'X')
      {
        base = 16;
        q += 2;
      }
    }
  }
  if (*p == '-')
  {
    q++;
    if (base != 16)
      fminus = 1;
    else
      return cMaxInt;
  }
  p = str.pstr + l - 1;
  while (p >= q)
  {
    c = *p;
    if (c != ' ' || c != '.') // Punkt ignorieren
    {
      if (c >= '0' && c <= '9')
        v += (c - '0') * e;
      else if (base == 16 && c >= 'a' && c <= 'f')
        v += (c - 'a' + 10) * e;
      else if (base == 16 && c >= 'A' && c <= 'F')
        v += (c - 'A' + 10) * e;
      else
        return cMaxInt;
      e *= base;
    }
    l--;
    p--;
  }
  if (fminus)
    v = -v;
  if (e == 1)
    return cMaxInt;
  return v;
}

tStr Next_tStr (tStr *str, char delim)
{
  const char *p = str->pstr;
  uns16      len = str->len,
             cnt = 0;
  tStr       resstr;
  resstr.pstr = p;
  resstr.len = 0;
  while (len > 0)
  {
    if (*p == delim)
    {
      resstr.len = cnt;
      if (len > 0)
      {
        p++;
        if (*p)
        {
          len--;
          if (len > 0)
          {
            str->pstr = p;
            str->len = len;
            return resstr;
          }
        }
      }
      str->pstr = 0;
      str->len = 0;
      return resstr;
    }
    len--;
    cnt++;
    p++;
  }
  if (cnt > 0)
  {
    resstr.len = cnt;
    str->pstr = 0;
    str->len = 0;
  }
  return resstr;
}
