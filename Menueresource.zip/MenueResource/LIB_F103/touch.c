//---------------------------------------------------------------------------------
// Touchpanel driver for XPT2046 or ADS7843
// Autor: Guido Kahle and others
//---------------------------------------------------------------------------------
#include "touch.h"
#include "delay.h"
#include "myGPIO.h"

// touch panel interface
#define  CMD_RDX   0x90      // Read X-Koordinate
#define  CMD_RDY   0xD0      // Read Y-Koordinate
#define  CMD_TMP   0xF4      // Read Junction temperature

#define cReadCnt   8         // Anzahl Mess-Iterationen
#define TouchDelay 2         // us Delay

// Calibration
#define cTouchCvx  400       // Verschiebung
#define cTouchCvy  300
#define cTouchCfx  11        // Faktor
#define cTouchCfy  15

static Touch_Handle_t HTouch; // Touch-Handle

#define PIN_Touch_CS_ON         GPIO_WriteBit (HTouch.CS_Port, HTouch.CS_Pin, Bit_SET)
#define PIN_Touch_CS_OFF        GPIO_WriteBit (HTouch.CS_Port, HTouch.CS_Pin, Bit_RESET)

#define PIN_Touch_DCLK_ON       GPIO_WriteBit (HTouch.DCLK_Port, HTouch.DCLK_Pin, Bit_SET)
#define PIN_Touch_DCLK_OFF      GPIO_WriteBit (HTouch.DCLK_Port, HTouch.DCLK_Pin, Bit_RESET)

#define PIN_Touch_DIN_ON        GPIO_WriteBit (HTouch.DIN_Port, HTouch.DIN_Pin, Bit_SET)
#define PIN_Touch_DIN_OFF       GPIO_WriteBit (HTouch.DIN_Port, HTouch.DIN_Pin, Bit_RESET)

#define PIN_Touch_DOUT_SET      (GPIO_ReadInputDataBit (HTouch.DOUT_Port, HTouch.DOUT_Pin))

#define PIN_Touch_Penirq_LOW    (!GPIO_ReadInputDataBit (HTouch.PIRQ_Port, HTouch.PIRQ_Pin))


#ifdef Touch_SPI_Device // SPI interface

static void WriteCMD (uns8 cmd)
{
  SPI_Set8Bit (&HTouch.TouchSPI);
  SPI_Send (&HTouch.TouchSPI, cmd);
}

static uns16 ReadKoord (void)
{
  uns16 Koord = 0;
  SPI_Set16Bit (&HTouch.TouchSPI);
  SPI_ReadWords (&HTouch.TouchSPI, &Koord, 1);
  Koord >>= 4;
  return (Koord);
}

#else

static void WriteCMD (uns8 cmd)
{
  uns8 mask = 0x80;
  for (uns8 i = 0; i < 8; i++)
  {
    if (cmd & mask)
      PIN_Touch_DIN_ON;
    else
      PIN_Touch_DIN_OFF;
    mask >>= 1;
    Delay (TouchDelay);
    PIN_Touch_DCLK_ON;
    Delay (TouchDelay);
    PIN_Touch_DCLK_OFF;
  }
}

static uns16 ReadKoord (void)
{
  uns16 Koord = 0;
  for (uns8 i = 0; i < 16; i++)
  {
    PIN_Touch_DCLK_ON;
    Delay (TouchDelay);
    if (PIN_Touch_DOUT_SET)
      Koord |= 1;
    Koord <<= 1;
    Delay (TouchDelay);
    PIN_Touch_DCLK_OFF;
    Delay (TouchDelay);
  }
  Koord >>= 4;
  return (Koord);
}

#endif

static uns8 ReadXY (uns16 *px, uns16 *py)
{
  uint32_t xsum = 0, ysum = 0;

  PIN_Touch_CS_OFF;
  for (uns8 i = 0; i < cReadCnt; i++)
  {
    WriteCMD (CMD_RDX);
    xsum += ReadKoord ();
    WriteCMD (CMD_RDY);
    ysum += ReadKoord ();
  }
  PIN_Touch_CS_ON;
  *px = xsum / cReadCnt;
  *py = ysum / cReadCnt;
  return 1;
}

uns8 Touch_Koords (uns16 *px, uns16 *py)
{
  if (HTouch.fsimulate)          // simulation active
  {
    *px = HTouch.SimX;
    *py = HTouch.SimY;
    HTouch.fsimulate = 0;
    return 1;
  }
  else if (PIN_Touch_Penirq_LOW) // touching
  {
    int16_t touchx, touchy;
    if (ReadXY ((uns16*) &touchx, (uns16*) &touchy))
    {
      touchx = (touchx - HTouch.Cvx) / HTouch.Cfx;
      touchy = (touchy - HTouch.Cvy) / HTouch.Cfy;
      if (HTouch.Orientation == Touch_LANDSCAPE)
        touchy = HTouch.Height - touchy;
      else if (HTouch.Orientation == Touch_PORTRAIT)
        touchx = HTouch.Width - touchx;
      if (touchx <= 0)
        touchx = 1;
      else if (touchx > HTouch.Width - 1)
        touchx = HTouch.Width - 1;
      if (touchy <= 0)
        touchy = 1;
      else if (touchy > HTouch.Height - 1)
        touchy = HTouch.Height - 1;
      *px = touchx;
      *py = touchy;
      return 1;
    }
  }
  return 0;
}

void Touch_SetParams (uns8 orientation, uns16 width, uns16 height)
{
  HTouch.Orientation = orientation;
  if (orientation == Touch_PORTRAIT || orientation == Touch_PORTRAIT_MIRROR)
  {
    HTouch.Width = width;
    HTouch.Height = height;
  }
  else
  {
    HTouch.Width = height;
    HTouch.Height = width;
  }
}

void Touch_Calibrate (uns16 cfx, uns16 cvx, uns16 cfy, uns16 cvy)
{
  HTouch.Cfx = cfx;
  HTouch.Cfy = cfy;
  HTouch.Cvx = cvx;
  HTouch.Cvy = cvy;
}

void Touch_Simulate (uns16 x, uns16 y)
{
  HTouch.SimX = x;
  HTouch.SimY = y;
  HTouch.fsimulate = 1;
}

static void InitTouch (void)
{
#ifdef Touch_SPI_Device // SPI interface
  InitSPI (&HTouch.TouchSPI);
#else // parallel interface
  PIO_Init (HTouch.DCLK_Port, HTouch.DCLK_Pin, GPIO_Mode_Out_PP, GPIO_Speed_2MHz);
  PIO_Init (HTouch.DIN_Port, HTouch.DIN_Pin, GPIO_Mode_Out_PP, GPIO_Speed_2MHz);
  PIO_Init (HTouch.DOUT_Port, HTouch.DOUT_Pin, GPIO_Mode_IPU, GPIO_Speed_2MHz);
  PIN_Touch_DCLK_OFF;
  PIN_Touch_DIN_OFF;
#endif

  PIO_Init (HTouch.PIRQ_Port, HTouch.PIRQ_Pin, GPIO_Mode_IPU, GPIO_Speed_2MHz);
  PIO_Init (HTouch.CS_Port, HTouch.CS_Pin, GPIO_Mode_Out_PP, GPIO_Speed_2MHz);
  PIN_Touch_CS_ON;

  Touch_Calibrate (cTouchCfx, cTouchCvx, cTouchCfy, cTouchCvy);
  Touch_SetParams (Touch_LANDSCAPE_MIRROR, cTouchWidth, cTouchHeight);
}

void Touch_Init_Custom (Touch_Handle_t *pTH)
{
  HTouch = *pTH;
  InitTouch ();
}

void Touch_Init (void)
{
#ifdef Touch_SPI_Device // SPI interface
  HTouch.TouchSPI.SPIx = Touch_SPI;
  HTouch.TouchSPI.pinpack = Touch_SPI_PINS;
#else // parallel interface
  HTouch.DCLK_Port = PORT_Touch_DCLK;
  HTouch.DCLK_Pin = PIN_Touch_DCLK;
  HTouch.DIN_Port = PORT_Touch_DIN;
  HTouch.DIN_Pin = PIN_Touch_DIN;
  HTouch.DOUT_Port = PORT_Touch_DOUT;
  HTouch.DOUT_Pin = PIN_Touch_DOUT;
#endif

  HTouch.CS_Port = PORT_Touch_CS;
  HTouch.CS_Pin = PIN_Touch_CS;
  HTouch.PIRQ_Port = PORT_Touch_Penirq;
  HTouch.PIRQ_Pin = PIN_Touch_Penirq;

  InitTouch ();
}
