#include "myADC.h"
#include "myGPIO.h"

void InitADC (ADC_TypeDef* ADCx)
{
  ADC_InitTypeDef aADC;

  RCC_ADCCLKConfig (RCC_PCLK2_Div6);

  if (ADCx == ADC1)
    RCC_APB2PeriphClockCmd (RCC_APB2Periph_AFIO | RCC_APB2Periph_ADC1, ENABLE);
  else if (ADCx == ADC2)
    RCC_APB2PeriphClockCmd (RCC_APB2Periph_AFIO | RCC_APB2Periph_ADC2, ENABLE);

  aADC.ADC_ContinuousConvMode = ENABLE;
  aADC.ADC_DataAlign = ADC_DataAlign_Right;
  aADC.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
  aADC.ADC_Mode = ADC_Mode_Independent;
  aADC.ADC_NbrOfChannel = 1;
  aADC.ADC_ScanConvMode = DISABLE;
  ADC_Init (ADCx, &aADC);

  ADC_Cmd (ADCx, ENABLE);
}

void InitADCChannel (ADC_TypeDef* ADCx, uint8_t ch)
{
  GPIO_TypeDef *GPIO = GPIOA;
  uint16_t     pin;
  switch (ch)
  {
    case ADC_Channel_0: pin = GPIO_Pin_0; break;
    case ADC_Channel_1: pin = GPIO_Pin_1; break;
    case ADC_Channel_2: pin = GPIO_Pin_2; break;
    case ADC_Channel_3: pin = GPIO_Pin_3; break;
    case ADC_Channel_4: pin = GPIO_Pin_4; break;
    case ADC_Channel_5: pin = GPIO_Pin_5; break;
    case ADC_Channel_6: pin = GPIO_Pin_6; break;
    case ADC_Channel_7: pin = GPIO_Pin_7; break;
    case ADC_Channel_8: GPIO = GPIOB; pin = GPIO_Pin_0;  break;
    case ADC_Channel_9: GPIO = GPIOB; pin = GPIO_Pin_1;  break;
    case ADC_Channel_10: GPIO = GPIOC; pin = GPIO_Pin_0; break;
    case ADC_Channel_11: GPIO = GPIOC; pin = GPIO_Pin_1; break;
    case ADC_Channel_12: GPIO = GPIOC; pin = GPIO_Pin_2; break;
    case ADC_Channel_13: GPIO = GPIOC; pin = GPIO_Pin_3; break;
    case ADC_Channel_14: GPIO = GPIOC; pin = GPIO_Pin_4; break;
    case ADC_Channel_15: GPIO = GPIOC; pin = GPIO_Pin_5; break;
    default : return;
  }
  PIO_Init (GPIO, pin, GPIO_Mode_AIN, GPIO_Speed_50MHz);
}


uint16_t ADC_Read (ADC_TypeDef* ADCx, uint8_t ch)
{
  ADC_RegularChannelConfig (ADCx, ch, 1, ADC_SampleTime_28Cycles5);
  ADC_SoftwareStartConvCmd (ADCx, ENABLE);
  return ADC_GetConversionValue (ADCx);
}

void ADC_EnableVbat(void)
{
  // Enable VBAT
  //ADC->CCR |= ADC_CCR_VBATE;
}

void ADC_DisableVbat(void)
{
  // Disable VBAT
  //ADC->CCR &= ~ADC_CCR_VBATE;
}

uint16_t ADC_ReadVbat(ADC_TypeDef* ADCx)
{
  // Read battery voltage
  // Start conversion
  //ADC_RegularChannelConfig(ADCx, ADC_Channel_Vbat, 1, ADC_SampleTime_239Cycles5);
  // Start software conversion
  ADCx->CR2 |= (uint32_t)ADC_CR2_SWSTART;
  // Wait till done
  while (!(ADCx->SR & ADC_SR_EOC))
    ;
  // Get result
  uint32_t result = ADCx->DR;
  // Convert to voltage
  //result = result * ADC_VBAT_MULTI * ADC_SUPPLY_VOLTAGE / 0xFFF;
  // Return value in mV
  return (uint16_t) result;
}
