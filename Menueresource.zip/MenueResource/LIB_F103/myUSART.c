#include "myUSART.h"
#include "myGPIO.h"

static void USART1_InitPins (uint8_t pinpack)
{
  if (pinpack == cUSART_Pinpack_1)
  {
    PIO_Init (GPIOA, GPIO_Pin_9, GPIO_Mode_AF_PP, GPIO_Speed_10MHz);
    PIO_Init (GPIOA, GPIO_Pin_10, GPIO_Mode_IN_FLOATING, GPIO_Speed_10MHz);
  }
  else if (pinpack == cUSART_Pinpack_2)
  {
    PIO_Init (GPIOB, GPIO_Pin_6, GPIO_Mode_AF_PP, GPIO_Speed_10MHz);
    PIO_Init (GPIOB, GPIO_Pin_7, GPIO_Mode_IN_FLOATING, GPIO_Speed_10MHz);
  }
}

static void USART2_InitPins (uint8_t pinpack)
{
  if (pinpack == cUSART_Pinpack_1)
  {
    PIO_Init (GPIOA, GPIO_Pin_2, GPIO_Mode_AF_PP, GPIO_Speed_10MHz);
    PIO_Init (GPIOA, GPIO_Pin_3, GPIO_Mode_IN_FLOATING, GPIO_Speed_10MHz);
  }
}

static void USART3_InitPins (uint8_t pinpack)
{
  if (pinpack == cUSART_Pinpack_1)
  {
    PIO_Init (GPIOB, GPIO_Pin_10, GPIO_Mode_AF_PP, GPIO_Speed_10MHz);
    PIO_Init (GPIOB, GPIO_Pin_11, GPIO_Mode_IN_FLOATING, GPIO_Speed_10MHz);
  }
}

void InitUsart (USART_TypeDef *USARTx, uint8_t pinpack, uint32_t Baudrate)
{
  USART_InitTypeDef usart;
  NVIC_InitTypeDef  aNVIC;

  // Enalbe clock for USART
  if (USARTx == USART1)
  {
  	if (pinpack == cUSART_Pinpack_1)
      RCC_APB2PeriphClockCmd (RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOA, ENABLE);
    else
      RCC_APB2PeriphClockCmd (RCC_APB2Periph_USART1 | RCC_APB2Periph_GPIOB, ENABLE);
    USART1_InitPins (pinpack);
  }
  else if (USARTx == USART2)
  {
    RCC_APB1PeriphClockCmd (RCC_APB1Periph_USART2 | RCC_APB2Periph_GPIOA, ENABLE);
    USART2_InitPins (pinpack);
  }
  else if (USARTx == USART3)
  {
    RCC_APB1PeriphClockCmd (RCC_APB1Periph_USART3 | RCC_APB2Periph_GPIOB, ENABLE);
    USART3_InitPins (pinpack);
  }

  USART_DeInit (USARTx);
  // Baud rate 9600, 8-bit data, One stop bit
  // No parity, Do both Rx and Tx, No HW flow control
  usart.USART_BaudRate = Baudrate;
  usart.USART_WordLength = USART_WordLength_8b;
  usart.USART_StopBits = USART_StopBits_1;
  usart.USART_Parity = USART_Parity_No;
  usart.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  usart.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_Init (USARTx, &usart);

  //USART_LINCmd (USARTx, DISABLE);

  // Enable USART2 global interrupt
  if (USARTx == USART1)
    aNVIC.NVIC_IRQChannel = USART1_IRQn;
  else if (USARTx == USART2)
    aNVIC.NVIC_IRQChannel = USART2_IRQn;
  else if (USARTx == USART3)
    aNVIC.NVIC_IRQChannel = USART3_IRQn;
  aNVIC.NVIC_IRQChannelPreemptionPriority = 0;
  aNVIC.NVIC_IRQChannelSubPriority = 0;
  aNVIC.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init (&aNVIC);

  // Enable USART
  USART_Cmd (USARTx, ENABLE);
  // Enable RXNE interrupt */
  USART_ITConfig (USARTx, USART_IT_RXNE, ENABLE);
}

void UsartSend (USART_TypeDef *USARTx, char *ptext)
{
  char *p = ptext;
  while (*p)
  {
    while (USART_GetFlagStatus (USARTx, USART_FLAG_TXE) == RESET)
       ;
    USART_SendData (USARTx, *p++);
  }
}

void UsartWrtBuf (USART_TypeDef *USARTx, uint8_t *pbuf, uint8_t len)
{
  for (uint8_t i = 0; i < len; i++)
  {
    while (USART_GetFlagStatus (USARTx, USART_FLAG_TXE) == RESET)
       ;
    uint16_t buf = *pbuf++;
    USART_SendData (USARTx, buf);
  }
}

void USART1_IRQHandler (void)
{
  if ((USART1->SR & USART_FLAG_RXNE) != RESET)
  {
    char c = USART_ReceiveData (USART1);
    Usart1ReceiveCallBack (c);
  }
}

void USART2_IRQHandler (void)
{
  if ((USART2->SR & USART_FLAG_RXNE) != RESET)
  {
    char c = USART_ReceiveData (USART2);
    Usart2ReceiveCallBack (c);
  }
}

void USART3_IRQHandler (void)
{
  if ((USART3->SR & USART_FLAG_RXNE) != RESET)
  {
    char c = USART_ReceiveData (USART3);
    Usart3ReceiveCallBack (c);
  }
}
