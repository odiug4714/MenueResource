#include "Buttons_LEDs.h"
#include "myGPIO.h"

void InitLED (HLED_t *HLED, GPIO_TypeDef *Port, uint16_t Pin, uint8_t active)
{
  HLED->Port = Port;
  HLED->Pin = Pin;
  HLED->active = active;
  PIO_Init (Port, Pin, GPIO_Mode_Out_PP, GPIO_Speed_10MHz);
  LEDAus (HLED);
}

void LEDAn (HLED_t *HLED)
{
  if (HLED->active == cLEDBut_ActiveHigh)
    GPIO_SetBits (HLED->Port, HLED->Pin);
  else
    GPIO_ResetBits (HLED->Port, HLED->Pin);
}

void LEDAus (HLED_t *HLED)
{
  if (HLED->active == cLEDBut_ActiveLow)
    GPIO_SetBits (HLED->Port, HLED->Pin);
  else
    GPIO_ResetBits (HLED->Port, HLED->Pin);
}

void SetLED (HLED_t *HLED, uint8_t anaus)
{
  if (anaus)
    LEDAn (HLED);
  else
    LEDAus (HLED);
}

uint8_t IsLEDAn (HLED_t *HLED)
{
  if (HLED->active == cLEDBut_ActiveHigh)
    return GPIO_ReadOutputDataBit (HLED->Port, HLED->Pin) != 0;
  return GPIO_ReadOutputDataBit (HLED->Port, HLED->Pin) == 0;
}

void LEDToggle (HLED_t *HLED)
{
  if (IsLEDAn (HLED))
    LEDAus (HLED);
  else
    LEDAn (HLED);
}

void InitButton (HButton_t *HBut, GPIO_TypeDef *Port, uint16_t Pin, uint8_t active)
{
  HBut->Port = Port;
  HBut->Pin = Pin;
  HBut->active = active;
  PIO_Init (Port, Pin, GPIO_Mode_IPU, GPIO_Speed_10MHz);
}

uint8_t ButtonPressed (HButton_t *HBut)
{
  if (HBut->active == cLEDBut_ActiveHigh)
    return GPIO_ReadOutputDataBit (HBut->Port, HBut->Pin) != 0;
  return GPIO_ReadOutputDataBit (HBut->Port, HBut->Pin) == 0;
}

