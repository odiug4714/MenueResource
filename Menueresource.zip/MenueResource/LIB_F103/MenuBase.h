//----------------------------------------------------------------------------
// MenuBase.h  Autor: Guido Kahle 06/2017
//----------------------------------------------------------------------------
#ifndef _MenuBase_h
#define _MenuBase_h

#include "basedefs.h"
#include "font.h"

#define cNoSoftkey       0xff       // no SK pressed
#define cDefSleepTime    30         // Menu-Sleep-Time (x 10ms)

// Softkey timing
#define cSWTimSKRepeat   40         // Softkey-Repeat (x 10ms)
#define cSWTimSKRepDiv   3          // Softkey-Repeat-Speedup
#define cSWTimSKDblClick 40         // Softkey-Doubleclick
#define cSWTimSKTimeout  200        // Softkey-Timeout (x 10ms)

// Softkey options
#define cSKNoOpts        0          // no options SK is shown cyclic editing is not possible
#define cSKFrame         0x0001     // SK with frame
#define cSKDoubleFrame   0x0002     // SK with double frame
#define cSKSelectable    0x0004     // SK is selecteble
#define cSKValue         0x0008     // SK can be edited
#define cSKReserved1     0x0010     // reserved for later use
#define cSKScrollable    0x0020     // SK is scrollable
#define cSKExit          0x0040     // SK is menue-exit-key
#define cSKPlus          0x0080     // SK is plus- key
#define cSKMinus         0x0100     // SK is minus- key
#define cSKMultiply      0x0200     // SK is multiplier-key (1,10,100, 1000)
#define cSKConcealable   0x0400     // SK is concealable
#define cSKZykVal        0x0800     // edit the SK value cyclic: Max -> Min and Min -> Max overrun
#define cSKSwitch        0x1000     // SK is enabled
#define cSKDblClick      0x2000     // SK can be double klicked
#define cSKTimeout       0x4000     // SK must be pressed a small amount of time
#define cSKRepeat        0x8000     // SK repeats continuously while pressed

// internal Softkey flags
#define cISKNoFlags      0
#define cISKSwitched     0x0001     // SK is swiched on or off
#define cISKInverse      0x0002     // SK is shown inverse
#define cISKEnabled      0x0004     // SK is enabled
#define cISKTipped       0x0008     // shows the SK inverse while touched

// Menu-Footer
#define cBottomLine     220         // position where footer starts

// Menu-Timers
#define cTimerSKRepeat  0           // timer if touchpanel is hold
#define cTimerDblClick  1           // timer f. double stroke recognition
#define cTimerReserve3  2           // reserved all other timers start with index 3

// Menue color indices
#define cMaxMenuColors  9

#define cMenuPen        0
#define cMenuBackGnd    1
#define cMenuTitle      2
#define cMenuTitleBG    3
#define cMenuSubLine    4
#define cMenuSubLineBG  5
#define cMenuFramePen   6
#define cMenuBarPen     7
#define cMenuSliderPen  8

// Menue-Layouts
#define cMenuPen1       YELLOW
#define cMenuBackGnd1   BLUE
#define cMenuTitle1     YELLOW
#define cMenuTitleBG1   RED
#define cMenuSubLine1   YELLOW
#define cMenuSubLineBG1 RED
#define cMenuFramePen1  BLACK
#define cMenuBarPen1    YELLOW
#define cMenuSliderPen1 YELLOW

#define cMenuPen2       BLACK
#define cMenuBackGnd2   LYELLOW
#define cMenuTitle2     WHITE
#define cMenuTitleBG2   BLUE
#define cMenuSubLine2   WHITE
#define cMenuSubLineBG2 DARKRED
#define cMenuFramePen2  BLACK
#define cMenuBarPen2    DARKGREEN
#define cMenuSliderPen2 BLUE

#define cMenuPen3       WHITE
#define cMenuBackGnd3   BLACK
#define cMenuTitle3     WHITE
#define cMenuTitleBG3   RED
#define cMenuSubLine3   WHITE
#define cMenuSubLineBG3 DARKRED
#define cMenuFramePen3  BLUE
#define cMenuBarPen3    GREEN
#define cMenuSliderPen3 BLUE

#define cMenuPen4       BLACK
#define cMenuBackGnd4   WHITE
#define cMenuTitle4     WHITE
#define cMenuTitleBG4   DARKRED
#define cMenuSubLine4   WHITE
#define cMenuSubLineBG4 RED
#define cMenuFramePen4  BLACK
#define cMenuBarPen4    LIGHTGREEN
#define cMenuSliderPen4 LIGHTBLUE

// options f. tBar: high byte = options,
// low byte upper nibble: vk, low byte lower nibble: nk
#define cObjNoOpts      0
#define cBarOptShowVal  0x0100 // show value and bar
#define cBarHidden      0x0200 // bar is hidden and disabled
#define cBarOptTxtZoom2 0x0400 // zoom x 2
#define cBarOptTxtInBar 0x0800 // draw Text in the bar (only horizontal)
#define cBarOptHor      0x1000 // horizontal bar
#define cBarOptScroll   0x2000 // bar is scrollbar
#define cBarOptfirstDrw 0x4000 // internal first draw flag
#define cBarOptRedraw   0x8000 // internal redraw flag

// Options f. LED
#define cLEDSquare      0x01   // square / round shape
#define cLEDfirstDraw   0x40   // internal first draw flag


typedef struct             // Softkey descriptor
{
  tStr        Text,        // Softkey text
              VarStr;      // values shown as text separated by a colon
  uns16       PosX,        // X- and Y-Koordinate upper left
              PosY,
              Options,     // options
              Width,       // frame dimensions
              Height,
              format;      // format of Var conversion
  uns8        zoom,        // zoom of text
              font,        // font number
              VarIdx,      // variable index on Vars []
              flags;       // internal options
} tSoftKey;


typedef struct             // Valuebar descriptor
{
  uns16       PosX,        // X- and Y-Koordinate upper left
              PosY,
              Width,       // frame dimensions
              Height,
              Options;     // options
  uns8        VarIdx;      // variable index on Vars []
  int32       VarOld;      // old value for comparison
} tValueBar;


typedef struct             // Slider descriptor
{
  tValueBar   *pVB;        // Valuebar Handle
  int16       Position,    // Slider position
              OldPos;      // old Sliderposition
} tSlider;


typedef struct             // LED descriptor
{
  uns16       PosX,        // X- and Y-Koordinate upper left
              PosY;
  uns8        Rad,         // Radius
              Opts,        // options
              VarIdx,      // variable index on Vars []
              BitNr;       // BitNr in variable
} tLED;


/*
//----------------------------------------------------------------------------
// Summary Doku Menue-Interpreter (SK = Softkey)
//----------------------------------------------------------------------------
M:             // menue item
T:             // menu title
O:             // menue options
X              // XPos SK text
X2             // XPos value or objekt, 2. YPos f. line
Y              // YPos
Y2             // 2. YPos f. line
H              // element height
W              // element width
FM             // format of value
CA             // menue calls another menu
TY=0           // SK is text a.\ o. value that can be edited (see options)
  =1           // object LED
  =2           // object Valuebar
  =3           // object Slider
  =4           // SK is a value and can only be shown cyclic not edited
  =5           // string
  =6           // line
  =7           // big line (only horizontal amd vertical)
  =8           // rect
  =9           // circle
  =10          // sk is button
  =12          // menue is a message box (title)
  =13          // filled rect
  =14          // filled circle
CO             // object color
ZO             // zoom for texts and values
FO             // font number for texts and values
BN             // bitno. variable is seen as bitfield
<Msg>          // text placeholder f. messagebox
SO             // SK options
OO             // object options (LED, Valuebar, Slider)
TX             // SK values chose these text strings
//----------------------------------------------------------------------------
*/

// default menue paras related to font2 and zoom = 2
#define cstdfont       cFont2
#define cstdzoom       2
#define cYHeader       (cZH2Max * cstdzoom  * cstdzoom + 3)
#define cYLine         (cZH2Max * cstdzoom + cZH2Max - 1)
#define cScrollHeight  6 * cYLine // 6 items in scrollarea with std. font 2
#define cScrollWidth   285

// Object types
#define cNoObjTyp      0xff
#define cObjTypSKVal   0
#define cObjTypLED     1
#define cObjTypVBar    2
#define cObjTypSlider  3
#define cObjTypSKShow  4
#define cObjTypString  5
#define cObjTypLine    6
#define cObjTypBigLine 7
#define cObjTypRect    8
#define cObjTypCircle  9
#define cObjTypSKKey   10
#define cObjTypTitle   11     // internal
#define cObjTypMsgBox  12
#define cObjTypFRect   13
#define cObjTypFCircle 14

// Menue-Ressource constants
#define cMaxElemBuf    2048  // Memory for menue management !!!

// internal menue callback-call-positions
typedef enum  { eOnStart, eOnZyk, eOnPlus, eOnMinus, eOnItem, eOnEnd } tCBCallMode;

// CallBack-function-type
typedef void (*tCBFunc)(void*, tCBCallMode, uns8);


typedef struct             // Menue-Ressource-Helper
{
  void  *ptr;              // Memory management Objects
  uns8  typ,               // Object type
        skidx,             // Softkey index
        bitnr;             // bitnr if Var is a bitfield
  tStr  callname;          // Menu to call
  uns16 X2,                // X Koord for value
        color;             // object color
} tObjPtr;


typedef struct             // Menue-Ressource-Lookuptable-Entry
{
  const char *pMenuName;   // Menu title name
  const char *pMenueRes;   // resource string
  tCBFunc pCBfunc;         // Callback function for special menue actions
} tMRLT;


typedef struct                           // Menue-Handle
{
  tSoftKey *SoftKeys;                    // Softkey array (ElemBuf)
  uns8     *ObjBuf,                      // Objects to interpret (ElemBuf)
           *CallStack;                   // Stack for nested menue calls (ElemBuf)
  tObjPtr  *ObjPtrBuf;                   // Object helpers (ElemBuf)
  tCBFunc  *CBfuncs;                     // callback function table  (ElemBuf)
  const tMRLT *pMRLT;                    // resource table entry
  tStr     MsgBoxStr;                    // str for msgbox
  uns16    YHeader,                      // header distance
           YLine,                        // Line distance
           ScrollHeight,                 // height scrolling area
           ScrollWidth,                  // width scrolling aerea
           NumSoftKeys,                  // nr. of sks for mem allocation (ElemBuf)
           ObjBufSize,                   // control buffer size for mem allocation (ElemBuf)
           NumObjPtrs,                   // nr. of obj helpers for mem allocation (ElemBuf)
           MenuStartIndex,               // index for the whole menu management (ElemBuf)
           MenuElemIndex;                // index for all menue elements (ElemBuf)
  uns8     CurrMenuIndex,                // menu index to current menue
           LayoutNr,                     // nr. of layout table
           ScrollVarIdx,                 // index f. scroll variable
           SelectedSK,                   // current selected SK
           PrevSelectedSK,               // previous selected SK used by messagebox
           ExitSK,                       // Softkey pressed when menu exited
           HideConcealableSKs,           // concealable SKs are disabled and hidden
           firstDraw,                    // init menues first draw
           MenuCnt;                      // nr of menues
  uns32    dummy;                        // force allignment f. ElemBuf
  uns8     ElemBuf [cMaxElemBuf];        // mem management
} tMenuHandle;


// basic functions
void  MenuBaseInit (void);
uns16 GetCol (uns8 ColIndex);
uns16 GetMultiplier (void);
uns8  IsSwitched (uns8 SKNr);
void  SetSwitched (uns8 SKNr, uns8 onoff);
void  EnableSK (uns8 SKNr);
void  DrawSoftKey (uns8 SKNr);
void  ClrSoftkey (uns8 SKNr);
uns8  SoftkeyPressed (void);
void  SetSKText (uns8 SKNr, tStr Text);
void  MenuClear (void);
void  MenuHeader (tStr Txt, uns8 zoom, uns8 fontno);
void  ShowValueItem (uns8 SKNr);
void  MakeSKVar (uns8 SKNr, uns8 VarIndex, uns16 format);
void  MakeSoftKey (uns8 SKNr, tStr Txt, uns16 x, uns16 y, uns8 zoom, uns8 font, uns16 opt);
void  UpdateMenuValue (uns8 SKNr, int16 fak, uns8 doZyk);
void  SelectSK (uns8 SKNr, uns8 LastSKey);
void  InitMenuLED (tLED *pLED, uns16 x, uns16 y, uns16 r, uns8 VarIndex, uns8 Opts, uns8 BitNr);
void  DrawMenuLED (tLED *pLED, uns16 color);
void  InitValueBar (tValueBar *pVB, uns16 x, uns16 y, uns16 w, uns16 h, uns8 VarIndex, uns16 Opts);
void  ShowValueBar (tValueBar *pVB, uns16 color);
void  InitSlider (tSlider *pSL, tValueBar *pVB);
void  UpdateSlider (tSlider *pSL, uns16 color);
void  ShowSLider (tSlider *pSL, uns16 color);

// menue handler functions
tMenuHandle* GetMenuHandle (void);
void  InitMenuResInterpreter (tMenuHandle *pMH);
uns8  GetMenuIndex (tMenuHandle *pMH);
uns8  GetSelectedSK (tMenuHandle *pMH);
uns8  SKFromVarIndex (tMenuHandle *pMH, uns8 VarIndex);
uns8  SKFromName (tMenuHandle *pMH, const char *pStr);
uns8  ObjPtrIndexFromVarIndex (tMenuHandle *pMH, uns8 VarIndex);
void  InitMenuRessources (tMenuHandle *pMH);
uns8  ShowMsgBox (tMenuHandle *pMH, const char *pBoxName, const char *pMsgStr);
void  MenuResourceInterpreter (tMenuHandle *pMH, tStr MenuName);
void  MenuHandler (tMenuHandle *pMH, tStr MenuName);

// value menagement callback functions,
// menubase module is a library module and has to be
// independant from userdefined Vars, overwrite these funcs
__weak int32 GetVal        (uns8 index);
__weak void  SetVal        (uns8 index, int32 Val);
__weak void  SetValChanged (uns8 index, uns8 changed);
__weak uns8  ValChanged    (uns8 index);
__weak int32 GetValMin     (uns8 index);
__weak void  SetValMin     (uns8 index, int32 Val);
__weak int32 GetValMax     (uns8 index);
__weak void  SetValMax     (uns8 index, int32 Val);
__weak uns8  GetValBitNr   (uns8 index);
__weak void  SetValBitNr   (uns8 index, uns8 bitnr);
__weak uns8  ValBitChanged (uns8 index, uns8 bitnr);
__weak uns8  ValBitSet     (uns8 index, uns8 bitnr);
__weak void  SetValBit     (uns8 index, uns8 bitnr, uns8 bitval);

__weak void MenuSleep (uns16 ms);   // callback func: task synchronisation RTOS
__weak void ResetSleepTimer (void); // callback func: reset  timer by user key press

#endif
