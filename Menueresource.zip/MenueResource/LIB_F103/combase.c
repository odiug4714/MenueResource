#include "stm32f10x_conf.h"
#include "combase.h"

void base64_enc (uint8_t *pdata)
{
  pdata [3] = pdata [2] & 0x3f;
  pdata [2] = ((pdata [2] & 0xc0) >> 6) | ((pdata [1] & 0x0f) << 2);
  pdata [1] = ((pdata [1] & 0xf0) >> 4) | ((pdata [0] & 0x03) << 4);
  pdata [0] = ((pdata [0] & 0xfc) >> 2);
  for (uint8_t i = 0; i < 4; i++)
  {
    if (pdata [i] >= 0 && pdata [i] <= 25)
      pdata [i] += 'A';
    else if (pdata [i] >= 26 && pdata [i] <= 51)
      pdata [i] += 'a' - 26;
    else if (pdata [i] >= 52 && pdata [i] <= 61)
      pdata [i] += '0' - 52;
    else if (pdata [i] == 62)
      pdata [i] = '+';
    else if (pdata [i] == 63)
      pdata [i] = '/';
  }
}


void base64_dec (uint8_t *pdata)
{
  for (uint8_t i = 0; i < 4; i++)
  {
    if (pdata [i] >= 'A' && pdata [i] <= 'Z')
      pdata [i] -= 'A';
    else if (pdata [i] >= 'a' && pdata [i] <= 'z')
      pdata [i] -= 0x47;
    else if (pdata [i] >= '0' && pdata [i] <= '9')
      pdata [i] += 4;
    else if (pdata [i] == '+')
      pdata [i] = 62;
    else if (pdata [i] == '/')
      pdata [i] = 63;
  }
  pdata [0] = ((pdata [1] & 0x30) >> 4) | ((pdata [0] & 0x3f) << 2);
  pdata [1] = ((pdata [2] & 0x3c) >> 2) | ((pdata [1] & 0x0f) << 4);
  pdata [2] = pdata [3] | ((pdata [2] & 0x03) << 6);
}

uint8_t EncodeMsg (uint8_t cmd, int32_t data, uint8_t *pMsgBuf)
{
  uint8_t *p = pMsgBuf, b;
  if (! (cmd & 0x80))
    return 0;
  CRC_ResetDR ();
  uint32_t crc = CRC_CalcCRC (cmd);
  *p++ = cmd;
  for (uint8_t i = 0; i < 4; i++)
  {
    b = (uint8_t) data;
    crc = CRC_CalcCRC (b);
    if (i == 3)
      p++;
    *p++ = b;
    data >>= 8;
  }
  *p++ = (uint8_t) (crc & 0x7f);
  *p++ = (uint8_t) ((crc >> 8) & 0x7f);
  *p = 0;
  p = pMsgBuf;
  base64_enc (p + 1);
  base64_enc (p + 5);
  return cMsgBufItems;
}

uint8_t DecodeMsg (uint8_t *pcmd, int32_t *pdata, uint8_t *pMsgBuf)
{
  uint8_t *p = pMsgBuf;
  if (! (*p & 0x80))
    return 0;
  *pcmd = *p;
  *pdata = 0;
  CRC_ResetDR ();
  uint32_t crc = CRC_CalcCRC (*p++),
           data;
  base64_dec (p);
  base64_dec (p + 4);
  for (uint8_t i = 0; i < 4; i++)
  {
    if (i == 3)
      p++;
    data = *p++;
    crc = CRC_CalcCRC (data);
    *pdata |= data << i * 8;
  }
  uint8_t ok = (*p == (crc & 0x7f)) && (*(p + 1) == ((crc >> 8) & 0x7f));
  return ok;
}

uint8_t EncodeCmdMsg (uint8_t cmd, uint8_t *pMsgBuf)
{
  uint8_t *p = pMsgBuf, b;
  if (! (cmd & 0x80))
    return 0;
  CRC_ResetDR ();
  uint32_t crc = CRC_CalcCRC (cmd);
  *p++ = cmd;
  *p++ = (uint8_t) (crc & 0x7f);
  return cCmdBufItems;
}

uint8_t DecodeCmdMsg (uint8_t *pMsgBuf)
{
  uint8_t *p = pMsgBuf;
  uint8_t cmd = *p++,
          acrc = *p;
  if (! (cmd & 0x80))
    return cNoCmd;
  CRC_ResetDR ();
  uint32_t crc = CRC_CalcCRC (cmd);
  if (acrc == (crc & 0x7f))
    return cmd;
  return cNoCmd;
}
