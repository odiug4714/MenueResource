#include "myGPIO.h"

uint16_t PIO_GetPinSource (uint16_t GPIO_Pin)
{
  uint16_t pinsource = 0;

  while (GPIO_Pin > 1)
  {
    pinsource++;
    GPIO_Pin >>= 1;
  }
  return pinsource;
}

uint16_t PIO_GetPortSource (GPIO_TypeDef* GPIOx)
{
  return ((uint32_t)GPIOx - (GPIOA_BASE)) / ((GPIOB_BASE) - (GPIOA_BASE));
}

static void PIO_EnableClock (GPIO_TypeDef* GPIOx)
{
  if (GPIOx == GPIOA)
    RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOA, ENABLE);
  if (GPIOx == GPIOB)
    RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOB, ENABLE);
  if (GPIOx == GPIOC)
    RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOC, ENABLE);
}

static void PIO_DisableClock (GPIO_TypeDef* GPIOx)
{
  if (GPIOx == GPIOA)
    RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOA, DISABLE);
  if (GPIOx == GPIOB)
    RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOB, DISABLE);
  if (GPIOx == GPIOC)
    RCC_APB2PeriphClockCmd (RCC_APB2Periph_GPIOC, DISABLE);
}

void PIO_Init (GPIO_TypeDef* GPIOx, uint16_t GPIO_Pin, GPIOMode_TypeDef GPIO_Mode, GPIOSpeed_TypeDef GPIO_Speed)
{
  GPIO_InitTypeDef Port;

  PIO_EnableClock (GPIOx);
  if (GPIO_Mode == GPIO_Mode_AF_OD || GPIO_Mode == GPIO_Mode_AF_PP || GPIO_Mode == GPIO_Mode_IN_FLOATING)
    RCC_APB2PeriphClockCmd (RCC_APB2ENR_AFIOEN, ENABLE);
  Port.GPIO_Pin = GPIO_Pin;
  Port.GPIO_Mode = GPIO_Mode;
  Port.GPIO_Speed = GPIO_Speed;
  GPIO_Init (GPIOx, &Port);
}
