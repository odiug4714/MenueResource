//----------------------------------------------------------------------------
// MenuBase.c  Autor: Guido Kahle 06/2017
//----------------------------------------------------------------------------
#include "MenuBase.h"
#include "LCD.h"
#include "Touch.h"


extern void UsartWrite (char *ptext); // Debug
extern void MenuSleep (uns16 ms);     // sysnchronises LCD access

static const char StrSKMult1 []    = "x 1 ",
                  StrSKMult10 []   = "x10 ",
                  StrSKMult100 []  = "x100",
                  StrSKMult1000 [] = "x1000",
                  StrMemOvl []     = "Menu Memory OVL",
                  StrErrNoMenu []  = "Menue not found";

typedef struct         // Menueinterpreter variables (private)
{
  uns8  first,         // koord management
        finterpret,    // pass1: count elements for mem alloc, pass2: interpret elements
        itemTyp,       // element type to interpret
        skcnt,         // SK index
        bitnr,         // bitnr of var-bitfield
        Y2XYWHproged,  // user programmed Y2,X,Y,H,W theese values overwrite calulated values
        defscrollofs,  // scroll management
        scrollofs,
        zoomdef,       // zoom management
        zoom,
        fontnrdef,     // font management
        fontnr;
  int8  callnr;        // index of callback function
  uns16 opt,
        X,             // koords
        X2,
        Y,
        Y2,
        r,            // object radius
        W,            // object width
        H,            // object height
        color,        // object color
        objopts,      // options of LEDs, valuebars and sliders
        ObjPtrIdx,    // objectptr index
        ObjPtrBufOfs, // object offset in element buffer
        format;       // presentation format of number
  int32 vi;           // current user programmed value
  tStr  vartxt,       // alternative programmed text replacing values
        menuname;     // menu to call
} tMIVars;

//----------------------------------------------------------------------------
// global variables
//----------------------------------------------------------------------------
static tMenuHandle MenuHandle,           // Handle for menue management
                   *pMH = &MenuHandle;
static uns8  CurrSK = cNoSoftkey,        // current SK pressed
             LastSK = cNoSoftkey,        // last SK pressed (Doubleclick)
             SKRepeatSpeed;              // speed Softkey-Repeat
static uns16 SKTouchCnt,                 // Softkeys: nr. of valid consecutively touch points
             SKTimeout,                  // Softkeys: Timeout (key hold)
             Multiplier = 1;             // value of Softkey multiplier

static const
uns16 Layout1 [] = { cMenuPen1, cMenuBackGnd1, cMenuTitle1, cMenuTitleBG1, cMenuSubLine1, \
                     cMenuSubLineBG1, cMenuFramePen1, cMenuBarPen1, cMenuSliderPen1 },
      Layout2 [] = { cMenuPen2, cMenuBackGnd2, cMenuTitle2, cMenuTitleBG2, cMenuSubLine2, \
                     cMenuSubLineBG2, cMenuFramePen2, cMenuBarPen2, cMenuSliderPen2 },
      Layout3 [] = { cMenuPen3, cMenuBackGnd3, cMenuTitle3, cMenuTitleBG3, cMenuSubLine3, \
                     cMenuSubLineBG3, cMenuFramePen3, cMenuBarPen3, cMenuSliderPen3 },
      Layout4 [] = { cMenuPen4, cMenuBackGnd4, cMenuTitle4, cMenuTitleBG4, cMenuSubLine4, \
                     cMenuSubLineBG4, cMenuFramePen4, cMenuBarPen4, cMenuSliderPen4 },
      *pLayouts [] = { Layout1, Layout2, Layout3, Layout4 };

//----------------------------------------------------------------------------
// Helpers
//---------------------------------------------------------------------------
static tStr GetMultStr (uns16 multiplier)
{
  tStr s;
  if (multiplier == 1000)
    s = Init_tStr (StrSKMult1000);
  else if (multiplier == 100)
    s = Init_tStr (StrSKMult100);
  else if (multiplier == 10)
    s = Init_tStr (StrSKMult10);
  else
    s = Init_tStr (StrSKMult1);
  return s;
}

uns16 GetMultiplier (void)
{
  return Multiplier;
}

uns16 GetCol (uns8 ColIndex)
{
  if (ColIndex < cMaxMenuColors)
    return *(pLayouts [pMH->LayoutNr ] + ColIndex);
  return 0xffff;
}

//---------------------------------------------------------------------------
// Softkeys
//---------------------------------------------------------------------------
static uns8 SKFlag (uns8 SKNr, uns8 flag)
{
  if (SKNr < pMH->NumSoftKeys)
    return (pMH->SoftKeys [SKNr].flags & flag) > 0;
  return 0;
}

static uns8 PSKFlag (tSoftKey *pSK, uns8 flag)
{
  if (pSK != 0)
    return (pSK->flags & flag) > 0;
  return 0;
}

static uns8 SKOption (uns8 SKNr, uns16 option)
{
  if (SKNr < pMH->NumSoftKeys)
    return (pMH->SoftKeys [SKNr].Options & option) > 0;
  return 0;
}

static uns8 PSKOption (tSoftKey *pSK, uns16 option)
{
  if (pSK != 0)
    return (pSK->Options & option) > 0;
  return 0;
}

uns8 IsSwitched (uns8 SKNr)
{
  if (SKNr < pMH->NumSoftKeys)
    return SKFlag (SKNr, cISKSwitched);
  return 0;
}

void SetSwitched (uns8 SKNr, uns8 onoff)
{
  if (SKNr < pMH->NumSoftKeys)
  {
    tSoftKey *pSK = &pMH->SoftKeys [SKNr];
    if (pSK->Options & cSKSwitch)
    {
      if (onoff)
        pSK->flags |= cISKSwitched;
      else
        pSK->flags &= ~cISKSwitched;
    }
  }
}

void EnableSK (uns8 SKNr)
{
  if (SKNr < pMH->NumSoftKeys)
    pMH->SoftKeys [SKNr].flags |= cISKEnabled;
}

static uns16 DrawInverse (void)
{
  LCD_SetBackCol (~ GetCol (cMenuBackGnd));
  return ~ GetCol (cMenuPen);
}

static uns16 DrawNormal (void)
{
  LCD_SetBackCol (GetCol (cMenuBackGnd));
  return GetCol (cMenuPen);
}

static void ShowVarString (tSoftKey *pSK, uns16 xofs, uns8 fontno, uns16 color)
{
  tStr varstr = pSK->VarStr, str;
  uns8 i = 0;
  while (varstr.len != 0 && i < GetVal (pSK->VarIdx) + 1)
  {
    str = Next_tStr (&varstr, '|');
    i++;
  }
  LCD_ShowString (pSK->PosX + xofs, pSK->PosY, str, pSK->zoom, fontno, color);
}

void ShowValueItem (uns8 SKNr)
{
  if (SKNr < pMH->NumSoftKeys)
  {
    tSoftKey *pSK = &pMH->SoftKeys [SKNr];
    if (PSKOption (pSK, cSKValue))
    {
      uns8  changed = ValChanged (pSK->VarIdx);
      uns16 xofs = 0,
            MenuPenCol = (PSKFlag (pSK, cISKInverse)) ? DrawInverse () : DrawNormal ();
      //if (! PSKOption (pSK, cSKSamePos))
        xofs = LCD_GetTextLen (pSK->Text.len, pSK->zoom, pSK->font) + 4;
      if (pSK->VarStr.pstr != 0 && pSK->VarStr.len > 0)
        ShowVarString (pSK, xofs, pSK->font, MenuPenCol);
      else
      {
        LCD_ShowNum (pSK->PosX + xofs, pSK->PosY, GetVal (pSK->VarIdx), pSK->zoom, pSK->font, pSK->format, MenuPenCol);
        if (changed)  // force change
          SetValChanged (pSK->VarIdx, 1);
      }
      DrawNormal ();
    }
  }
}

static void GetSKTextPos (tSoftKey *pSK, uns16 *px, uns16 *py)
{
  uns16 txtlen = LCD_GetTextLen (pSK->Text.len, pSK->zoom, pSK->font);
  *px = pSK->PosX + (pSK->Width - txtlen) / 2 + 1;
  *py = pSK->PosY + (pSK->Height - LCD_GetOpts ()->ZHMax * pSK->zoom) / 2 + 1;
}

void DrawSoftKey (uns8 SKNr)
{
  if (SKNr < pMH->NumSoftKeys)
  {
    tSoftKey *pSK = &pMH->SoftKeys [SKNr];
    uns16 r = (pSK->Width > pSK->Height) ? pSK->Height >>  2 : pSK->Width >> 2;
    if (pSK->Text.len > 0)
    {
      uns16 x = pSK->PosX, y = pSK->PosY, MenuPenCol;
      if ((PSKOption (pSK, cSKSwitch) && PSKFlag (pSK, cISKSwitched)) ||
          PSKFlag (pSK, cISKInverse) || PSKFlag (pSK, cISKTipped))
        MenuPenCol = DrawInverse ();
      else
        MenuPenCol = DrawNormal ();
      if (PSKOption (pSK, cSKFrame) || PSKOption (pSK, cSKDoubleFrame))
      {
        GetSKTextPos (pSK, &x, &y);
        uns8 d = 0;
        if (PSKOption (pSK, cSKDoubleFrame)) // innerer Rahmen
          d = 1;
        LCD_FillRoundRect (pSK->PosX+d, pSK->PosY+d, pSK->Width-2*d, pSK->Height-2*d, r-d, LCD_GetBackColor ());
      }
      LCD_ShowString (x, y, pSK->Text, pSK->zoom, pSK->font, MenuPenCol);
      DrawNormal ();
    }
    if (PSKOption (pSK, cSKFrame) || PSKOption (pSK, cSKDoubleFrame))
    {
      LCD_DrawRoundRect (pSK->PosX, pSK->PosY, pSK->Width, pSK->Height, r, GetCol (cMenuFramePen));
      if (PSKOption (pSK, cSKDoubleFrame)) // innerer Rahmen
        LCD_DrawRoundRect (pSK->PosX+1, pSK->PosY+1, pSK->Width-2, pSK->Height-2, r-1, GetCol (cMenuFramePen));
    }
    if (PSKOption (pSK, cSKValue))
      ShowValueItem (SKNr);
  }
}

void ClrSoftkey (uns8 SKNr)
{
  if (SKNr < pMH->NumSoftKeys)
  {
    tSoftKey *pSK = &pMH->SoftKeys [SKNr];
    uns8 d = 0;
    if (PSKOption (pSK, cSKFrame))
      d++;
    else if (PSKOption (pSK, cSKDoubleFrame))
      d = 2;
    LCD_Fill (pSK->PosX-d, pSK->PosY-d, pSK->Width+d, pSK->Height+d, LCD_GetBackColor ());
    pSK->flags &= ~cISKEnabled;
  }
}

void SetSKText (uns8 SKNr, tStr Text)
{
  if (SKNr < pMH->NumSoftKeys)
    pMH->SoftKeys [SKNr].Text = Text;
}

static uns8 FindSoftKey (uns16 x, uns16 y)
{
  for (uns8 i = 0; i < pMH->NumSoftKeys; i++)
  {
    tSoftKey *pSK = &pMH->SoftKeys [i];
    if (PSKFlag (pSK, cISKEnabled) && PSKOption (pSK, cSKSelectable) &&
        x >= pSK->PosX && x <= pSK->PosX + pSK->Width &&
        y >= pSK->PosY && y <= pSK->PosY + pSK->Height)
      return i;
  }
  return cNoSoftkey;
}

uns8 SoftkeyPressed (void)
{
  uns16 x, y;

  if (! Touch_Koords (&x, &y))
  {
    CurrSK = cNoSoftkey;
    SKRepeatSpeed = 0;
    SKTimeout = 0;
    SetTimer (cTimerSKRepeat, 0);
    if (LastSK != cNoSoftkey && SKFlag (LastSK, cISKEnabled) &&
        ! SKOption (LastSK, cSKSwitch) && ! SKOption (LastSK, cSKValue))
    {
      pMH->SoftKeys [LastSK].flags &= ~cISKTipped;
      DrawSoftKey (LastSK);
    }
    if (TimerExpired (cTimerDblClick, 0))
    {
      LastSK = cNoSoftkey;
      SKTouchCnt = 0;
    }
    else if (SKTouchCnt == 1)
      SKTouchCnt = 2;
  }
  else if (SKTouchCnt == 0)
  {
    ResetSleepTimer ();          // SK stroke resets sleeptimer
    CurrSK = FindSoftKey (x, y);
    if (CurrSK == cNoSoftkey)
      return cNoSoftkey;
    LastSK = CurrSK;
    if (! SKOption (CurrSK, cSKSwitch) && ! SKOption (CurrSK, cSKValue))
    {
      pMH->SoftKeys [CurrSK].flags |= cISKTipped;
      DrawSoftKey (CurrSK);
    }
    if (SKOption (CurrSK, cSKTimeout))
    {
      if (SKTimeout == 0)
      {
        SetTimer (cTimerSKRepeat, cSWTimSKTimeout);
        SKTimeout = 1;
      }
      else if (SKTimeout == 1 && TimerExpired (cTimerSKRepeat, cSWTimSKTimeout))
      {
        SKTimeout = 2;
        return CurrSK;
      }
      return cNoSoftkey;
    }
    else
    {
      SKTouchCnt = 1;
      if (SKOption (CurrSK, cSKDblClick))
      {
        SetTimer (cTimerDblClick, cSWTimSKDblClick);
        return cNoSoftkey;
      }
      SetTimer (cTimerSKRepeat, cSWTimSKRepeat);
    }
  }
  else
  {
    if (SKTouchCnt == 2 && LastSK != cNoSoftkey && SKOption (LastSK, cSKDblClick))
    {
      uns8 SKey = FindSoftKey (x, y);
      if (SKey == LastSK)
        return SKey;
      return cNoSoftkey;
    }
    else if (SKTouchCnt >= 1 && CurrSK != cNoSoftkey &&
             ! SKOption (CurrSK, cSKDblClick) && ! SKOption (CurrSK, cSKTimeout))
    {
      if (! (SKOption (CurrSK, cSKPlus) || SKOption (CurrSK, cSKMinus) || SKOption (CurrSK, cSKRepeat)))
      {
        CurrSK = cNoSoftkey;
        return cNoSoftkey;
      }
      else if (TimerExpired (cTimerSKRepeat, 0))
      {
        SetTimer (cTimerSKRepeat, cSWTimSKRepeat - SKRepeatSpeed);
        if (SKRepeatSpeed + cSWTimSKRepDiv < cSWTimSKRepeat - cSWTimSKRepeat / cSWTimSKRepDiv)
          SKRepeatSpeed += cSWTimSKRepDiv;
      }
      else
        return cNoSoftkey;
    }
    else
      return cNoSoftkey;
  }
  if (SKTouchCnt == 1)
  {
    if (SKOption (CurrSK, cSKSwitch))
    {
      if (SKFlag (CurrSK, cISKSwitched))
        pMH->SoftKeys [CurrSK].flags &= ~cISKSwitched;
      else
        pMH->SoftKeys [CurrSK].flags |= cISKSwitched;
      DrawSoftKey (CurrSK);
    }
    else if (SKOption (CurrSK, cSKMultiply))
    {
      if (Multiplier == 1)
        Multiplier = 10;
      else if (Multiplier == 10)
        Multiplier = 100;
      else if (Multiplier == 100)
        Multiplier = 1000;
      else
        Multiplier = 1;
      pMH->SoftKeys [CurrSK].Text = GetMultStr (Multiplier);
      DrawSoftKey (CurrSK);
    }
  }
  return CurrSK;
}

void SelectSK (uns8 SKNr, uns8 LastSKey)
{
  if (LastSKey < pMH->NumSoftKeys)
  {
    pMH->SoftKeys [LastSKey].flags &= ~cISKInverse;
    DrawSoftKey (LastSKey);
  }
  if (SKNr < pMH->NumSoftKeys)
  {
    pMH->SoftKeys [SKNr].flags |= cISKInverse;
    DrawSoftKey (SKNr);
    pMH->SelectedSK = SKNr;
  }
}

//----------------------------------------------------------------------------
// Menues
//----------------------------------------------------------------------------
void UpdateMenuValue (uns8 SKNr, int16 fak, uns8 doZyk)
{
  if (SKNr < pMH->NumSoftKeys)
  {
    tSoftKey *pSK = &pMH->SoftKeys [SKNr];
    int32    v = GetVal (pSK->VarIdx) + fak,
             vmin = GetValMin (pSK->VarIdx),
             vmax = GetValMax (pSK->VarIdx);
    uns8     bitnr = GetValBitNr (pSK->VarIdx);
    if (bitnr == 0)                            // normal var
    {
      if (doZyk)
        v = MinMaxValZyk (v, vmin, vmax);
      else
        v = MinMaxVal (v, vmin, vmax);
      SetVal (pSK->VarIdx, v);
    }
    else                                       // bitfield
      SetValBit (pSK->VarIdx, bitnr, fak > 0);
  }
}

void MakeSoftKey (uns8 SKNr, tStr Txt, uns16 x, uns16 y, uns8 zoom, uns8 font, uns16 opt)
{
  if (SKNr < pMH->NumSoftKeys)
  {
    tSoftKey *pSK = &pMH->SoftKeys [SKNr];
    pSK->Text = Txt;
    pSK->PosX = x;
    pSK->PosY = y;
    pSK->Width = LCD_GetTextLen (Txt.len, zoom, font);
    pSK->Height = zoom * LCD_GetOpts ()->ZHMax;
    pSK->Options = opt;
    pSK->flags = cISKEnabled;
    pSK->VarStr.pstr = 0;
    pSK->VarStr.len = 0;
    pSK->zoom = zoom;
    pSK->font = font;
    pSK->VarIdx = 0;
    pSK->format = 0x20;
  }
}

void MakeSKVar (uns8 SKNr, uns8 VarIndex, uns16 format)
{
  if (SKNr < pMH->NumSoftKeys)
  {
    tSoftKey *pSK = &pMH->SoftKeys [SKNr];
    pSK->VarIdx = VarIndex;
    pSK->VarStr.pstr = 0;
    pSK->VarStr.len = 0;
    pSK->format = format;
  }
}

void MenuClear (void)
{
  LCD_Fill (0, 0, LCD_GetOpts ()->width-1, cBottomLine-1, LCD_GetBackColor ());
}

void MenuHeader (tStr Txt, uns8 zoom, uns8 fontno)
{
  if (Txt.len > 0)
  {
    LCD_SetBackCol (GetCol (cMenuTitleBG));
    LCD_Fill (70, 0, 180, 24, LCD_GetBackColor ());
    LCD_ShowString ((LCD_GetOpts ()->width - LCD_GetTextLen (Txt.len, zoom, fontno)) / 2, 5, Txt, zoom, fontno, GetCol (cMenuTitle));
    LCD_SetBackCol (GetCol (cMenuBackGnd));
  }
}

//----------------------------------------------------------------------------
// LED object
//----------------------------------------------------------------------------
void InitMenuLED (tLED *pLED, uns16 x, uns16 y, uns16 r, uns8 VarIndex, uns8 Opts, uns8 BitNr)
{
  pLED->PosX = x;
  pLED->PosY = y;
  pLED->Rad = r;
  pLED->Opts = Opts | cLEDfirstDraw;
  pLED->VarIdx = VarIndex;
  pLED->BitNr = BitNr;
}

void DrawMenuLED (tLED *pLED, uns16 color)
{
  uns8 changed = (pLED->BitNr > 0 && ValBitChanged (pLED->VarIdx, pLED->BitNr)) ||
                 (pLED->BitNr == 0 && ValChanged (pLED->VarIdx));
  if (pLED->Opts & cLEDfirstDraw || changed)
  {
    LCDOptions_t *pLO = LCD_GetOpts ();
    if (pLED->PosX + pLED->Rad + 1 < pLO->width && pLED->PosY + pLED->Rad + 1 < pLO->height)
    {
      uns16 pencolor = GetCol (cMenuPen);
      if ((pLED->BitNr > 0 && ! ValBitSet (pLED->VarIdx, pLED->BitNr)) ||
          (pLED->BitNr == 0 && GetVal (pLED->VarIdx) == 0))
        color = LCD_GetBackColor ();
      if (pLED->Opts & cLEDSquare)
      {
        LCD_DrawRect (pLED->PosX, pLED->PosY, pLED->Rad, pLED->Rad, pencolor);
        LCD_Fill (pLED->PosX+1, pLED->PosY+1, pLED->Rad-2, pLED->Rad-2, color);
      }
      else
      {
        LCD_DrawCircle (pLED->PosX+pLED->Rad, pLED->PosY+pLED->Rad, pLED->Rad, pencolor);
        LCD_FillCircle (pLED->PosX+pLED->Rad, pLED->PosY+pLED->Rad, pLED->Rad-1, color);
      }
    }
    pLED->Opts &= ~cLEDfirstDraw;
  }
}

//----------------------------------------------------------------------------
// Valuebar object
//----------------------------------------------------------------------------
void InitValueBar (tValueBar *pVB, uns16 x, uns16 y, uns16 w, uns16 h, uns8 VarIndex, uns16 Opts)
{
  pVB->PosX = x;
  pVB->PosY = y;
  pVB->Width = w;
  pVB->Height = h;
  pVB->VarIdx = VarIndex;
  pVB->VarOld = GetValMin (VarIndex);
  pVB->Options = Opts | cBarOptfirstDrw;
}

static void DrawFrame (tValueBar *pVB)
{
  LCDOptions_t *pLO = LCD_GetOpts ();
  if (pVB->PosX+pVB->Width < pLO->width && pVB->PosY+pVB->Height < pLO->height)
  {
    LCD_DrawRect (pVB->PosX, pVB->PosY, pVB->Width, pVB->Height, GetCol (cMenuPen));
    LCD_Fill (pVB->PosX+1, pVB->PosY+1, pVB->Width-2, pVB->Height-2, LCD_GetBackColor ());
  }
}

static int32 VBCalcPos (tValueBar *pVB, int32 val)
{
  int32 vmin = GetValMin (pVB->VarIdx),
        vmax = GetValMax (pVB->VarIdx);
  return ((val - vmin) * ((int32) pVB->Width - 2)) / (vmax - vmin);
}

static void FillVBar (tValueBar *pVB, int32 pos, int32 oldpos, uns16 color1, uns16 color2)
{
  if (pVB->Options & cBarOptHor)
  {
    if (pos > oldpos)
      LCD_Fill (pVB->PosX+oldpos+1, pVB->PosY+1, pos-oldpos-1, pVB->Height-2, color1);
    else
      LCD_Fill (pVB->PosX+pos+1, pVB->PosY+1, oldpos-pos-1, pVB->Height-2, color2);
  }
  else
  {
    if (pos > oldpos)
      LCD_Fill (pVB->PosX+1, pVB->PosY+oldpos+1, pVB->Width-2, pos-oldpos-1, color1);
    else
      LCD_Fill (pVB->PosX+1, pVB->PosY+pos+1, pVB->Width-2, oldpos-pos-1, color2);
  }
}

static void WriteValueBar (tValueBar *pVB, uns16 color)
{
  LCDOptions_t *pLO = LCD_GetOpts ();
  if (pVB->PosX + pVB->Width < pLO->width && pVB->PosY + pVB->Height < pLO->height)
  {
    int32 val = GetVal (pVB->VarIdx),
          vmin = GetValMin (pVB->VarIdx),
          vmax = GetValMax (pVB->VarIdx),
          oldpos = VBCalcPos (pVB, pVB->VarOld);
    if (val < vmin)
    {
      val = vmin;
      oldpos = VBCalcPos (pVB, vmin);
      color = RED;
      pVB->Options |= cBarOptRedraw;
    }
    else if (val > vmax)
    {
      val = vmax;
      oldpos = VBCalcPos (pVB, vmin);
      color = RED;
      pVB->Options |= cBarOptRedraw;
    }
    else if (pVB->Options & cBarOptRedraw)
    {
      pVB->Options &= ~cBarOptRedraw;
      oldpos = VBCalcPos (pVB, vmin);
      LCD_Fill (pVB->PosX+1, pVB->PosY+1, pVB->Width-2, pVB->Height-2, LCD_GetBackColor ());
    }
    if (oldpos > pVB->Width-2)
      oldpos = pVB->Width-2;
    int32 pos = VBCalcPos (pVB, val);
    if (oldpos != pos)
    {
      uns16 color1 = color,
            backcolor = LCD_GetBackColor (),
            color2 = backcolor;
      uns8  bv = val >= 0,
            bov = pVB->VarOld >= 0;
      if (bv != bov)
      {
        FillVBar (pVB, pos, oldpos, backcolor, backcolor);
        oldpos = VBCalcPos (pVB, 0);
      }
      if (! bv)
      {
        color1 = backcolor;
        color2 = color;
      }
      FillVBar (pVB, pos, oldpos, color1, color2);
    }
    if (pVB->Options & cBarOptHor && pVB->Options & cBarOptShowVal)
    {
      uns8  zoom = 1 + ((pVB->Options & cBarOptTxtZoom2) > 0);
      uns16 format = pVB->Options & 0x00ff;
      LCD_ShowNum (pVB->PosX + 2, pVB->PosY + 2, val, zoom, cFont2, format, GetCol (cMenuPen));
    }
  }
}

void ShowValueBar (tValueBar *pVB, uns16 color)
{
  if (ValChanged (pVB->VarIdx) || (pVB->Options & cBarOptfirstDrw))
  {
    uns8 first = (pVB->Options & cBarOptfirstDrw) > 0;
    if (first)
    {
      DrawFrame (pVB);
      pVB->VarOld = GetValMin (pVB->VarIdx);
    }
    if (first || GetVal (pVB->VarIdx) != pVB->VarOld)
      WriteValueBar (pVB, color);
    pVB->VarOld = GetVal (pVB->VarIdx);
    pVB->Options &= ~cBarOptfirstDrw;
  }
}

//----------------------------------------------------------------------------
// Slider object
//----------------------------------------------------------------------------
static uns16 CalcScrollArea (tValueBar *pVB)
{
  return (pVB->Options & cBarOptHor) ? pVB->Width - 2 : pVB->Height - 2;
}

static uns16 CalcSliderLen (tValueBar *pVB)
{
  int32 sa = CalcScrollArea (pVB),
        sl = sa / (GetValMax (pVB->VarIdx) - GetValMin (pVB->VarIdx) + 1);
  return (pVB->Options & cBarOptHor) ? vmax (sl, pVB->Height-1) : vmax (sl, pVB->Width-1);
}

static int16 CalcSLPosVal (tValueBar *pVB)
{
  int16 sa = CalcScrollArea (pVB),
        sl = CalcSliderLen (pVB),
        dl = sa - sl;
  return ((GetVal (pVB->VarIdx) - GetValMin (pVB->VarIdx)) * dl) / (GetValMax (pVB->VarIdx) + 1 - GetValMin (pVB->VarIdx));
}

static uns8 CalcSLPos (int16 *pSLPos, uns16 x, uns16 y, uns16 posx, uns16 posy, uns16 w, uns16 h)
{
  uns16 wh = h / 2,
        xs = posx + 1,
        xe = posx + w - 1;

  if (x > xs && x < xe + wh && y >= posy && y <= posy + h)
  {
    if (x < xs + wh)
      x = xs + wh;
    else if (x > xe - wh)
      x = xe - wh;
    *pSLPos = x - posx - wh - 1;
    return 1;
  }
  return 0;
}

static void WriteSlider (tSlider *pSL, uns16 color)
{
  tValueBar    *pVB = pSL->pVB;
  LCDOptions_t *pLO = LCD_GetOpts ();
  if (pVB->PosX + pVB->Width < pLO->width && pVB->PosY + pVB->Height < pLO->height)
  {
    uns8  zoom = 1 + ((pVB->Options & cBarOptTxtZoom2) > 0);
    uns16 backcolor = LCD_GetBackColor (),
          format = pVB->Options & 0x00ff,
          yt, sl = CalcSliderLen (pVB) - 1;
    if (pVB->Options & cBarOptHor)
    {
      int16 xo = pVB->PosX + pSL->OldPos + 1,
            xn = pVB->PosX + pSL->Position + 1;
      LCD_Fill (xo+1, pVB->PosY+1, sl, pVB->Height-2, backcolor);
      LCD_Fill (xn+1, pVB->PosY+1, sl, pVB->Height-2, color);
      if (pVB->Options & cBarOptTxtInBar)
        yt = pVB->PosY+2;
      else
        yt = pVB->PosY+pVB->Height+3;
    }
    else
    {
      int16 yo = pVB->PosY + pSL->OldPos + 1,
            yn = pVB->PosY + pSL->Position + 1;
      LCD_Fill (pVB->PosX+1, yo+1, pVB->Width-2, sl, backcolor);
      LCD_Fill (pVB->PosX+1, yn+1, pVB->Width-2, sl, color);
      yt = pVB->PosY - zoom * LCD_GetOpts ()->ZHMax - 1;
    }
    if (pVB->Options & cBarOptShowVal)
      LCD_ShowNum (pVB->PosX+2, yt, GetVal (pVB->VarIdx), zoom, cFont2, format, GetCol (cMenuPen));
  }
  pSL->OldPos = pSL->Position;
}

void InitSlider (tSlider *pSL, tValueBar *pVB)
{
  pSL->pVB = pVB;
  pSL->Position = CalcSLPosVal (pVB);
  pSL->OldPos = pSL->Position;
}

void UpdateSlider (tSlider *pSL, uns16 color)
{
  tValueBar *pVB = pSL->pVB;
  if (! (pVB->Options & cBarHidden))
  {
    pSL->Position = CalcSLPosVal (pSL->pVB);
    WriteSlider (pSL, color);
  }
}

void ShowSLider (tSlider *pSL, uns16 color)
{
  tValueBar *pVB = pSL->pVB;
  if (! (pVB->Options & cBarHidden))
  {
    uns16 x, y;
    if ((pVB->Options & cBarOptfirstDrw) || Touch_Koords (&x, &y))
    {
      uns8  ok = 1;
      uns16 sl = CalcSliderLen (pVB);
      if (! (pVB->Options & cBarOptfirstDrw))
      {
        if (pVB->Options & cBarOptHor)
          ok = CalcSLPos (&pSL->Position, x, y, pVB->PosX, pVB->PosY, pVB->Width, sl);
        else
          ok = CalcSLPos (&pSL->Position, y, x, pVB->PosY, pVB->PosX, pVB->Height, sl);
      }
      else
        DrawFrame (pVB);
      if (ok)
      {
        int32 dl = CalcScrollArea (pVB) - sl,
              vmin = GetValMin (pVB->VarIdx),
              vmax = GetValMax (pVB->VarIdx),
              v = ((vmax + 1 - vmin) * (int32) pSL->Position) / dl + vmin;
        if (v > vmax) v = vmax;
        if (v < vmin) v = vmin;
        pVB->VarOld = GetVal (pVB->VarIdx);
        if (v != pVB->VarOld)
          SetVal (pVB->VarIdx, v);
        if ((pVB->Options & cBarOptfirstDrw) || pSL->OldPos != pSL->Position)
          WriteSlider (pSL, color);
        if (v != pVB->VarOld)
          SetValChanged (pVB->VarIdx, 1); // force change
      }
    }
    pVB->Options &= ~cBarOptfirstDrw;
  }
}

//----------------------------------------------------------------------------
// Menu-Ressource-Interpreter and Menu-Handler
//----------------------------------------------------------------------------
tMenuHandle* GetMenuHandle (void)
{
  return pMH;
}

uns8 GetMenuIndex (tMenuHandle *pMH)
{
  return pMH->CurrMenuIndex;
}

static void MenuError (const char *pErrStr, uns16 color)
{
  LCD_Clear (LCD_GetBackColor ());
  LCD_ShowString (5, 10, Init_tStr (pErrStr), 2, cFont1, color);
}

void InitMenuRessources (tMenuHandle *pMH)
{
  pMH->CBfuncs = (tCBFunc*) (pMH->ElemBuf);
  while (*pMH->pMRLT [pMH->MenuCnt].pMenuName != 0)
  {
    pMH->CBfuncs [pMH->MenuCnt] = pMH->pMRLT [pMH->MenuCnt].pCBfunc;
    pMH->MenuCnt++;
    pMH->MenuElemIndex += sizeof (tCBFunc);
  }
  pMH->MenuStartIndex = pMH->MenuElemIndex;
}

static uns8 FindMenuRes (tMenuHandle *pMH, tStr menuname)
{
  for (uns8 i = 0; i < pMH->MenuCnt; i++)
  {
    if (tStr_In_tStr (menuname, Init_tStr (pMH->pMRLT [i].pMenuName)))
    {
      pMH->CurrMenuIndex = i;
      return 1;
    }
  }
  return 0;
}

uns8 GetSelectedSK (tMenuHandle *pMH)
{
  return pMH->SelectedSK;
}

uns8 ShowMsgBox (tMenuHandle *pMH, const char *pBoxName, const char *pMsgStr)
{
  uns8 MenuIdx = pMH->CurrMenuIndex,
       PrevSelectedSK = pMH->SelectedSK; // we want to keep the selected line after this box
  if (! FindMenuRes (pMH, Init_tStr (pBoxName)))
  {
    while (1)
     ;
  }
  pMH->MsgBoxStr = Init_tStr (pMsgStr);
  MenuHandler (pMH, Init_tStr (pBoxName));
  uns8 ExitSK = pMH->ExitSK;
  InitMenuResInterpreter (pMH);
  MenuResourceInterpreter (pMH, Init_tStr (pMH->pMRLT [MenuIdx].pMenuName));
  pMH->PrevSelectedSK = PrevSelectedSK; // restore old selected line of calling menue
  pMH->firstDraw = 2;
  return ExitSK == 0;
}

static void InitMenuHandle (tMenuHandle *pMH)
{
  for (uns16 i = 0; i < cMaxElemBuf; i++)
    pMH->ElemBuf [i] = 0;
  pMH->MenuElemIndex = 0;
  pMH->MenuStartIndex = 0;
  pMH->MenuCnt = 0;
  pMH->CallStack = &pMH->ElemBuf [cMaxElemBuf - 1];
  pMH->NumSoftKeys = 0;
  pMH->NumObjPtrs = 0;
  pMH->ObjBufSize = 0;
}

static void CountAllocSpace (tMenuHandle *pMH, uns8 itemTyp, uns16 options, uns8 hasText)
{
  uns8 withSKey = options & cSKSelectable || options & cSKValue || options & cSKScrollable || hasText;
  switch (itemTyp)
  {
    case cObjTypSKVal:
    case cObjTypSKShow:
    case cObjTypSKKey:
      pMH->NumSoftKeys++;
      pMH->NumObjPtrs++;
    break;

    case cObjTypLED:
      pMH->ObjBufSize += sizeof (tLED);
      pMH->NumObjPtrs++;
      if (withSKey)
        pMH->NumSoftKeys++;
    break;

    case cObjTypVBar:
      pMH->ObjBufSize += sizeof (tValueBar);
      pMH->NumObjPtrs++;
      if (withSKey)
        pMH->NumSoftKeys++;
    break;

    case cObjTypSlider:
      pMH->ObjBufSize += sizeof (tValueBar) + sizeof (tSlider);
      pMH->NumObjPtrs += 2;
      if (withSKey)
        pMH->NumSoftKeys++;
    break;
  }
}

void InitMenuResInterpreter (tMenuHandle *pMH)
{
  pMH->MenuElemIndex = pMH->MenuStartIndex;
  pMH->NumSoftKeys = 0;
  pMH->NumObjPtrs = 0;
  pMH->ObjBufSize = 0;
  pMH->SoftKeys = 0;
  pMH->ObjPtrBuf = 0;
  pMH->ObjBuf = 0;
  Multiplier = 1;
  SetVal (pMH->ScrollVarIdx, 0);
  SetValMax (pMH->ScrollVarIdx, 0);
  SetValMin (pMH->ScrollVarIdx, 0);
  pMH->YHeader = cYHeader;
  pMH->YLine = cYLine;
  pMH->ScrollHeight = cScrollHeight;
  pMH->ScrollWidth = cScrollWidth;
  pMH->CurrMenuIndex = 0;
  pMH->firstDraw = 1;
  pMH->SelectedSK = cNoSoftkey;
  pMH->PrevSelectedSK = cNoSoftkey;
}

static void MIVDefaults (tMIVars *pV, uns8 firstInit)
{
  if (firstInit)
  {
    pV->first = 1; pV->finterpret = 0; pV->Y = pV->Y2 = 0;
    pV->skcnt = 0; pV->ObjPtrIdx = 0;  pV->ObjPtrBufOfs = 0;
    pV->zoomdef = cstdzoom; pV->fontnrdef = cstdfont;
    pV->defscrollofs = cScrollHeight / cYLine; pV->scrollofs = 0;
  }
  pV->W = 100; pV->H = 16;
  pV->itemTyp = 0; pV->opt = cSKNoOpts;
  pV->fontnr = pV->fontnrdef; pV->zoom = pV->zoomdef;
  pV->bitnr = 0;  pV->objopts = cObjNoOpts;
  pV->r = 8; pV->callnr = -1;
  pV->color = GetCol (cMenuPen); pV->Y2XYWHproged = 0;
  pV->format = 0x20; pV->vi = cMaxInt;
  pV->vartxt.pstr = 0; pV->vartxt.len = 0;
  pV->menuname.pstr = 0; pV->menuname.len = 0;
}

static void ScanOptions (tStr opts, tStr item, tMIVars *pV)
{
  if (IsIn_tStr ("TY", opts))
    pV->itemTyp = tStrToVal (item);
  else if (IsIn_tStr ("SO", opts))
    pV->opt = tStrToVal (item);
  if (pV->finterpret)
  {
    if (IsIn_tStr ("FM", opts))
      pV->format = tStrToVal (item);
    else if (IsIn_tStr ("BN", opts))
      pV->bitnr = tStrToVal (item);
    else if (IsIn_tStr ("X", opts))
    {
      pV->X = tStrToVal (item);
      pV->Y2XYWHproged |= 8;
    }
    else if (IsIn_tStr ("Y", opts))
    {
      pV->Y = tStrToVal (item);
      pV->Y2XYWHproged |= 4;
    }
    else if (IsIn_tStr ("X2", opts))
      pV->X2 = tStrToVal (item);
    else if (IsIn_tStr ("Y2", opts))
    {
      pV->Y2 = tStrToVal (item);
      pV->Y2XYWHproged |= 16;
    }
    else if (IsIn_tStr ("H", opts))
    {
      pV->H = tStrToVal (item);
      pV->Y2XYWHproged |= 1;
    }
    else if (IsIn_tStr ("W", opts))
    {
      pV->W = tStrToVal (item);
      pV->Y2XYWHproged |= 2;
    }
    else if (IsIn_tStr ("R", opts))
      pV->r = tStrToVal (item);
    else if (IsIn_tStr ("CO", opts))
      pV->color = tStrToVal (item);
    else if (IsIn_tStr ("SO", opts))
      pV->opt = tStrToVal (item);
    else if (IsIn_tStr ("OO", opts))
      pV->objopts = tStrToVal (item);
    else if (IsIn_tStr ("TX", opts))
      pV->vartxt = item;
    else if (IsIn_tStr ("ZO", opts))
      pV->zoom = tStrToVal (item);
    else if (IsIn_tStr ("FO", opts))
      pV->fontnr = tStrToVal (item);
    else if (IsIn_tStr ("CA", opts))
      pV->menuname = item;
  }
}

static void InterpreteStr (tStr text, tMIVars *pV)
{
  if (IsIn_tStr ("<Msg>", text))
  {
    tStr str = pMH->MsgBoxStr,
         s = Next_tStr (&str, '|');
    while (s.len)
    {
      LCD_ShowString (pV->X, pV->Y, s, pV->zoom, pV->fontnr, pV->color);
      s = Next_tStr (&str, '|');
      pV->Y += cYLine;
    }
  }
  else if (text.len)
    LCD_ShowString (pV->X, pV->Y, text, pV->zoom, pV->fontnr, pV->color);
}

static void DrawMsgBox (tStr text, tMIVars *pV)
{
  LCD_FillRoundRect (pV->X, pV->Y, pV->W, pV->H, pV->r, LCD_GetBackColor ());
  LCD_DrawRoundRect (pV->X, pV->Y, pV->W, pV->H, pV->r, GetCol (cMenuTitleBG));
  LCD_DrawRoundRect (pV->X+1, pV->Y+1, pV->W-2, pV->H-2, pV->r-1, GetCol (cMenuTitleBG));
  if (text.len)
    LCD_ShowString (pV->X + (pV->W - LCD_GetTextLen (text.len, pV->zoom, pV->fontnr)) / 2, pV->Y+10, text, pV->zoom, pV->fontnr, pV->color);
}

static void InterpreteTitle (tMenuHandle *pMH, tStr text, tMIVars *pV)
{
  MenuClear ();
  pV->zoomdef = pV->zoom;
  pV->fontnrdef = pV->fontnr;
  if (text.len > 0 && ! (pMH->HideConcealableSKs && (pV->opt & cSKConcealable)))
    MenuHeader (text, pV->zoom, pV->fontnr);
  if (pV->vi != cMaxInt)
    pMH->CurrMenuIndex = pV->vi;
  pMH->YHeader = (pV->Y2XYWHproged & 4) ? pV->Y : cYHeader;
  pMH->YLine = (pV->Y2XYWHproged & 16) ? pV->Y2 : cYLine;
  pMH->ScrollHeight = (pV->Y2XYWHproged & 1) ? pV->H : cScrollHeight;
  pMH->ScrollWidth = (pV->Y2XYWHproged & 2) ? pV->W : cScrollWidth;
  pV->defscrollofs = pMH->ScrollHeight / pMH->YLine;
  pV->X = 5; pV->X2 = pV->X; // init X and X2 here
}

static void InterpreteSKKey (tMenuHandle *pMH, tObjPtr *pObjPtr, tStr text, tMIVars *pV)
{
  tSoftKey *pSK = &pMH->SoftKeys [pV->skcnt];
  if (pV->skcnt > 0 && ! (pV->Y2XYWHproged & 4))
    pV->Y += 5;
  MakeSoftKey (pV->skcnt, text, pV->X, pV->Y, pV->zoom, pV->fontnr, pV->opt);
  if (pV->vi != cMaxInt && pV->vi > 0)
    pSK->VarIdx = pV->vi;
  if (pV->Y2XYWHproged & 1) // user programmed H & W are overwritten
    pSK->Height = pV->H;
  else
    pSK->Height += 10;
  if (pV->Y2XYWHproged & 2)
    pSK->Width = pV->W;
  else
    pSK->Width += 10;
  pV->Y += 5;
  if (pMH->HideConcealableSKs && (pV->opt & cSKConcealable))
    pSK->flags &= ~cISKEnabled;
  pObjPtr->skidx = pV->skcnt;
  pObjPtr->callname = pV->menuname;
  if (pV->skcnt < pMH->NumSoftKeys)
    pV->skcnt++;
}

static void InterpreteMItem (tMenuHandle *pMH, tObjPtr *pObjPtr, tStr text, tMIVars *pV)
{
  tSoftKey *pSK = &pMH->SoftKeys [pV->skcnt];
  MakeSoftKey (pV->skcnt, text, pV->X, pV->Y, pV->zoom, pV->fontnr, pV->opt);
  if (pV->Y2XYWHproged & 1) // user programmed H & W are overwritten
    pSK->Height = pV->H;
  if (pV->Y2XYWHproged & 2)
    pSK->Width = pV->W;
  if (pV->vi != cMaxInt)
    MakeSKVar (pV->skcnt, pV->vi, pV->format);
  if (pV->vartxt.len > 0)
    pSK->VarStr = pV->vartxt;
  if (pMH->HideConcealableSKs && (pV->opt & cSKConcealable))
  {
    pSK->Options &= ~cSKScrollable;
    pSK->flags &= ~cISKEnabled;
  }
  else if (SKOption (pV->skcnt, cSKScrollable))
  {
    if (pV->scrollofs < pV->defscrollofs)
      pV->scrollofs++;
    else
      SetValMax (pMH->ScrollVarIdx, GetValMax (pMH->ScrollVarIdx) + 1);
  }
  else
    pSK->flags |= cISKEnabled;
  pObjPtr->skidx = pV->skcnt;
  pObjPtr->bitnr = pV->bitnr;
  pObjPtr->X2 = pV->X2;
  pObjPtr->color = pV->color;
  pObjPtr->callname = pV->menuname;
  if (pV->skcnt < pMH->NumSoftKeys)
    pV->skcnt++;
}

static void InterpreteObjs (tMenuHandle *pMH, tObjPtr *pObjPtr, tMIVars *pV)
{
  uns8 s;
  pObjPtr->color = pV->color;
  if (pV->vi != cMaxInt && pV->itemTyp == cObjTypLED)
  {
    s = sizeof (tLED);
    if (pV->ObjPtrBufOfs + s <= pMH->ObjBufSize)
    {
      pObjPtr->ptr = pMH->ObjBuf + pV->ObjPtrBufOfs;
      InitMenuLED ((tLED*) pObjPtr->ptr, pV->X2, pV->Y, pV->r, pV->vi, pV->objopts, pV->bitnr);
      pV->ObjPtrBufOfs += s;
    }
  }
  else if (pV->vi != cMaxInt && (pV->itemTyp == cObjTypVBar || pV->itemTyp == cObjTypSlider))
  {
    s = sizeof (tValueBar);
    if (pV->ObjPtrBufOfs + s <= pMH->ObjBufSize)
    {
      if (pV->objopts & cBarOptScroll && GetValMax (pV->vi) == 0) // hide scrollbar if there is nothing to scroll
        pV->objopts |= cBarHidden;
      pObjPtr->ptr = pMH->ObjBuf + pV->ObjPtrBufOfs;
      InitValueBar ((tValueBar*) pObjPtr->ptr, pV->X2, pV->Y, pV->W, pV->H, pV->vi, pV->objopts);
      pV->ObjPtrBufOfs += s;
      if (pV->itemTyp == cObjTypSlider && pV->ObjPtrIdx < pMH->NumObjPtrs)
      {
        s = sizeof (tSlider);
        if (pV->ObjPtrBufOfs + s <= pMH->ObjBufSize)
        {
          if (pV->ObjPtrIdx < pMH->NumObjPtrs)
          {
            pV->ObjPtrIdx++;
            tObjPtr *p = &pMH->ObjPtrBuf [pV->ObjPtrIdx];
            *p = *pObjPtr;
            p->ptr = pMH->ObjBuf + pV->ObjPtrBufOfs;
            InitSlider ((tSlider*) p->ptr, (tValueBar*) pObjPtr->ptr);
            pV->ObjPtrBufOfs += s;
            pObjPtr->typ = cNoObjTyp; // no access to valuebar (belongs to this slider object)
          }
        }
      }
    }
  }
}

static void  MIAllocMem (tMenuHandle *pMH)
{
  pMH->SoftKeys = (tSoftKey*) &pMH->ElemBuf [pMH->MenuElemIndex];
  pMH->MenuElemIndex += pMH->NumSoftKeys * sizeof (tSoftKey);
  pMH->ObjPtrBuf = (tObjPtr*) &pMH->ElemBuf [pMH->MenuElemIndex];
  pMH->MenuElemIndex += pMH->NumObjPtrs * sizeof (tObjPtr);
  pMH->ObjBuf = &pMH->ElemBuf [pMH->MenuElemIndex];
  pMH->MenuElemIndex += pMH->ObjBufSize;

  uns16 s = &pMH->ElemBuf [cMaxElemBuf - 1] - pMH->CallStack;
  if (pMH->MenuElemIndex >= cMaxElemBuf - s)
  {
    MenuError (StrMemOvl, GetCol (cMenuPen));
    while (1)
      ;
  }
  s = cMaxElemBuf - pMH->MenuStartIndex - s;
  for (uns16 i = pMH->MenuStartIndex; i < s; i++)
    pMH->ElemBuf [i] = 0;
}

static void  ObjPtrDefaults (uns8 itemtyp, tObjPtr *pObjPtr)
{
  pObjPtr->ptr = 0;
  pObjPtr->typ = itemtyp;
  pObjPtr->skidx = cNoSoftkey;
  pObjPtr->bitnr = 0;
  pObjPtr->X2 = 0;
  pObjPtr->color = GetCol (cMenuPen);
  pObjPtr->callname.len = 0;
  pObjPtr->callname.pstr = 0;
}

void MenuResourceInterpreter (tMenuHandle *pMH, tStr MenuName)  // interprete ressource string
{
  tMIVars MIV;
  tStr    RStr, itemstr, item, text, validx, opts;
  if (! FindMenuRes (pMH, MenuName))
  {
    MenuError (StrErrNoMenu, GetCol (cMenuPen));
    while (1)
      ;
  }
  RStr = Init_tStr (pMH->pMRLT [pMH->CurrMenuIndex].pMenueRes);
  MenuSleep (cDefSleepTime);
  MIVDefaults (&MIV, 1);
  for (uns8 i = 0; i < 2; i++)
  {
    tStr ResStr = RStr;
    while (ResStr.len > 0)
    {
      itemstr = Next_tStr (&ResStr, ';');
      item = Next_tStr (&itemstr, ':');
      uns8 isTitle = IsIn_tStr ("T", item);
      if (IsIn_tStr ("M", item) || isTitle)
      {
        if (isTitle)
        {
          MIV.itemTyp = cObjTypTitle;
          text = Next_tStr (&itemstr, ',');
        }
        else
        {
          validx = Next_tStr (&itemstr, ',');
          text = Next_tStr (&validx, '=');
        }
        while (itemstr.len != 0)
        {
          item = Next_tStr (&itemstr, ',');
          opts = Next_tStr (&item, '=');
          ScanOptions (opts, item, &MIV);
        }
        if (MIV.finterpret) // interpret elements
        {
          MIV.vi = tStrToVal (validx);
          if (MIV.itemTyp == cObjTypString)
            InterpreteStr (text, &MIV);
          else if (MIV.itemTyp == cObjTypLine)
            LCD_DrawLine (MIV.X, MIV.Y, MIV.X2, MIV.Y2, MIV.color);
          else if (MIV.itemTyp == cObjTypBigLine)
            LCD_DrawBigLine (MIV.X, MIV.Y, (MIV.Y == MIV.Y2) ? MIV.X2 - MIV.X : MIV.Y2 - MIV.Y,  MIV.Y == MIV.Y2, MIV.color);
          else if (MIV.itemTyp == cObjTypRect)
            LCD_DrawRoundRect (MIV.X, MIV.Y, MIV.W, MIV.H, MIV.r, MIV.color);
          else if (MIV.itemTyp == cObjTypCircle)
            LCD_DrawCircle (MIV.X, MIV.Y, MIV.r, MIV.color);
          else if (MIV.itemTyp == cObjTypFRect)
            LCD_FillRoundRect (MIV.X, MIV.Y, MIV.W, MIV.H, MIV.r, MIV.color);
          else if (MIV.itemTyp == cObjTypFCircle)
            LCD_FillCircle (MIV.X, MIV.Y, MIV.r, MIV.color);
          else if (MIV.itemTyp == cObjTypTitle)
            InterpreteTitle (pMH, text, &MIV);
          else if (MIV.itemTyp == cObjTypMsgBox)
            DrawMsgBox (text, &MIV);
          else if (MIV.ObjPtrIdx < pMH->NumObjPtrs)
          {
            tObjPtr *pObjPtr = &pMH->ObjPtrBuf [MIV.ObjPtrIdx];
            ObjPtrDefaults (MIV.itemTyp, pObjPtr);
            if (MIV.itemTyp == cObjTypSKKey)
              InterpreteSKKey (pMH, pObjPtr, text, &MIV);
            else if (MIV.itemTyp == cObjTypSKShow || MIV.itemTyp == cObjTypSKVal || text.len > 0 ||
                     MIV.opt & cSKSelectable || MIV.opt & cSKValue || MIV.opt & cSKScrollable)
              InterpreteMItem (pMH, pObjPtr, text, &MIV);
            if (MIV.itemTyp == cObjTypLED || MIV.itemTyp == cObjTypVBar || MIV.itemTyp == cObjTypSlider)
              InterpreteObjs (pMH, pObjPtr, &MIV);
            if (MIV.ObjPtrIdx < pMH->NumObjPtrs)
              MIV.ObjPtrIdx++;
          }
        }
        else // count elements for mem allocation
          CountAllocSpace (pMH, MIV.itemTyp, MIV.opt, text.len > 0);
      }
      MIV.itemTyp = 0;
      MIV.opt = cSKNoOpts;
      if (MIV.finterpret)
      {
        if (MIV.first)
          MIV.Y += pMH->YHeader;
        else
          MIV.Y += pMH->YLine;
        MIV.Y2 = MIV.Y;
        MIVDefaults (&MIV, 0);
        MIV.first = 0;
      }
    }
    if (! MIV.finterpret)
    {
      MIAllocMem (pMH);
      MIV.finterpret = 1;
    }
  }
}

static uns8 GetObjIdx (tMenuHandle *pMH, uns8 SKNr)
{
  for (uns8 i = 0; i < pMH->NumObjPtrs; i++)
  {
    if (pMH->ObjPtrBuf [i].skidx == SKNr)
      return i;
  }
  return cNoSoftkey;
}

uns8 SKFromVarIndex (tMenuHandle *pMH, uns8 VarIndex)
{
  for (uns8 i = 0; i < pMH->NumSoftKeys; i++)
  {
    if (pMH->SoftKeys [i].VarIdx == VarIndex)
      return i;
  }
  return cNoSoftkey;
}

uns8 SKFromName (tMenuHandle *pMH, const char *pStr)
{
  for (uns8 i = 0; i < pMH->NumSoftKeys; i++)
  {
    if (IsIn_tStr (pStr, pMH->SoftKeys [i].Text))
      return i;
  }
  return cNoSoftkey;
}

uns8 ObjPtrIndexFromVarIndex (tMenuHandle *pMH, uns8 VarIndex)
{
  for (uns8 i = 0; i < pMH->NumObjPtrs; i++)
  {
    tObjPtr *pObjPtr = &pMH->ObjPtrBuf [i];
    if (pObjPtr->typ == cObjTypLED && ((tLED*) pObjPtr->ptr)->VarIdx == VarIndex)
      return i;
    else if (pObjPtr->typ == cObjTypVBar && ((tValueBar*) pObjPtr->ptr)->VarIdx == VarIndex)
      return i;
    else if (pObjPtr->typ == cObjTypSlider && ((tSlider*) pObjPtr->ptr)->pVB->VarIdx == VarIndex)
      return i;
    else
    {
      uns8 skidx = pObjPtr->skidx;
      if (skidx != cNoSoftkey && VarIndex == pMH->SoftKeys [skidx].VarIdx)
        return i;
    }
  }
  return cNoSoftkey;
}

static void ShowObjects (tMenuHandle *pMH)
{
  for (uns8 i = 0; i < pMH->NumObjPtrs; i++)
  {
    tObjPtr *pObjPtr = &pMH->ObjPtrBuf [i];
    uns8 skidx = pObjPtr->skidx;
    if (pObjPtr->typ == cObjTypSKShow)
    {
      if (skidx != cNoSoftkey && SKFlag (skidx, cISKEnabled))
      {
        tSoftKey *pSK = &pMH->SoftKeys [pObjPtr->skidx];
        if (pMH->firstDraw || ValChanged (pSK->VarIdx))
          LCD_ShowNum (pObjPtr->X2, pSK->PosY, GetVal (pSK->VarIdx), pSK->zoom, pSK->font, pSK->format, pObjPtr->color);
      }
    }
    else if (pObjPtr->ptr != 0)
    {
      // check if its a solo obejekt or an enabled SK-connected objekt
      if (skidx == cNoSoftkey || (skidx != cNoSoftkey && SKFlag (skidx, cISKEnabled)))
      {
        if (pObjPtr->typ == cObjTypLED)
          DrawMenuLED ((tLED*) pObjPtr->ptr, pObjPtr->color);
        else if (pObjPtr->typ == cObjTypVBar)
          ShowValueBar ((tValueBar*) pObjPtr->ptr, pObjPtr->color);
        else if (pObjPtr->typ == cObjTypSlider)
          ShowSLider ((tSlider*) pObjPtr->ptr, pObjPtr->color);
      }
    }
  }
}

static uns8 SKSelect (tMenuHandle *pMH, uns8 i, uns8 idx, uns8 firstSK)
{
  tSoftKey *pSK = &pMH->SoftKeys [i];
  uns8 match = 0;
  if (pMH->PrevSelectedSK != cNoSoftkey)
  {
    if (i == pMH->PrevSelectedSK) // restore old cursor position
    {
      pMH->PrevSelectedSK = cNoSoftkey;
      match = 1;
    }
  }
  else if (firstSK)
    match = 1;
  if (match)
  {
    //check for ediatable SK or SK-connected Object
    if (PSKOption (pSK, cSKSelectable) && ! PSKOption (pSK, cSKFrame)&& ! PSKOption (pSK, cSKDoubleFrame) &&
        (PSKOption (pSK, cSKValue) || (idx != cNoSoftkey && pMH->ObjPtrBuf [idx].typ > 0)))
      pSK->flags |= cISKInverse;
    return i;
  }
  return cNoSoftkey;
}

// draw menu objects and handle scrolling
static void ShowSoftkeys (tMenuHandle *pMH, uns8 *pCurrSK, uns8 *pLastSK)
{
  if (ValChanged (pMH->ScrollVarIdx) || pMH->firstDraw)
  {
    uns8 defscrollofs = pMH->ScrollHeight / pMH->YLine,
         firstSK = 1, scrollofs = 0;
    if (! pMH->firstDraw)
      LCD_Fill (0, pMH->YHeader-2, pMH->ScrollWidth, pMH->ScrollHeight+2, LCD_GetBackColor ());
    for (uns8 i = 0; i < pMH->NumSoftKeys; i++)
    {
      tObjPtr *pObjPtr = &pMH->ObjPtrBuf [i];
      uns8 idx = GetObjIdx (pMH, i);
      tSoftKey *pSK = &pMH->SoftKeys [i];
      pSK->flags &= ~cISKInverse;
      if (PSKOption (pSK, cSKScrollable)) // scrollable SK
      {
        if (i >= GetVal (pMH->ScrollVarIdx) + scrollofs && scrollofs < defscrollofs) // SK is in visible scroll area
        {
          if (SKSelect (pMH, i, idx, firstSK) != cNoSoftkey)
            pMH->SelectedSK = *pCurrSK = *pLastSK = i;
          firstSK = 0;
          uns16 pos = pMH->YHeader + scrollofs * pMH->YLine;
          if (idx != cNoSoftkey && pObjPtr->ptr != 0)
          {
            if (pObjPtr->typ == cObjTypLED)
            {
              tLED *pLED = (tLED*) pObjPtr->ptr;
              pLED->PosY = pos;
              pLED->Opts |= cLEDfirstDraw;
            }
            else if (pObjPtr->typ == cObjTypVBar)
            {
              tValueBar *pVB = (tValueBar*) pObjPtr->ptr;
              pVB->PosY = pos;
              pVB->Options |= cBarOptfirstDrw;
            }
            else if (pObjPtr->typ == cObjTypSlider)
            {
              tSlider *pSL = pObjPtr->ptr;
              tValueBar *pVB = pSL->pVB;
              pVB->PosY = pos;
              pVB->Options |= cBarOptfirstDrw;
            }
          }
          pSK->flags |= cISKEnabled;
          pSK->PosY = pos;
          DrawSoftKey (i);
          if (pSK->VarIdx != 0)
          {
            if (pObjPtr->bitnr == 0)
              SetValChanged (pSK->VarIdx, 1);
          }
          scrollofs++;
        }
        else                                // SK is not in visible area
          pSK->flags &= ~cISKEnabled;
      }
      else if (PSKFlag (pSK, cISKEnabled))  // draw not scrollable enabled SK
      {
        if (SKSelect (pMH, i, idx, firstSK) != cNoSoftkey)
          pMH->SelectedSK = *pCurrSK = *pLastSK = i;
        firstSK = 0;
        DrawSoftKey (i);
      }
    }
  }
}

static void HandlePluMi (tMenuHandle *pMH, uns8 SK, uns8 CurrSKey)
{
  tSoftKey *pSK = &pMH->SoftKeys [CurrSKey];
  int16     fak = GetMultiplier ();

  tCBCallMode cm = eOnPlus;
  if (SKOption (SK, cSKMinus))
  {
    fak = - fak;
    cm = eOnMinus;
  }
  if (CurrSKey < pMH->NumSoftKeys && SKOption (CurrSKey, cSKSelectable) &&
      ! SKOption (CurrSKey, cSKFrame) && ! SKOption (CurrSKey, cSKDoubleFrame))
  {
    uns8 idx = GetObjIdx (pMH, CurrSKey);
    if (idx != cNoSoftkey)
    {
      tObjPtr *pObjPtr = &pMH->ObjPtrBuf [idx];
      SetValBitNr (pSK->VarIdx, pObjPtr->bitnr);
    }

    // change softkey value
    UpdateMenuValue (CurrSKey, fak, PSKOption (pSK, cSKZykVal));

    // special aditional function via callBack function (eOnPlus / eOnMinus)
    if (pMH->CBfuncs [pMH->CurrMenuIndex] != 0)
      pMH->CBfuncs [pMH->CurrMenuIndex] (pMH, cm, CurrSKey);

    ShowValueItem (CurrSKey);
  }
}

static uns8 HandleItems (tMenuHandle *pMH, uns8 SK)
{
  uns8 submenucalled = 0,
       idx = GetObjIdx (pMH, SK);
  if (idx != cNoSoftkey)
  {
    tObjPtr *pObjPtr = &pMH->ObjPtrBuf [idx];
    if (pObjPtr->callname.pstr != 0 && pObjPtr->callname.len > 0) // call submenue
    {
      *pMH->CallStack = pMH->CurrMenuIndex;
      pMH->CallStack--;
      if (FindMenuRes (pMH, pObjPtr->callname))
      {
        // recursive call of submenue
        MenuHandler (pMH, pObjPtr->callname);
        InitMenuResInterpreter (pMH);
        pMH->CallStack++;
        pMH->CurrMenuIndex = *pMH->CallStack;
        MenuResourceInterpreter (pMH, Init_tStr (pMH->pMRLT [pMH->CurrMenuIndex].pMenuName));
      }
      else
      {
        MenuError (StrErrNoMenu, GetCol (cMenuPen));
        while (1)
          ;
      }
      pMH->firstDraw = 1;
      submenucalled = 1;
    }
  }
  // special aditional function via callBack function eOnItem / OnStart (after recusive menu call)
  if (pMH->CBfuncs [pMH->CurrMenuIndex] != 0)
  {
    tCBCallMode cm = eOnItem;
    if (submenucalled)
      cm = eOnStart;
    pMH->CBfuncs [pMH->CurrMenuIndex] (pMH, cm, SK);
  }
  return submenucalled;
}

void MenuHandler (tMenuHandle *pMH, tStr MenuName)
{
  InitMenuResInterpreter (pMH);
  MenuResourceInterpreter (pMH, MenuName);

  uns8 fend = 0, submenucalled, SK = cNoSoftkey,
       CurrSKey = cNoSoftkey, LastSKey = cNoSoftkey;

  // special aditional function via callBack function (eOnStart)
  if (pMH->CBfuncs [pMH->CurrMenuIndex] != 0)
    pMH->CBfuncs [pMH->CurrMenuIndex] (pMH, eOnStart, CurrSKey);

  while (! fend) // cyclic menue operation
  {
    submenucalled = 0;
    MenuSleep (cDefSleepTime);

    // special aditional function via callBack function (eOnZyk)
    if (pMH->CBfuncs [pMH->CurrMenuIndex] != 0)
      pMH->CBfuncs [pMH->CurrMenuIndex] (pMH, eOnZyk, SK);

    ShowSoftkeys (pMH, &CurrSKey, &LastSKey);

    ShowObjects (pMH);

    SK = SoftkeyPressed (); // check what softkey was pressed

    if (SK != cNoSoftkey && (SKOption (SK, cSKPlus) || SKOption (SK, cSKMinus))) // click on +/-
    {
      HandlePluMi (pMH, SK, CurrSKey);
    }
    else if (SK != cNoSoftkey && SKOption (SK, cSKExit))                         // click on exit
    {
      // special aditional function via callBack function (eOnEnd)
      if (pMH->CBfuncs [pMH->CurrMenuIndex] != 0)
        pMH->CBfuncs [pMH->CurrMenuIndex] (pMH, eOnEnd, CurrSKey);
      pMH->ExitSK = SK;
      fend = 1;
	}
    else if (SK < pMH->NumSoftKeys)                                              // click on item
    {
      submenucalled = HandleItems (pMH, SK);
      if (! submenucalled && SK != LastSKey && SKOption (SK, cSKSelectable) &&
          ! SKOption (SK, cSKFrame) && ! SKOption (SK, cSKDoubleFrame))
      {
        SelectSK (SK, LastSKey);
        CurrSKey = LastSKey = SK;
      }
    }
    if (! submenucalled && pMH->firstDraw != 0) // initiate a first draw after submenue call
      pMH->firstDraw--;
  }
}

//----------------------------------------------------------------------------
// Menue init
//----------------------------------------------------------------------------
void MenuBaseInit (void)
{
  uns16 color = GetCol (cMenuBackGnd);
  LCD_SetBackLight (1);
  LCD_SetBackCol (color);
  LCD_Fill (0, 0, LCD_GetOpts ()->width-1, LCD_GetOpts ()->height-1, color);
  InitMenuHandle (pMH);
}
