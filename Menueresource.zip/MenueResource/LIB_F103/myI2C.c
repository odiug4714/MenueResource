#include "myI2C.h"
#include "delay.h"
#include "myGPIO.h"

static void I2C1_InitPins (uint8_t pinpack)
{
  if (pinpack == cI2C_PinPack_1)
    PIO_Init (GPIOB, GPIO_Pin_6 | GPIO_Pin_7, GPIO_Mode_AF_OD, GPIO_Speed_10MHz);
  else if (pinpack == cI2C_PinPack_2)
    PIO_Init (GPIOB, GPIO_Pin_8 | GPIO_Pin_9, GPIO_Mode_AF_OD, GPIO_Speed_10MHz);
}

static void I2C2_InitPins (uint8_t pinpack)
{
  if (pinpack == cI2C_PinPack_1)
    PIO_Init (GPIOB, GPIO_Pin_10 | GPIO_Pin_11, GPIO_Mode_AF_OD, GPIO_Speed_10MHz);
}

void InitI2CCustom (HI2C_t *HI2C, uint32_t clockSpeed, uint16_t AcknoledgedAdress,
                    uint16_t I2C_Mode,  uint16_t I2C_OwnAddress,  uint16_t I2C_Ack,  uint16_t I2C_DutyCycle)
{
  I2C_TypeDef *I2Cx = HI2C->I2Cx;
  I2C_InitTypeDef aI2C;

  if (I2Cx == I2C1)
  {
    // Enable clock
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;
    // Enable pins
    I2C1_InitPins (HI2C->pinpack);
    // Set values
    aI2C.I2C_ClockSpeed = clockSpeed;
    aI2C.I2C_AcknowledgedAddress = AcknoledgedAdress;
    aI2C.I2C_Mode = I2C_Mode;
    aI2C.I2C_OwnAddress1 = I2C_OwnAddress;
    aI2C.I2C_Ack = I2C_Ack;
    aI2C.I2C_DutyCycle = I2C_DutyCycle;
  }
  else if (I2Cx == I2C2)
  {
    // Enable clock
    RCC->APB1ENR |= RCC_APB1ENR_I2C2EN;
    // Enable pins
    I2C2_InitPins (HI2C->pinpack);
    // Set values
    aI2C.I2C_ClockSpeed = clockSpeed;
    aI2C.I2C_AcknowledgedAddress = AcknoledgedAdress;
    aI2C.I2C_Mode = I2C_Mode;
    aI2C.I2C_OwnAddress1 = I2C_OwnAddress;
    aI2C.I2C_Ack = I2C_Ack;
    aI2C.I2C_DutyCycle = I2C_DutyCycle;
  }
  // Disable I2C first
  I2Cx->CR1 &= ~I2C_CR1_PE;
  // Initialize I2C
  I2C_Init(I2Cx, &aI2C);
  // Enable I2C
  I2Cx->CR1 |= I2C_CR1_PE;
  // clear errorcnt
  HI2C->errorcnt = 0;
}


void InitI2C (HI2C_t *HI2C)
{
  InitI2CCustom (HI2C, I2C_CLOCK_STANDARD, I2C_ACKNOWLEDGED_ADDRESS,
                 I2C_MODE, I2C_OWN_ADDRESS, I2C_ACK, I2C_DUTY_CYCLE);
}

int16_t StartI2C (HI2C_t *HI2C, uint8_t direction, uint8_t ack)
{
  if (HI2C->timeout)
  {
    HI2C->errorcnt++;
    //HI2C->timeout = 0;
    return 1;
  }
  I2C_TypeDef *I2Cx = HI2C->I2Cx;
  // Generate I2C start pulse
  I2Cx->CR1 |= I2C_CR1_START;
  // Wait till I2C is busy
  uint32_t I2C_Timeout = I2C_TIMEOUT;
  while (! (I2Cx->SR1 & I2C_SR1_SB))
  {
    if (--I2C_Timeout == 0x00)
    {
      HI2C->timeout = 1;
      return 1;
    }
  }
  // Enable ack if we select it
  if (ack)
    I2Cx->CR1 |= I2C_CR1_ACK;
  // Send write/read bit
  if (direction == I2C_TRANSMITTER_MODE)
  {
    // Send address with zero last bit
    I2Cx->DR = HI2C->address & ~I2C_OAR1_ADD0;
    // Wait till finished
    I2C_Timeout = I2C_TIMEOUT;
    while (! (I2Cx->SR1 & I2C_SR1_ADDR))
    {
      if (--I2C_Timeout == 0x00)
      {
        HI2C->timeout = 1;
        return 1;
      }
    }
  }
  if (direction == I2C_RECEIVER_MODE)
  {
    // Send address with 1 last bit
    I2Cx->DR = HI2C->address | I2C_OAR1_ADD0;
    // Wait till finished
    I2C_Timeout = I2C_TIMEOUT;
    while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))
    {
      if (--I2C_Timeout == 0x00)
      {
        HI2C->timeout = 1;
        return 1;
      }
    }
  }
  // Read status register to clear ADDR flag
  I2Cx->SR2;
  // Return 0, everything ok
  return 0;
}

void WriteDataI2C (HI2C_t *HI2C, uint8_t data)
{
  if (HI2C->timeout)
    return;
  I2C_TypeDef *I2Cx = HI2C->I2Cx;
  // Wait till I2C is not busy anymore
  uint32_t I2C_Timeout = I2C_TIMEOUT;
  while (!(I2Cx->SR1 & I2C_SR1_TXE) && I2C_Timeout)
  {
    I2C_Timeout--;
  }
  if (I2C_Timeout == 0x00)
  {
    HI2C->timeout = 1;
    return;
  }
  // Send I2C data
  I2Cx->DR = data;
}

uint8_t ReadAckI2C (HI2C_t *HI2C)
{
    if (HI2C->timeout)
      return 1;
    I2C_TypeDef *I2Cx = HI2C->I2Cx;
	// Enable ACK
	I2Cx->CR1 |= I2C_CR1_ACK;
	// Wait till not received
	uint32_t I2C_Timeout = I2C_TIMEOUT;
	while (! I2C_CheckEvent (I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED))
    {
		if (--I2C_Timeout == 0x00)
        {
	    	HI2C->timeout = 1;
			return 1;
		}
	}
	// Read data
	uint8_t data = I2Cx->DR;
	// Return data
	return data;
}

uint8_t ReadNackI2C (HI2C_t *HI2C)
{
  if (HI2C->timeout)
    return 1;
  I2C_TypeDef *I2Cx = HI2C->I2Cx;
  // Disable ACK
  I2Cx->CR1 &= ~I2C_CR1_ACK;
  // Generate stop
  I2Cx->CR1 |= I2C_CR1_STOP;
  // Wait till received
  uint32_t I2C_Timeout = I2C_TIMEOUT;
  while (! I2C_CheckEvent (I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED))
  {
    if (--I2C_Timeout == 0x00)
    {
      HI2C->timeout = 1;
      return 1;
    }
  }
  // Read data
  uint8_t data = I2Cx->DR;
  // Return data
  return data;
}

uint8_t StopI2C (HI2C_t *HI2C)
{
  if (HI2C->timeout)
    return 1;
  I2C_TypeDef *I2Cx = HI2C->I2Cx;
  // Wait till transmitter not empty
  uint32_t I2C_Timeout = I2C_TIMEOUT;
  while ((! (I2Cx->SR1 & I2C_SR1_TXE)) || (! (I2Cx->SR1 & I2C_SR1_BTF)))
  {
    if (--I2C_Timeout == 0x00)
    {
      HI2C->timeout = 1;
      return 1;
    }
  }
  // Generate stop
  I2Cx->CR1 |= I2C_CR1_STOP;
  // Return 0, everything ok
  return 0;
}

uint8_t IsDeviceConnectedI2C (HI2C_t *HI2C)
{
  uint8_t connected = 0;
  // Try to start, function will return 0 in case device will send ACK
  if (! StartI2C (HI2C, I2C_TRANSMITTER_MODE, I2C_ACK_ENABLE))
    connected = 1;
  // STOP I2C
  StopI2C (HI2C);
  // Return status
  return connected;
}


uint8_t ReadI2C (HI2C_t *HI2C, uint8_t reg, uint8_t RS)
{
  StartI2C (HI2C, I2C_TRANSMITTER_MODE, I2C_ACK_DISABLE);
  WriteDataI2C (HI2C, reg);
  if (RS == cNoRepeatedStart)
    StopI2C (HI2C);
  StartI2C (HI2C, I2C_RECEIVER_MODE, I2C_ACK_DISABLE);
  return ReadNackI2C (HI2C);
}

uint8_t ReadBitI2C (HI2C_t *HI2C, uint8_t reg, uint8_t bitnum, uint8_t RS)
{
  uint8_t b = ReadI2C (HI2C, reg, RS);
  return b & (1 << bitnum);
}

void WriteI2C (HI2C_t *HI2C, uint8_t reg, uint8_t data, uint8_t RS)
{
  StartI2C (HI2C, I2C_TRANSMITTER_MODE, I2C_ACK_DISABLE);
  WriteDataI2C (HI2C, reg);
  WriteDataI2C (HI2C, data);
  if (RS == cNoRepeatedStart)
    StopI2C (HI2C);
}

void WriteCmdI2C (HI2C_t *HI2C, uint8_t reg, uint8_t RS)
{
  StartI2C (HI2C, I2C_TRANSMITTER_MODE, I2C_ACK_DISABLE);
  WriteDataI2C (HI2C, reg);
  if (RS == cNoRepeatedStart)
    StopI2C (HI2C);
}

void WriteBitI2C (HI2C_t *HI2C, uint8_t reg, uint8_t bitnum, uint8_t data, uint8_t RS)
{
  uint8_t b = ReadI2C (HI2C, reg, RS);
  b = (data != 0) ? (b | (1 << bitnum)) : (b & ~(1 << bitnum));
  WriteI2C (HI2C, reg, b, RS);
}

void WriteBitsI2C (HI2C_t *HI2C, uint8_t reg, uint8_t bitStart, uint8_t len, uint8_t data, uint8_t RS)
{
  uint8_t b = ReadI2C (HI2C, reg, RS),
          mask = (0xFF << (bitStart + 1)) | 0xFF >> ((8 - bitStart) + len - 1);
  data <<= (8 - len);
  data >>= (7 - bitStart);
  b &= mask;
  b |= data;
  WriteI2C (HI2C, reg, b, RS);
}

uint8_t WriteBufI2C (HI2C_t *HI2C, uint8_t *pdata, uint8_t len, uint8_t RS)
{
  if (StartI2C (HI2C, I2C_TRANSMITTER_MODE, I2C_ACK_DISABLE))
    return 1;
  for (uint8_t i = 0; i < len; i++)
  {
    WriteDataI2C (HI2C, pdata [i]);
    Delay (5); // ! Wichtig
  }
  if (RS == cNoRepeatedStart && StopI2C (HI2C))
    return 1;
  return 0;
}

void ReadBufI2C (HI2C_t *HI2C, uint8_t *pdata, uint16_t len)
{
  StartI2C (HI2C, I2C_RECEIVER_MODE, I2C_ACK_ENABLE);
  for (uint8_t i = 0; i < len; i++)
  {
    Delay (5); // Wichtig
    if (i == len - 1)
    {
      // Last byte
      pdata [i] = ReadNackI2C (HI2C);
    }
    else
    {
      pdata [i] = ReadAckI2C (HI2C);
    }
  }
}


//---------------------------------------------------------
// EE-Prom-Devices
//---------------------------------------------------------
uint8_t EEPromWritePage (HI2C_t *HI2C, uint16_t pagenr, tEEPromPage *pbuf)
{
  pbuf->dummyhi = pagenr >> 8;
  pbuf->dummylo = pagenr;
  uint16_t adr = pagenr * cEEPromPageSize;
  pbuf->adrhi = adr >> 8;
  pbuf->adrlo = adr;
  //uint8_t ctrlmask = adr >> 15; // bei mehreren devices (device dependant !!)
  //EEPSlaveAdr |= ctrlmask & 0x0e;
  return WriteBufI2C (HI2C, &pbuf->adrhi, cEEPromPageSize + 2, cNoRepeatedStart);
}

uint8_t EEPromReadPage (HI2C_t *HI2C, uint16_t pagenr, tEEPromPage *pbuf)
{
  pbuf->dummyhi = pagenr >> 8;
  pbuf->dummylo = pagenr;
  uint16_t adr = pagenr * cEEPromPageSize;
  pbuf->adrhi = adr >> 8;
  pbuf->adrlo = adr;
  //uint8_t ctrlmask = adr >> 15; // bei mehreren devices (device dependant !!)
  //EEPSlaveAdr |= ctrlmask & 0x0e;
  WriteBufI2C (HI2C, &pbuf->adrhi, 2, cRepeatedStart);
  Delay (80); // Wichtig
  ReadBufI2C (HI2C, pbuf->buf, cEEPromPageSize);
  return 1;
}

//---------------------------------------------------------
