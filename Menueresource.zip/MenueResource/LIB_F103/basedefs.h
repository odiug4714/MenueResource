#ifndef _basedefs_h
#define _basedefs_h

#include "stdint.h"

/* Check for GNUC */
#if defined (__GNUC__)
	#ifndef __weak
		#define __weak   	__attribute__((weak))
	#endif	/* Weak attribute */
	#ifndef __packed
		#define __packed 	__attribute__((__packed__))
	#endif	/* Packed attribute */
#endif

#define uns8  uint8_t
#define uns16 uint16_t
#define uns32 uint32_t

#define int8  int8_t
#define int16 int16_t
#define int32 int32_t

#define true  1
#define false 0

// Formatierte Anzeige von Werten
// low byte: dezimal: oberes nibble = Vorkommastellen, hex: Anzahl Stellen
//                    unteres nibble = Nachkommastellen, hex egal
// high byte: nachfolgende Optionen
#define cLeadingZeros    0x0100
#define cHex             0x0800  // convert to hex value
#define cHex0x           0x0200  // with 0x at the beginning
#define cHexUpperCase    0x0400

#define cMaxTimers 16            // max. Anzahl SWTimer
#define cMaxInt    0x7fffffff

// defines substring on constant ressource string
// temporary strings are NOT stored
typedef struct
{
  const char *pstr; // pointer on constant ressoucre string
  uns16      len;   // needed for substring length limitation
} tStr;

int32 vmax (int32 a, int32 b);
int32 vmin (int32 a, int32 b);
int32 MinMaxVal (int32 v, int32 vmin, int32 vmax);
int32 MinMaxValZyk (int32 v, int32 vmin, int32 vmax);
int32 ValConvert (int32 inputval, uns16 format);

tStr Init_tStr (const char *p);
uns8 IsIn_tStr (const char* s, tStr str);
uns8 tStr_In_tStr (tStr s, tStr str);
int32 tStrToVal (tStr str);
tStr Next_tStr (tStr *str, char delim);

void SetTimer (uns8 TimIndex, uns32 Time);
uns8 TimerExpired (uns8 TimIndex, uns32 NewTime);
void DecTimers (void);

uns16 StrLen (const char* str);
void StrCopy (char* srcstr, char* deststr);
char* StrCat (char* srcstr, char* str);
void NextStr (char** pstr, char delim, char* resstr);
uns8 GetValueLen (uns16 format);
void ValToStr (int32 val, char *pstr, uns16 format);
int32 StrToVal (const char* str);

#endif
