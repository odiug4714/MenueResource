#ifndef _DELAY_H
#define _DELAY_H

#include "stdint.h"

void DELAY_Init(void);
void Delay (uint32_t micros);
void Delayms (uint32_t millis);

#endif
