#ifndef MYI2C_H
#define MYI2C_H

/*
       |PINPACK 1    |PINPACK 2
I2CX   |SCL   SDA    |SCL   SDA
I2C1   |PB6   PB7    |PB8   PB9
I2C2   |PB10  PB11
*/

#include "stm32f10x.h"

#define I2C_TRANSMITTER_MODE        0
#define I2C_RECEIVER_MODE           1
#define I2C_ACK_ENABLE              1
#define I2C_ACK_DISABLE             0

#define I2C_TIMEOUT			        1000000

#define I2C_ACKNOWLEDGED_ADDRESS    I2C_AcknowledgedAddress_7bit
#define I2C_MODE                    I2C_Mode_I2C
#define I2C_OWN_ADDRESS             0x00
#define I2C_ACK                     I2C_Ack_Disable
#define I2C_DUTY_CYCLE              I2C_DutyCycle_2

#define I2C_CLOCK_STANDARD			100000   // I2C Standard speed
#define I2C_CLOCK_FAST_MODE			400000   // I2C Fast mode speed
#define I2C_CLOCK_FAST_MODE_PLUS	1000000  // I2C Fast mode plus speed
#define I2C_CLOCK_HIGH_SPEED		3400000  // I2C High speed

#define cI2C_PinPack_1              0        // Use Pinpack1 from Pinout table for I2Cx
#define cI2C_PinPack_2              1        // Use Pinpack2 from Pinout table for I2Cx

#define cNoRepeatedStart            0        // send Stop
#define cRepeatedStart              1        // repeated Start without Stop

typedef struct
{
  I2C_TypeDef* I2Cx;
  uint8_t      address,
               pinpack,
               timeout;
  uint32_t     errorcnt;
} HI2C_t;

void    InitI2C (HI2C_t *HI2C);
void    InitI2CCustom (HI2C_t *HI2C, uint32_t clockSpeed, uint16_t AcknoledgedAdress,
                       uint16_t I2C_Mode,  uint16_t I2C_OwnAddress,  uint16_t I2C_Ack,  uint16_t I2C_DutyCycle);
uint8_t IsDeviceConnectedI2C (HI2C_t *HI2C);
int16_t StartI2C (HI2C_t *HI2C, uint8_t direction, uint8_t ack);
uint8_t StopI2C (HI2C_t *HI2C);
void    WriteI2C (HI2C_t *HI2C, uint8_t reg, uint8_t data, uint8_t RS);
void    WriteCmdI2C (HI2C_t *HI2C, uint8_t reg, uint8_t RS);
void    WriteDataI2C (HI2C_t *HI2C, uint8_t data);
void    WriteBitI2C (HI2C_t *HI2C, uint8_t reg, uint8_t bitnum, uint8_t data, uint8_t RS);
void    WriteBitsI2C (HI2C_t *HI2C, uint8_t reg, uint8_t bitStart, uint8_t len, uint8_t data, uint8_t RS);
uint8_t WriteBufI2C (HI2C_t *HI2C, uint8_t *pdata, uint8_t len, uint8_t RS);
uint8_t ReadBitI2C (HI2C_t *HI2C, uint8_t reg, uint8_t bitnum, uint8_t RS);
void    ReadBufI2C (HI2C_t *HI2C, uint8_t *pdata, uint16_t len);
uint8_t ReadNackI2C (HI2C_t *HI2C);
uint8_t ReadAckI2C (HI2C_t *HI2C);
uint8_t ReadI2C (HI2C_t *HI2C, uint8_t reg, uint8_t RS);

//------------------------------------------ Devices ----------------------------------------------------
#define cEEPromPages    512
#define cEEPromPageSize 128

typedef struct
{
  uint8_t dummyhi,               // allignment
          dummylo,
          adrhi,                 // page addess calculated by system
          adrlo,
          buf [cEEPromPageSize]; // EEP-Userdata
} tEEPromPage;

uint8_t EEPromWritePage (HI2C_t *HI2C, uint16_t pagenr, tEEPromPage *pbuf);
uint8_t EEPromReadPage (HI2C_t *HI2C, uint16_t pagenr, tEEPromPage *pbuf);

#endif
