#include "stm32f10x_conf.h"
#include "delay.h"

static uint32_t multiplier = 10;

extern uint32_t TickCnt;

void DELAY_Init (void)
{
  uint32_t v = SystemCoreClock / 10 - SystemCoreClock / 100;
  multiplier = SystemCoreClock / v;
}

void Delay (uint32_t micros)
{
  uint32_t us = micros * multiplier;

  while (us--)
    ;
}

void Delayms (uint32_t millis)
{
  Delay (millis * 1000);
/*
  uint32_t ticks = TickCnt + millis;
  while (TickCnt < ticks)
    ;
*/
}
