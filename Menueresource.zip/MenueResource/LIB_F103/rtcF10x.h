#ifndef rtcF10x_H
#define rtcF10x_H

typedef struct
{
	uint16_t year;	 /* 1..4095 */
	uint8_t  month;	 /* 1..12 */
	uint8_t  mday;	 /* 1..31 */
	uint8_t  wday;	 /* 0..6, Sunday = 0*/
	uint8_t  hour;	 /* 0..23 */
	uint8_t  minute;	 /* 0..59 */
	uint8_t  sec;	 /* 0..59 */
	uint8_t  dst;	 /* 0 Winter, !=0 Summer */
	uint8_t  alhour; /* 0..23 */
	uint8_t  almin;	 /* 0..59 */
	uint8_t  alsec;	 /* 0..59 */
} RTC_t;

void     InitRTC (void);
void     RTCcounter_to_struct (uint32_t sec, RTC_t *t);
uint32_t RTCstruct_to_counter (const RTC_t *t);
uint8_t  RTCadjustDST (RTC_t *t);
void     RTCGetTime (RTC_t *);
void     RTCSetTime (RTC_t *);
void     RTCSetAlarm (RTC_t *);

#endif
