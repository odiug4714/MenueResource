#include "mySPI.h"
#include "myGPIO.h"

static void SPI1_InitPins (uint8_t pinpack)
{
  if (pinpack == cSPI_PinPack_1)
  {
    PIO_Init (GPIOA, GPIO_Pin_5 | GPIO_Pin_6 | GPIO_Pin_7, GPIO_Mode_AF_PP, GPIO_Speed_50MHz);
  }
  else if (pinpack == cSPI_PinPack_2)
  {
    PIO_Init (GPIOB, GPIO_Pin_3 | GPIO_Pin_4 | GPIO_Pin_5, GPIO_Mode_AF_PP, GPIO_Speed_50MHz);
    GPIO_PinRemapConfig (GPIO_Remap_SPI1, ENABLE);
  }
}

static void SPI2_InitPins (uint8_t pinpack)
{
  if (pinpack == cSPI_PinPack_1)
  {
    PIO_Init (GPIOB, GPIO_Pin_13 | GPIO_Pin_14 | GPIO_Pin_15, GPIO_Mode_AF_PP, GPIO_Speed_50MHz);
  }
}

void InitSPICustom (HSPI_t *HSPI, uint8_t SPI_Mode, uint16_t DataSize,
                    uint16_t SPI_BaudRatePrescaler, uint16_t SPI_MasterSlave, uint16_t SPI_FirstBit)
{
  SPI_TypeDef     *SPIx = HSPI->SPIx;
  SPI_InitTypeDef aSPI;

  HSPI->timeout = 0;
  if (SPIx == SPI1)
  {
    RCC->APB2ENR |= RCC_APB2ENR_SPI1EN;
    SPI1_InitPins (HSPI->pinpack);
  }
  else if (SPIx == SPI2)
  {
    RCC->APB1ENR |= RCC_APB1ENR_SPI2EN;
    SPI2_InitPins (HSPI->pinpack);
  }
  SPI_StructInit (&aSPI);
  aSPI.SPI_DataSize = DataSize;
  aSPI.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler;
  aSPI.SPI_Direction = SPI_Direction_2Lines_FullDuplex;
  aSPI.SPI_FirstBit = SPI_FirstBit;
  aSPI.SPI_Mode = SPI_MasterSlave;
  aSPI.SPI_NSS = SPI_NSS_Soft;
  if (SPI_Mode == cSPI_Mode_0)
  {
    aSPI.SPI_CPOL = SPI_CPOL_Low;
    aSPI.SPI_CPHA = SPI_CPHA_1Edge;
  }
  else if (SPI_Mode == cSPI_Mode_1)
  {
	aSPI.SPI_CPOL = SPI_CPOL_Low;
	aSPI.SPI_CPHA = SPI_CPHA_2Edge;
  }
  else if (SPI_Mode == cSPI_Mode_2)
  {
    aSPI.SPI_CPOL = SPI_CPOL_High;
    aSPI.SPI_CPHA = SPI_CPHA_1Edge;
  }
  else if (SPI_Mode == cSPI_Mode_3)
  {
    aSPI.SPI_CPOL = SPI_CPOL_High;
    aSPI.SPI_CPHA = SPI_CPHA_2Edge;
  }
  SPIx->CR1 &= ~SPI_CR1_SPE;
  SPI_Init (SPIx, &aSPI);
  // Enable SPI
  SPIx->CR1 |= SPI_CR1_SPE;
}

void InitSPI (HSPI_t *HSPI)
{
  InitSPICustom (HSPI, cSPI_Mode_0, SPI_DataSize_8b , SPI_BaudRatePrescaler_2,
                 SPI_Mode_Master, SPI_FirstBit_MSB);
}

static uint8_t SPI_WAIT (HSPI_t *HSPI)
{
  uint32_t Timeout = cSPI_Timeout;
  while (SPI_IS_BUSY (HSPI->SPIx) && Timeout > 0)
    Timeout--;
  HSPI->timeout = Timeout == 0;
  return HSPI->timeout;
}

uint16_t SPI_GetPrescalerFromMaxFrequency (HSPI_t *HSPI, uint32_t MAX_SPI_Frequency)
{
  SPI_TypeDef       *SPIx = HSPI->SPIx;
  RCC_ClocksTypeDef RCC_Clocks;
  uint32_t          APB_Frequency;

  // Prevent false input
  if (MAX_SPI_Frequency == 0)
  {
    return SPI_BaudRatePrescaler_256;
  }
  // Get clock values from RCC
  RCC_GetClocksFreq (&RCC_Clocks);
  // Calculate max SPI clock
  if (SPIx == SPI1)
  {
    APB_Frequency = RCC_Clocks.PCLK2_Frequency;
  }
  else
  {
    APB_Frequency = RCC_Clocks.PCLK1_Frequency;
  }
  // Calculate prescaler value
  // Bits 5:3 in CR1 SPI registers are prescalers
  // 000 = 2, 001 = 4, 002 = 8, ..., 111 = 256
  for (uint8_t i = 0; i < 8; i++)
  {
    if (APB_Frequency / (1 << (i + 1)) <= MAX_SPI_Frequency)
    {
      // Bits for BP are 5:3 in CR1 register
      return (i << 3);
    }
  }
  // Use max prescaler possible
  return SPI_BaudRatePrescaler_256;
}

void SPI_Set8Bit (HSPI_t *HSPI)
{
  SPI_TypeDef *SPIx = HSPI->SPIx;
  SPIx->CR1 &= ~SPI_CR1_SPE; // DISABLE SPI
  SPIx->CR1 &= ~SPI_CR1_DFF; // SPI 8
  SPIx->CR1 |= SPI_CR1_SPE;  // ENABLE SPI
}

void SPI_Set16Bit (HSPI_t *HSPI)
{
  SPI_TypeDef *SPIx = HSPI->SPIx;
  SPIx->CR1 &= ~SPI_CR1_SPE; // DISABLE SPI
  SPIx->CR1 |= SPI_CR1_DFF;  // SPI 16
  SPIx->CR1 |= SPI_CR1_SPE;  // ENABLE SPI
}

void SPI_SetDataSize (HSPI_t *HSPI, uint16_t DataSize)
{
  SPI_TypeDef *SPIx = HSPI->SPIx;
  // Disable SPI
  SPIx->CR1 &= ~SPI_CR1_SPE;

  if (DataSize == SPI_DataSize_16b)
    SPIx->CR1 |= SPI_CR1_DFF;
  else
   SPIx->CR1 &= ~SPI_CR1_DFF;

  // Enable SPI
  SPIx->CR1 |= SPI_CR1_SPE;
}

void SPI_SetMode (HSPI_t *HSPI, uint8_t SPI_Mode)
{
  SPI_TypeDef *SPIx = HSPI->SPIx;
  uint16_t tmpreg = 0;

  // Get the SPIx CR1 value
  tmpreg = SPIx->CR1;
  // Clear CPOL (bit 1) and CPHA (bit 0)
  tmpreg &= ~0x03;

  // SPI mode
  if (SPI_Mode == cSPI_Mode_0)
  {
    // SPI_CPOL_Low, SPI_CPHA_1Edge
    // nix
  }
  else if (SPI_Mode == cSPI_Mode_1)
  {
	// SPI_CPOL_Low, SPI_CPHA_2Edge
    tmpreg |= 0x01;
  }
  else if (SPI_Mode == cSPI_Mode_2)
  {
	// SPI_CPOL_High, SPI_CPHA_1Edge
    tmpreg |= 0x10;
  }
  else if (SPI_Mode == cSPI_Mode_3)
  {
	// SPI_CPOL_High, SPI_CPHA_2Edge
    tmpreg |= 0x03;
  }
  // Write to SPIx CR1
  SPIx->CR1 = tmpreg;
}

uint8_t SPI_Send (HSPI_t *HSPI, uint8_t data)
{
  if (HSPI->timeout)
    return 1;
  SPI_TypeDef *SPIx = HSPI->SPIx;
  // Check if SPI is enabled
  SPI_CHECK_ENABLED_RESP(SPIx, 0);
  // Wait for previous transmissions to complete if DMA TX enabled for SPI
  SPI_WAIT (HSPI);
  // Fill output buffer with data
  SPIx->DR = data;
  // Wait for transmission to complete
  SPI_WAIT (HSPI);
  // Return data from buffer
  return SPIx->DR;
}

uint16_t SPI_Send16 (HSPI_t *HSPI, uint8_t data)
{
  if (HSPI->timeout)
    return 1;
  SPI_TypeDef *SPIx = HSPI->SPIx;
  // Check if SPI is enabled
  SPI_CHECK_ENABLED_RESP (SPIx, 0);
  // Wait for previous transmissions to complete if DMA TX enabled for SPI
  SPI_WAIT (HSPI);
  // Fill output buffer with data
  SPIx->DR = data;
  // Wait for transmission to complete
  SPI_WAIT (HSPI);
  // Return data from buffer
  return SPIx->DR;
}


void SPI_SendBytes (HSPI_t *HSPI, uint8_t* dataOut, uint8_t* dataIn, uint32_t num)
{
  if (HSPI->timeout)
    return;
  SPI_TypeDef *SPIx = HSPI->SPIx;
  // Check if SPI is enabled
  SPI_CHECK_ENABLED (SPIx);
  // Wait for previous transmissions to complete if DMA TX enabled for SPI
  SPI_WAIT (HSPI);
  for (uint32_t i = 0; i < num; i++)
  {
    // Fill output buffer with data
    SPIx->DR = dataOut[i];
    // Wait for SPI to end everything
    SPI_WAIT (HSPI);
    // Read data register
    dataIn[i] = SPIx->DR;
  }
}

void SPI_WriteBytes (HSPI_t *HSPI, uint8_t* dataOut, uint32_t num)
{
  if (HSPI->timeout)
    return;
  SPI_TypeDef *SPIx = HSPI->SPIx;
  // Check if SPI is enabled
  SPI_CHECK_ENABLED (SPIx);
  // Wait for previous transmissions to complete if DMA TX enabled for SPI
  SPI_WAIT (HSPI);
  for (uint32_t i = 0; i < num; i++)
  {
    // Fill output buffer with data
    SPIx->DR = dataOut[i];
    // Wait for SPI to end everything
    SPI_WAIT (HSPI);
    // Read data register
    SPIx->DR;
  }
}

void SPI_ReadBytes (HSPI_t *HSPI, uint8_t* dataIn, uint32_t num)
{
  if (HSPI->timeout)
    return;
  SPI_TypeDef *SPIx = HSPI->SPIx;
  // Check if SPI is enabled
  SPI_CHECK_ENABLED (SPIx);
  // Wait for previous transmissions to complete if DMA TX enabled for SPI
  SPI_WAIT (HSPI);
  for (uint32_t i = 0; i < num; i++)
  {
    // Fill output buffer with data
    SPIx->DR = 0xff;
    // Wait for SPI to end everything
    SPI_WAIT (HSPI);
    // Save data to buffer
    dataIn[i] = SPIx->DR;
  }
}

void SPI_SendWords (HSPI_t *HSPI, uint16_t* dataOut, uint16_t* dataIn, uint32_t num)
{
  if (HSPI->timeout)
    return;
  SPI_TypeDef *SPIx = HSPI->SPIx;
  // Check if SPI is enabled
  SPI_CHECK_ENABLED (SPIx);
  // Wait for previous transmissions to complete if DMA TX enabled for SPI
  SPI_WAIT (HSPI);
  for (uint32_t i = 0; i < num; i++)
  {
    // Fill output buffer with data
    SPIx->DR = dataOut[i];
    // Wait for SPI to end everything
    SPI_WAIT (HSPI);
    // Read data register
    dataIn[i] = SPIx->DR;
  }
}

void SPI_WriteWords (HSPI_t *HSPI, uint16_t* dataOut, uint32_t num)
{
  if (HSPI->timeout)
    return;
  SPI_TypeDef *SPIx = HSPI->SPIx;
  // Check if SPI is enabled
  SPI_CHECK_ENABLED(SPIx);
  // Wait for previous transmissions to complete if DMA TX enabled for SPI
  SPI_WAIT (HSPI);
  for (uint32_t i = 0; i < num; i++)
  {
    // Fill output buffer with data
    SPIx->DR = dataOut[i];
    // Wait for SPI to end everything
    SPI_WAIT (HSPI);
    // Read data register
    SPIx->DR;
  }
}

void SPI_ReadWords (HSPI_t *HSPI, uint16_t* dataIn, uint32_t num)
{
  if (HSPI->timeout)
    return;
  SPI_TypeDef *SPIx = HSPI->SPIx;
  // Check if SPI is enabled
  SPI_CHECK_ENABLED(SPIx);
  // Wait for previous transmissions to complete if DMA TX enabled for SPI
  SPI_WAIT (HSPI);
  for (uint32_t i = 0; i < num; i++)
  {
    // Fill output buffer with data
    SPIx->DR = 0xff;
    // Wait for SPI to end everything
    SPI_WAIT (HSPI);
    // Save data to buffer
    dataIn[i] = SPIx->DR;
  }
}
