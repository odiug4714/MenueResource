#include "Vars.h"

tVar Vars [cVarMax]; // System-Variablen

void InitVars (void)
{
  for (uns8 i = 0; i < cVarMax; i++)
  {
    Vars [i].VMin = 0;
    Vars [i].bitnr = 0;
    Vars [i].changed = 0;
  }
  Vars [cStunden].VMax = 24;
  Vars [cMinuten].VMax = 60;
  Vars [cSekunden].VMax = 60;
  Vars [cAlStunden].VMax = 24;
  Vars [cAlMinuten].VMax = 60;
  Vars [cAlSekunden].VMax = 60;
  Vars [cTag].VMax = 31;
  Vars [cMonat].VMax = 12;
  Vars [cJahr].VMax = 99;
  Vars [cRed].VMax = 31;
  Vars [cGreen].VMax = 63;
  Vars [cBlue].VMax = 31;
  Vars [cLayout].VMax = 3;
  Vars [cACCX].VMin = -32768;
  Vars [cACCX].VMax = 32767;
  Vars [cACCY].VMin = -32768;
  Vars [cACCY].VMax = 32767;
  Vars [cACCZ].VMin = -32768;
  Vars [cACCZ].VMax = 32767;
  Vars [cGyroX].VMin = -32768;
  Vars [cGyroX].VMax = 32767;
  Vars [cGyroY].VMin = -32768;
  Vars [cGyroY].VMax = 32767;
  Vars [cGyroZ].VMin = -32768;
  Vars [cGyroZ].VMax = 32767;
  Vars [cMotTime].VMax = 99;
  Vars [cMotSense].VMax = 99;
  Vars [cAccSense].VMax = 3;
  Vars [cGyroSense].VMax = 3;
  Vars [cSysIdle].VMax = 1100;
  Vars [cSysIdleMax].VMax = 10000;
  Vars [cTimeSleep].VMax = 99999;
  // Add your min max values for your variables here !!!
}

void DefaultVars (void)
{
  Vars [cMagicNr].Value = cMagicNrDef;
  Vars [cLayout].Value = 2;
  Vars [cSysIdleMax].Value = 1086;
  Vars [cMenuStatus1].Value = (1 << cShowPWKeys);
  Vars [cMotTime].Value = 1;
  Vars [cMotSense].Value = 10;
  Vars [cAccSense].Value = 0;
  Vars [cGyroSense].Value = 1;
  Vars [cPassword1].Value = 0x0600082a;
  Vars [cPassword2].Value = 0x06000d7f;
  Vars [cTimeSleep].Value = cSleepTime;
  // default init your Vars here !!!
}

//----------------------------------------------------------------------------
// Userdefined Vars callback functions for menubase library module
//----------------------------------------------------------------------------
int32 GetVal (uns8 index)
{
  Vars [index].changed = 0;
  return Vars [index].Value;
}

void SetVal (uns8 index, int32 val)
{
  if (Vars [index].Value != val)
  {
    Vars [index].Value = val;
    Vars [index].changed = 1;
  }
}

void SetValChanged (uns8 index, uns8 changed)
{
  Vars [index].changed = changed;
}

uns8 ValChanged (uns8 index)
{
  uns8 b = Vars [index].changed;
  Vars [index].changed = 0;
  return b;
}

int32 GetValMin (uns8 index)
{
  return Vars [index].VMin;
}

void SetValMin (uns8 index, int32 val)
{
  Vars [index].VMin = val;
}

int32 GetValMax (uns8 index)
{
  return Vars [index].VMax;
}

void SetValMax (uns8 index, int32 val)
{
  Vars [index].VMax = val;
}

uns8 GetValBitNr (uns8 index)
{
  return Vars [index].bitnr;
}

void SetValBitNr (uns8 index, uns8 bitnr)
{
  Vars [index].bitnr = bitnr;
}

uns8 ValBitChanged (uns8 index, uns8 bitnr)
{
  uns32 bit = 1<<bitnr;
  int32 v = Vars [index].Value;
  uns8 b = (v & bit) != (Vars [index].VMin & bit);
  if (v & bit)
    Vars [index].VMin |= bit;
  else
    Vars [index].VMin &= ~bit;
  return b;
}

uns8 ValBitSet (uns8 index, uns8 bitnr)
{
  return (Vars [index].Value & (1<<bitnr)) != 0;
}

void SetValBit (uns8 index, uns8 bitnr, uns8 bitval)
{
  uns32 bit = 1<<bitnr;
  if (bitval != 0)
  {
    Vars [index].Value |= bit;
    Vars [index].VMin &= ~bit;
  }
  else
  {
    Vars [index].Value &= ~bit;
    Vars [index].VMin |= bit;
  }
}

//----------------------------------------------------------------------------
void SetValOnChg (uns8 index, int32 val)
{
  if (Vars [index].changed == 0)
    SetVal (index, val);
}

void SetValBitOnChg (uns8 index, uns8 bitnr, uns8 bitval)
{
  if (! ValBitChanged (index, bitnr))
    SetValBit (index, bitnr, bitval);
}

void AddToVal (uns8 varidx, int32 val, uns8 fzyk)
{
  int32 vmin = Vars [varidx].VMin,
        vmax = Vars [varidx].VMax;
  Vars [varidx].Value += val;
  if (fzyk)
    Vars [varidx].Value = MinMaxValZyk (Vars [varidx].Value, vmin, vmax);
  else
    Vars [varidx].Value = MinMaxVal (Vars [varidx].Value, vmin, vmax);
  Vars [varidx].changed = 1;
}

//-------------------- user code --------------------------------------------
