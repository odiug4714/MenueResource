//----------------------------------------------------------------------------
// Menus.c  Autor: Guido Kahle 06/2017
//----------------------------------------------------------------------------
#include "MenuBase.h"
#include "MenueResource.h"
#include "Menues.h"
#include "Vars.h"
#include "delay.h"
#include "rtcF10x.h"
#include "LCD.h"
#include "Touch.h"

//----------------------------------------------------------------------------
// Constants
//----------------------------------------------------------------------------
#define cAlarmTime    500 // (x 10ms)

//----------------------------------------------------------------------------
// global variables
//----------------------------------------------------------------------------
extern tVar        Vars [cVarMax];             // Eingabe-Variablen

static uns8        FooterStart = 0,            // Menu-Sync f. DisplayTask
                   clockstarted = 0,           // Stoppuhr gestartet
                   InitSysIdle = 0;            // init by max value change
static tValueBar   VBSysIdle;                  // System load
static RTC_t       DateTime,                   // Clock paras
                   OldDateTime,                // DateTime show filter
                   SWDT;                       // DateTime Stopp Watch
static uns32       refCounter;                 // Stoppuhr Referenzz�hler

//----------------------------------------------------------------------------
// Funcs
//----------------------------------------------------------------------------
extern void UsartDebWrite (char *ptext);       // Debug
extern void MenuSleep (uns16 ms);
extern void WriteEEPromData (void);

static void InitFooter (void);

//----------------------------------------------------------------------------
// Menue-Strings
//----------------------------------------------------------------------------
static const char StrAlarmEvt []  = "Alarm",
                  StrSKNix []     = "",
                  StrPoint []     = ".",
                  StrLine []      = "|",
                  StrColon []     = ":",
                  StrStart []     = "Start",
                  StrStopp []     = "Stopp",
                  StrSpeedTest [] = "Display Speed",
                  StrWarnSave []  = " wirklich|speichern ?",
                  StrWarnDel []   = "wirklich|loeschen ?";
// Add your strings here !!!

//----------------------------------------------------------------------------
// Menue-Callback-Functions
//----------------------------------------------------------------------------
void CallBackService (void *pMH, tCBCallMode mode, uns8 SKey)
{
  if (mode == eOnItem)
  {
    tMenuHandle *pHM = (tMenuHandle*) pMH;
    if (IsIn_tStr ("Save", pHM->SoftKeys [SKey].Text) && ShowMsgBox (pHM, "Warn", StrWarnSave))
    {
#ifdef _UseEEP
      WriteEEPromData ();
#endif
    }
  }
}

static void ColorBox (void)
{
  uns16 RGBVal = (Vars [cRed].Value << 11) + (Vars [cGreen].Value << 5) + Vars [cBlue].Value;
  LCD_DrawRect (160, 60, 110, 65, GetCol (cMenuPen));
  LCD_Fill (161, 61, 108, 63, RGBVal);
  char str [9]; // temp. str works with tStr cause no copy is needed
  str [0] = '[';
  ValToStr (RGBVal, &str [1], 0xb40);
  str [7] = ']';
  str [8] = 0;
  uns16 color = LCD_GetBackColor ();
  LCD_SetBackCol (BLACK);
  LCD_ShowString (168, 100, Init_tStr (str), 2, cFont2, WHITE);
  LCD_SetBackCol (color);
}

void CallBackColors (void *pMH, tCBCallMode mode, uns8 SKey)
{
  if (mode == eOnStart)
    ColorBox ();
  else if (mode == eOnPlus || mode == eOnMinus)
  {
    tMenuHandle *pHM = (tMenuHandle*) pMH;
    if (SKey == SKFromVarIndex (pHM, cLayout))
    {
      FooterStart = 0;
      pHM->LayoutNr = Vars [cLayout].Value;
      InitFooter ();
      InitMenuResInterpreter (pHM);
      MenuResourceInterpreter (pHM, Init_tStr ("Colors"));
      pHM->firstDraw = 2;
    }
    else
    {
      int8 f = GetMultiplier ();
      if (mode == eOnMinus)
        f = -f;
      if (SKey == 1)               // R
        AddToVal (cRed, f, 1);
      else if (SKey == 2)          // G
        AddToVal (cGreen, f, 1);
      else if (SKey == 3)          // B
        AddToVal (cBlue, f, 1);
      tObjPtr *pObjPtr = pHM->ObjPtrBuf;
      if (ValChanged (cRed))
      {
        uns8 idx = ObjPtrIndexFromVarIndex (pHM, cRed);
        if (idx != cNoSoftkey && pObjPtr [idx].ptr != 0 && pObjPtr [idx].typ == cObjTypSlider)
        {
          tSlider *pSL = (tSlider*) pObjPtr [idx].ptr;
          UpdateSlider (pSL, pObjPtr [idx].color);
          SetValChanged (cRed, 0);
        }
      }
      else if (ValChanged (cGreen))
      {
        uns8 idx = ObjPtrIndexFromVarIndex (pHM, cGreen);
        if (idx != cNoSoftkey && pObjPtr [idx].ptr != 0 && pObjPtr [idx].typ == cObjTypSlider)
        {
          tSlider *pSL = (tSlider*) pObjPtr [idx].ptr;
          UpdateSlider (pSL, pObjPtr [idx].color);
          SetValChanged (cGreen, 0);
        }
      }
      else if (ValChanged (cBlue))
      {
        uns8 idx = ObjPtrIndexFromVarIndex (pHM, cBlue);
        if (idx != cNoSoftkey && pObjPtr [idx].ptr != 0 && pObjPtr [idx].typ == cObjTypSlider)
        {
          tSlider *pSL = (tSlider*) pObjPtr [idx].ptr;
          UpdateSlider (pSL, pObjPtr [idx].color);
          SetValChanged (cBlue, 0);
        }
      }
    }
    ColorBox ();
  }
  else if (mode == eOnZyk)
  {
    if (ValChanged (cRed) || ValChanged (cGreen) || ValChanged (cBlue))
      ColorBox ();
  }
  else if (mode == eOnItem)
  {
    tMenuHandle *pHM = (tMenuHandle*) pMH;
    if (IsIn_tStr ("Speed", pHM->SoftKeys [SKey].Text))  // Display speed
    {
      int16 i = 0, j = 10, k = 2, t = 200;
      uns16 colors [] = { 0xf800, 0x07e0, 0x0001f };
      while (i < 200)
      {
        LCD_ShowString (1, 135, Init_tStr (StrSpeedTest), 4, cFont2, colors [k]);
        if (t > 0)
        {
          Delayms (t);
          t -= 10;
        }
        else if (j == 0)
        {
          j = 10;
          MenuSleep (20);
        }
        else
          j--;
        if (k-- == 0)
          k = 2;
        i++;
      }
      LCD_Fill (0, 135, 319, 37, LCD_GetBackColor ());
    }
  }
}

static void UpdateStartStop (tMenuHandle *pMH, uns8 started)
{
  uns8 zeroSK = SKFromName (pMH, "Zero"),
       startSK = (started) ? SKFromName (pMH, "Start") : SKFromName (pMH, "Stop");
  if (startSK != cNoSoftkey && zeroSK != cNoSoftkey)
  {
    tStr s;
    if (started)
    {
      s = Init_tStr ("Stop");
      ClrSoftkey (zeroSK);
    }
    else
    {
      s = Init_tStr ("Start");
      EnableSK (zeroSK);
      DrawSoftKey (zeroSK);
    }
    SetSKText (startSK, s);
    DrawSoftKey (startSK);
  }
}

void CallBackClock (void *pMH, tCBCallMode mode, uns8 SKey)
{
  static RTC_t DT;                          // Uhr-Paras
  static uns8  didZero =  0,
               updateZero = 1;
  static uns32 clockcnt = 0,
               oldclockcnt = 0;

  if (mode == eOnStart)
  {
    RTCGetTime (&DT);
    Vars [cStunden].Value = DT.hour;
    Vars [cMinuten].Value = DT.minute;
    Vars [cSekunden].Value = DT.sec;
    Vars [cTag].Value = DT.mday;
    Vars [cMonat].Value = DT.month;
    Vars [cJahr].Value = DT.year - 2000;

    DT.alhour = DT.hour;
    DT.almin = DT.minute;
    DT.alsec = DT.sec;

    Vars [cAlStunden].Value = DT.alhour;
    Vars [cAlMinuten].Value = DT.almin;
    Vars [cAlSekunden].Value = DT.alsec;

    tMenuHandle *pHM = (tMenuHandle*) pMH;
    UpdateStartStop (pHM, clockstarted); // SK start / stopp
    if (! clockstarted)
    {
      refCounter = RTC_GetCounter ();
      didZero = 1;
      updateZero = 1;
    }
  }
  else if (mode == eOnZyk)
  {
    if (clockstarted || updateZero)
    {
      clockcnt = RTC_GetCounter ();
      if (clockcnt != oldclockcnt || updateZero)
      {
        uns16 MenuPenCol = GetCol (cMenuPen);
        oldclockcnt = clockcnt;
        uns32 cnt = clockcnt - refCounter;
        RTCcounter_to_struct (cnt, &SWDT);
        LCD_ShowNum (125, 140, SWDT.hour, 2, cFont2, cLeadingZeros + 0x20, MenuPenCol);
        LCD_ShowNum (161, 140, SWDT.minute, 2, cFont2, cLeadingZeros + 0x20, MenuPenCol);
        LCD_ShowNum (197, 140, SWDT.sec, 2, cFont2, cLeadingZeros + 0x20, MenuPenCol);
      }
      updateZero = 0;
    }
  }
  else if (mode == eOnItem)
  {
    tMenuHandle *pHM = (tMenuHandle*) pMH;
    if (IsIn_tStr ("Set", pHM->SoftKeys [SKey].Text))
    {
      if (IsSwitched (SKey))
      {
        DT.alhour = Vars [cAlStunden].Value;
        DT.almin = Vars [cAlMinuten].Value;
        DT.alsec = Vars [cAlSekunden].Value;
        RTCSetAlarm (&DT);
        RTC_ClearITPendingBit (RTC_IT_ALR); // Clear RTC alarm Flag
        RTC_ITConfig (RTC_IT_ALR, ENABLE);  // Enable alarm interrupt
      }
      else
        RTC_ITConfig (RTC_IT_ALR, DISABLE);  // Disable alarm interrupt
    }
    else if (IsIn_tStr ("Start", pHM->SoftKeys [SKey].Text) ||
             IsIn_tStr ("Stop", pHM->SoftKeys [SKey].Text))
    {
      clockstarted = ! clockstarted;
      tMenuHandle *pHM = (tMenuHandle*) pMH;
      UpdateStartStop (pHM, clockstarted);
      if (didZero)
      {
        refCounter = RTC_GetCounter ();
        didZero = 0;
      }
    }
    else if (IsIn_tStr ("Zero", pHM->SoftKeys [SKey].Text))
    {
      if (! clockstarted)
      {
        refCounter = RTC_GetCounter ();
        didZero = 1;
        updateZero = 1;
      }
    }
  }
  else if (mode == eOnEnd)
  {
    if (ValChanged (cStunden) || ValChanged (cMinuten) || ValChanged (cSekunden) ||
        ValChanged (cTag) || ValChanged (cMonat) || ValChanged (cJahr))
    {
      DT.hour = Vars [cStunden].Value;
      DT.minute = Vars [cMinuten].Value;
      DT.sec = Vars [cSekunden].Value;
      DT.mday = Vars [cTag].Value;
      DT.month = Vars [cMonat].Value;
      DT.year = 2000 + Vars [cJahr].Value;
      DT.wday = 4; // ???
      RTCSetTime (&DT);
    }
  }
}

void CallBackPassword (void *pMH, tCBCallMode mode, uns8 SKey)
{
  static uns32 tippidx = 0;
  static uns8  playcnt = 0;
  if (mode == eOnItem)
  {
    tMenuHandle *pHM = (tMenuHandle*) pMH;
    uns8        SK = GetSelectedSK (pHM),
                fdraw = 0;
    int32       Val = 0;
    if (SK != cNoSoftkey)
    {
      if (SK == 0)                     // PW1
        Val = Vars [cPassword1].Value;
      else if (SK == 1)                // PW2
        Val = Vars [cPassword2].Value;
    }
    if (SKey >= 2 && SKey <= 5)        // SKs in corners
    {
      Val |= (SKey - 2) << tippidx;
      if (tippidx < 24)
        tippidx += 2;
      Val &= 0x00ffffff;
      Val |= (tippidx >> 1) << 24;
      fdraw = 1;
    }
    else if (IsIn_tStr ("DEL", pHM->SoftKeys [SKey].Text) &&
             ShowMsgBox (pHM, "Warn", StrWarnDel))
    {
      tippidx = 0;
      if (SK != cNoSoftkey)
      {
        Val = 0;
        fdraw = 1;
      }
    }
    else if (IsIn_tStr ("Play", pHM->SoftKeys [SKey].Text)) // play key triggers PW show simulation
    {
      playcnt = 0;
      // wait until timers of SoftkeyPressed () run down
      MenuSleep (100);   // give other tasks the chance to run
      SoftkeyPressed (); // reset SK identification when no key is pressed
    }
    if (fdraw)
    {
      if (SK == 0)                     // PW1
        Vars [cPassword1].Value = Val;
      else if (SK == 1)                // PW2
        Vars [cPassword2].Value = Val;
      ShowValueItem (SK);
    }
  }
  else if (mode == eOnZyk)
  {
    tMenuHandle *pHM = (tMenuHandle*) pMH;
    uns8 playSK = SKFromName (pMH, "Play");
    if (IsSwitched (playSK) && TimerExpired (cPWPlayTimer, 20)) // simulate PW show
    {
      uns32 pw = 0;
      uns8  SK = GetSelectedSK (pHM);
      if (SK == 0)
        pw = Vars [cPassword1].Value;
      else if (SK == 1)
        pw = Vars [cPassword2].Value;
      uns8 len = pw >> 24,
           key = ((pw >> (2 * playcnt)) & 0x03) + 2;
      if (key >= 2 && key <= 5 && playcnt < len)
      {
        tMenuHandle *pHM = (tMenuHandle*) pMH;
        tSoftKey *pSK = &pHM->SoftKeys [key];
        Touch_Simulate (pSK->PosX + (pSK->Width >> 1), pSK->PosY + (pSK->Height >> 1));
        SoftkeyPressed (); // turn key on
        while (! TimerExpired (cPWPlayTimer, cPWPlayTime))
          MenuSleep (10);
        SoftkeyPressed (); // turn key off
        playcnt++;
      }
      else
      {
        SetSwitched (playSK, 0);
        DrawSoftKey (playSK);
      }
    }
  }
}

void CallBackIMU (void *pMH, tCBCallMode mode, uns8 SKey)
{
  if (mode == eOnZyk)
  {
#ifdef _UseMPU6500
    MPU6050_ReadAll (&MPU6050);
    SetValOnChg (cACCX, MPU6050.SmartAccX);
    SetValOnChg (cACCY, MPU6050.SmartAccY);
    SetValOnChg (cACCZ, MPU6050.SmartAccZ);
    SetValOnChg (cGyroX, MPU6050.SmartGyroX);
    SetValOnChg (cGyroY, MPU6050.SmartGyroY);
    SetValOnChg (cGyroZ, MPU6050.SmartGyroZ);
    SetValOnChg (cMotion, MPU6050_MotionDetected (&MPU6050) != 0);
    if (ValChanged (cMotTime) || ValChanged (cMotSense))
      MPU6050_SetMotionParas (&MPU6050, Vars [cMotSense].Value, Vars [cMotTime].Value);
    if (ValChanged (cAccSense) || ValChanged (cGyroSense))
      MPU6050_SetSense (&MPU6050, Vars [cAccSense].Value, Vars [cGyroSense].Value);
    SetVal (cI2CError, MPU6050.HI2C.errorcnt);
#endif
  }
}

void CallBackSystem (void *pMH, tCBCallMode mode, uns8 SKey)
{
  if (mode == eOnPlus || mode == eOnMinus)
  {
    tMenuHandle *pHM = (tMenuHandle*) pMH;
    if (SKey == SKFromVarIndex (pHM, cSysIdleMax))
      InitSysIdle = 1;
  }
}

// Fill your main menue callback function !!!
void CallBackMyMainMenue (void *pMH, tCBCallMode mode, uns8 SKey)
{
  // parameters:	*pMH is the menu handle pointer as declared in menubase.h
  //			mode selects the part in this function
  if (mode == eOnStart)
  {
    // this part is called only once at the very beginning of a menue
    // Skey is not valid (cNoSoftKey)
  }
  else if (mode == eOnZyk)
  {
    // this part is called cyclic to update variables cyclicly shown
    // on the display, Skey is the selected SK but check on cNoSoftKey
  }
  else if (mode == eOnPlus || mode == eOnMinus)
  {
    // this part is called once when the user pressed the plus or minus button
    // SKey is the selected Softkey-value nr. not the plus or minus Softkey
  }
  else if (mode == eOnItem)
  {
    // this part is called once when the user pressed on an editable menue item
    // or button, SKey is the selected Softkey
  }
  else if (mode == eOnEnd)
  {
    // this part is called only once when the user pressed the exit button
    // Skey is not valid (cNoSoftKey)
  }
}


// Add your callback functions here !!!


//----------------------------------------------------------------------------
// Menue-Resource-Lookuptable
//----------------------------------------------------------------------------
const tMRLT MenuResTable [] = cMenuResTable;

static void InitMenuRessourceTable (tMenuHandle *pMH)
{
  pMH->pMRLT = MenuResTable;
  InitMenuRessources (pMH);
}

//----------------------------------------------------------------------------
// Footer
//----------------------------------------------------------------------------
void HandleFooter () // wird zyklisch in der Displaytask aufgerufen
{
  if (! FooterStart)
    return;
  else if (FooterStart == 2) // init. new footer line
  {
    FooterStart = 1;
  }
  uns16 MenuSLCol = GetCol (cMenuSubLine),
        VBarCol = GetCol (cMenuBarPen);
  LCD_SetBackCol (GetCol (cMenuSubLineBG));
  uns32 clockcnt = RTC_GetCounter ();
  RTCcounter_to_struct (clockcnt, &DateTime);
  RTCadjustDST (&DateTime);
  if (DateTime.hour != OldDateTime.hour)
    LCD_ShowNum (283, 222, DateTime.hour, 1, cFont1, cLeadingZeros + 0x20, MenuSLCol);
  if (DateTime.minute != OldDateTime.minute)
    LCD_ShowNum (301, 222, DateTime.minute, 1, cFont1, cLeadingZeros + 0x20, MenuSLCol);
  //LCD_ShowNum (301, 229, DateTime.sec, 1, cLeadingZeros + 0x20, MenuSLCol);
  if (DateTime.mday != OldDateTime.mday)
    LCD_ShowNum (243, 222, DateTime.mday, 1, cFont1, cLeadingZeros + 0x20, MenuSLCol);
  if ( DateTime.month != OldDateTime.month)
     LCD_ShowNum (261, 222, DateTime.month, 1, cFont1, cLeadingZeros + 0x20, MenuSLCol);
  //LCD_ShowNum (241, 229, DateTime.year, 1, cLeadingZeros + 0x20, MenuSLCol);
  OldDateTime = DateTime;

  if (InitSysIdle)
  {
    Vars [VBSysIdle.VarIdx].VMax = Vars [cSysIdleMax].Value;
    InitValueBar (&VBSysIdle, 2, 221, 50, 16, cSysIdle, cBarOptHor);
    Vars [VBSysIdle.VarIdx].changed = 1;
    InitSysIdle = 0;
  }
  if (Vars [VBSysIdle.VarIdx].changed)
  {
    ShowValueBar (&VBSysIdle, VBarCol);
    Vars [VBSysIdle.VarIdx].changed = 0;
  }
  if (ValBitSet (cMenuStatus1, cAlarm1))
  {
    LCD_ShowString (120, 222, Init_tStr (StrAlarmEvt), 1, cFont1, MenuSLCol);
    SetTimer (cTimerAlarm, cAlarmTime);
    SetValBit (cMenuStatus1, cAlarm1, 0);
    SetValBit (cMenuStatus1, cAlarm2, 1);
  }
  else if (ValBitSet (cMenuStatus1, cAlarm2))
  {
    if (TimerExpired (cTimerAlarm, 0))
    {
      LCD_ShowString (120, 222, Init_tStr ("     "), 1, cFont1, MenuSLCol);
      SetValBit (cMenuStatus1, cAlarm2, 0);
    }
  }
  LCD_SetBackCol (GetCol (cMenuBackGnd));
}

static void InitFooter (void)
{
  uns16 MenuSLCol = GetCol (cMenuSubLine);
  LCD_SetBackCol (GetCol (cMenuSubLineBG));
  LCD_Fill (0, cBottomLine, LCD_GetOpts ()->width-1, LCD_GetOpts ()->height-1 - cBottomLine, GetCol (cMenuSubLineBG));
  //LCD_ShowString (35 - LCD_GetTextLen (StrSys, 1), 222, StrSys, 1, MenuSLCol);
  //LCD_ShowString (277, 221, StrColon, 1, MenuSLCol);
  LCD_ShowString (295, 222, Init_tStr (StrColon), 1, cFont1, MenuSLCol);
  //LCD_ShowString (217, 221, StrPoint, 1, MenuSLCol);
  LCD_ShowString (275, 222, Init_tStr (StrLine), 1, cFont1, MenuSLCol);
  LCD_ShowString (257, 222, Init_tStr (StrPoint), 1, cFont1, MenuSLCol);
  LCD_SetBackCol (GetCol (cMenuBackGnd));
  LCD_Fill (0, 0, LCD_GetOpts ()->width-1, cBottomLine-1, GetCol (cMenuBackGnd));
  InitValueBar (&VBSysIdle, 2, 221, 50, 16, cSysIdle, cBarOptHor);
  OldDateTime.hour = OldDateTime.minute = OldDateTime.mday = OldDateTime.month = 255;
  FooterStart = 2;
}

//----------------------------------------------------------------------------
// Password menue
//----------------------------------------------------------------------------
/*
  Touch positions on the display (display corners):
  -------------
  |0         1|
  |     4     |
  |2         3|
  -------------
  4 = reset input
*/

static int8 PWComparePos (uns8 SK, uns8 *pidx, uns8 *pstatus)
{
  // returns 0  : check in progress
  // returns 1  : PW 1 ok
  // returns 2  : PW 2 ok
  // returns -1 : new start of check
  uns8  i = 2 * (*pidx),
        res = 0;
  uns32 mask  = 3 << i;
  uns8  l1 = Vars [cPassword1].Value >> 24,
        l2 = Vars [cPassword2].Value >> 24,
        sk1 = (Vars [cPassword1].Value & mask) >> i,
        sk2 = (Vars [cPassword2].Value & mask) >> i;
  (*pidx)++;
  if (*pstatus == 0)
  {
    if (SK == sk1 && SK == sk2)
    {
      if (*pidx == l1)
        res = (*pidx == l1) ? 1 : 0;
      else if (*pidx == l2)
        res = (*pidx == l2) ? 2 : 0;
      else
        res = 0;
    }
    else if (SK == sk1 && SK != sk2)
    {
      *pstatus = 1;
      res = (*pidx == l1) ? 1 : 0;
    }
    else if (SK != sk1 && SK == sk2)
    {
      *pstatus = 2;
      res = (*pidx == l2) ? 2 : 0;
    }
    else
    {
      *pidx = 0;
      *pstatus = 0;
      res = -1;
    }
  }
  else if (*pstatus == 1 && SK == sk1)
    res = (*pidx == l1) ? 1 : 0;
  else if (*pstatus == 2 && SK == sk2)
    res = (*pidx == l2) ? 2 : 0;
  else
  {
    *pidx = 0;
    *pstatus = 0;
     res = -1;
  }
  return res;
}

static uns8 PasswordMenu ()
{
  tMenuHandle *pMH = GetMenuHandle ();
  int8        res = 0;
  uns8        fEnd = 0, noKey = 1, status = 0, i = 0;
  MenuSleep (cDefSleepTime);
  LCD_Clear (LCD_GetBackColor ());
  InitMenuResInterpreter (pMH);
  pMH->HideConcealableSKs = 1;
  MenuResourceInterpreter (pMH, Init_tStr ("PW"));
  if (ValBitSet (cMenuStatus1, cShowPWKeys))
  {
    for (uns8 i = 0; i < pMH->NumSoftKeys; i++)
    {
      pMH->SoftKeys [i].Options |= cSKFrame;
      DrawSoftKey (i);
    }
  }
  while (! fEnd)
  {
    MenuSleep (cDefSleepTime);
    uns8 SK = SoftkeyPressed ();
    if (SK >= 0 && SK <= 4)
    {
      res = PWComparePos (SK, &i, &status);
      if (noKey && res >= 0)
        noKey = 0;
      else if (noKey)
        noKey = 0;
    }
    else if (SK == cNoSoftkey)
      noKey = 1;
    else
      noKey = 0;
    if (res > 0)
      fEnd = 1;
  }
  return res; // returns PWNr
}

//----------------------------------------------------------------------------
// Main menue
//----------------------------------------------------------------------------
void MainMenu (void)
{
  tMenuHandle *pMH = GetMenuHandle ();
  FooterStart = 0;
  pMH->LayoutNr = Vars [cLayout].Value;
  pMH->ScrollVarIdx = cScrollBar;
  MenuBaseInit ();
  InitMenuRessourceTable (pMH);
  // password menue
  uns8 PW = 0;
  if (ValBitSet (cMenuStatus1, cPassword))
    PW = PasswordMenu ();
  pMH->HideConcealableSKs = PW == 1; // filter concealable SKs with Password 1
  // init. footer and main menue
  InitFooter ();
  MenuHandler (pMH, Init_tStr ("MainMenue"));
}
