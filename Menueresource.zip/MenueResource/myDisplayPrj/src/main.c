#include "stm32f10x_conf.h"
#include "delay.h"
#include "basedefs.h"
#include "myGPIO.h"
#include "myUSART.h"
#include "myI2C.h"
#include "mpu6050.h"
#include "rtcF10x.h"
#include "Buttons_LEDs.h"
#include "LCD.h"
#include "touch.h"
#include "Vars.h"
#include "MenuBase.h"
#include "MenueResource.h"
#include "menues.h"

// FreeRTOS includes
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"

#define LED1_Port      GPIOB
#define LED1_Pin       GPIO_Pin_1

#define USRBUT1_Port   GPIOB
#define USRBUT1_Pin    GPIO_Pin_8

#define cBaudrate      115200

#define cI2CEEPAdr     0xa0
#define EEPI2C         I2C2

#define Standby_Port   GPIOA
#define Standby_Pin    GPIO_Pin_0

/* ST-Link connection:
3.3V   Pin 1
GND    Pin 2
SWDIO  Pin 3
SWCLK  Pin 4
SWIM   Pin 5
RST    Pin 6
*/

#ifdef _UseMPU6500
static MPU6050_t MPU6050;
#endif
#ifdef _UseEEP
static HI2C_t    HEEP;
#endif
uns32            TickCnt = 0,
                 IdleCnt = 0;
tVar             Vars [cVarMax]; // System variables
HLED_t           HLED1;
xSemaphoreHandle FooterSyncSem = NULL;

//-----------------------------------------------------------
// Usart send and receive
//-----------------------------------------------------------
#ifdef _UseUsart
void Usart2ReceiveCallBack (char c)
{


}
#endif

void UsartDebWrite (char *ptext)
{
#ifdef _UseUsart
#ifdef _Debug
  UsartSend (USART2, ptext);
#endif
#endif
}

void UsartWrite (char *ptext)
{
#ifdef _UseUsart
  UsartSend (USART2, ptext);
#endif
}

//-----------------------------------------------------------
// Power
//-----------------------------------------------------------
void PowerDown (void)
{
#ifdef _PwrDown
  UsartDebWrite ("\r\nPower Down\r\n");
  LEDAus (&HLED4);
  LCD_SetBackLight (0);
  LCD_PowerDown ();
  //MPU6050_Sleep (&MPU6050);
  PWR_WakeUpPinCmd (DISABLE);
  Delayms (100);
  PWR_ClearFlag (PWR_FLAG_SB);
  Delayms (100);
  PWR->CR |= 0x00000100;
  PWR_WakeUpPinCmd (ENABLE);
  // Request to enter STANDBY mode (Wake Up flag
  // is cleared in PWR_EnterSTANDBYMode function)
  PWR_EnterSTANDBYMode ();
  PWR_WakeUpPinCmd (DISABLE);
  NVIC_SystemReset ();
#endif
}

//-----------------------------------------------------------
// IRQs
//-----------------------------------------------------------
void RTC_IRQHandler (void)
{
  if (! ValBitSet (cMenuStatus1, cAlarm1) && ! ValBitSet (cMenuStatus1, cAlarm2))
    SetValBit (cMenuStatus1, cAlarm1, 1);
  UsartDebWrite ("\r\nRTC-Alarm\r\n");
  RTC_ClearITPendingBit( RTC_IT_ALR);
  EXTI_ClearITPendingBit (EXTI_Line17);
}

//-----------------------------------------------------------
// RTOS Hooks
//-----------------------------------------------------------
void vApplicationMallocFailedHook (void)
{
  taskDISABLE_INTERRUPTS ();
  UsartDebWrite ("\r\nFehler Malloc !\r\n");
  for ( ; ; );
}

void vApplicationStackOverflowHook (TaskHandle_t pxTask, char *pcTaskName)
{
  taskDISABLE_INTERRUPTS ();
  UsartDebWrite ("\r\nStackoverflow !\r\n");
  for ( ; ; );
}

void vApplicationTickHook (void)
{
//LED2An;
  TickCnt++;
//LED2Aus;
}

void vApplicationIdleHook (void)
{

//LED2An;
  IdleCnt++;
//LED2Aus;
}

//-----------------------------------------------------------
// Control_Task for operational/functional user code
//-----------------------------------------------------------
static void Ctrl_Task (void *parameters)
{
  tMenuHandle *pMH = GetMenuHandle ();

  SetTimer (cSleepTimer, Vars [cTimeSleep].Value);

  // Used to wakeup the task at the correct frequency
  portTickType xLastExecutionTime = xTaskGetTickCount ();
  for ( ; ; )
  {
    vTaskDelayUntil (&xLastExecutionTime, pdMS_TO_TICKS (10)); // sleep for 10 ms

#ifdef _PwrDown
    if (Vars [cPwrDown].Value > 0 && Vars [cTimeSleep).Value > 0)
    {
      if (TimerExpired (Vars [cTimeSleep).Value, 0))
        PowerDown ();
    }
#endif
    DecTimers (); // handle our timers



    // Put your functional code in here !!!
    // this part is cyclic called every 10 ms
    uns8 MenuIndex = GetMenuIndex (pMH);
    if (MenuIndex == cMenuMainIdx)
    {
      // do something if we are in main menue


    }



  }
}

//-----------------------------------------------------------
// Footer task
//-----------------------------------------------------------
static void Footer_Task (void *parameters)
{
  uns32 OldTickCnt = 0, OldIdleCnt = 0;
  int32 OldSysIdle = 0;

  portTickType xLastExecutionTime = xTaskGetTickCount ();
  for ( ; ; )
  {
    vTaskDelayUntil (&xLastExecutionTime, pdMS_TO_TICKS (300)); // alle 300 ms
    if (xSemaphoreTake (FooterSyncSem, 0) == pdTRUE)
    {
      Vars [cSysIdle].Value = (IdleCnt - OldIdleCnt) / (TickCnt - OldTickCnt);
      if (Vars [cSysIdle].Value > OldSysIdle + 10 || Vars [cSysIdle].Value < OldSysIdle - 10)
        Vars [cSysIdle].changed = 1;
      OldSysIdle = Vars [cSysIdle].Value;
      HandleFooter ();
      OldTickCnt = TickCnt;
      OldIdleCnt = IdleCnt;
      xSemaphoreGive (FooterSyncSem);
    }
  }
}

//-----------------------------------------------------------
// Menu_Task
//-----------------------------------------------------------
// sysnchronizes menutask's display access,
// menu task gives other tasks a chance to run
void MenuSleep (uns16 ms)
{
  xSemaphoreGive (FooterSyncSem);
  vTaskDelay (pdMS_TO_TICKS (ms));
  xSemaphoreTake (FooterSyncSem, portMAX_DELAY);
}

void ResetSleepTimer (void) // menu task: user pressed a key
{
  SetTimer (cSleepTimer, Vars [cTimeSleep].Value);
}

static void Menu_Task (void *parameters)
{
  xSemaphoreTake (FooterSyncSem, portMAX_DELAY);
  for ( ; ; )
  {
    LEDAn (&HLED1);
    MainMenu ();
    if (ValBitSet (cMenuStatus1, cPwrDown))
      PowerDown ();
  }
}

//-----------------------------------------------------------
// EEProm
//-----------------------------------------------------------
#ifdef _UseEEP

#define cVarsPerPage   (cEEPromPageSize << 2)
#define cMaxSaveVars   11                     // 32 vars per EEP-page
uns8 SaveVarIndices [cMaxSaveVars] =          // cMagicNr must be the 1. one
{
  cMagicNr, cLayout, cSysIdleMax, cMenuStatus1,
  cMotTime, cMotSense, cAccSense, cGyroSense,
  cPassword1, cPassword2, cTimeSleep
  // save your Vars ion EEP here, increase cMaxSaveVars !!!
};

void WriteEEPromData (void)
{
  tEEPromPage aPage;
  int32       *p;
  int16       MaxSaveVars = cMaxSaveVars;
  uns8        pagecnt = cMaxSaveVars / cVarsPerPage + (cMaxSaveVars % cVarsPerPage != 0),
              res = 1;
  for (uns8 n = 0; n < pagecnt && res; n++)
  {
    for (uns8 i = 0; i < cEEPromPageSize; i++)
      aPage.buf [i] = 0;
    uns8 vcnt = MaxSaveVars >= cVarsPerPage ? cVarsPerPage : MaxSaveVars;
    for (uns8 i = 0; i < vcnt; i++)
    {
      uns8 varidx = SaveVarIndices [i];
      p = (int32*) &aPage.buf [i * 4];
      *p = Vars [varidx].Value;
    }
    MaxSaveVars -= cVarsPerPage;
    res = EEPromWritePage (&HEEP, n, &aPage);
  }
  if (res)
    UsartDebWrite ("schreibe EEProm-Daten\r\n");
  else
    UsartDebWrite ("Error EEProm-Daten\r\n");
}

uns8 InitEEPromData (void)
{
  tEEPromPage aPage;
  int32       *p = (int32*) &aPage.buf [0], *p0 = p;
  int16       MaxSaveVars = cMaxSaveVars;
  uns8        pagecnt = cMaxSaveVars / cVarsPerPage + (cMaxSaveVars % cVarsPerPage != 0),
              res = 1, done = 0;
  UsartDebWrite ("lese EEProm-Daten\r\n");
  for (uns8 n = 0; n < pagecnt && res; n++)
  {
    for (uns8 i = 0; i < cEEPromPageSize; i++)
      aPage.buf [i] = 0;
    res = EEPromReadPage (&HEEP, n, &aPage);
    if (res)
    {
      done = n != 0 || *p0 == cMagicNrDef; // check if EEP is initialized
      if (done)
      {
        uns8 vcnt = MaxSaveVars >= cVarsPerPage ? cVarsPerPage : MaxSaveVars;
        for (uns8 i = 0; i < vcnt; i++)
        {
          uns8 varidx = SaveVarIndices [i];
          p = (int32*) &aPage.buf [i * 4];
          Vars [varidx].Value = *p;
        }
        MaxSaveVars -= cVarsPerPage;
      }
    }
  }
  if (! done) // Default-Init
  {
    UsartDebWrite ("Initialisiere Default-EEProm-Daten\r\n");
    DefaultVars ();
    WriteEEPromData ();
  }
  SetValBit (cMenuStatus1, cEEPOk, done);
  return done;
}
#endif
//-----------------------------------------------------------
// Inits
//-----------------------------------------------------------
void ClockInfo (void)
{
  char str [10];

  RCC_ClocksTypeDef RCC_Clocks;
  RCC_GetClocksFreq (&RCC_Clocks);

  UsartDebWrite ("SysClock: ");
  ValToStr (RCC_Clocks.SYSCLK_Frequency, str, 0x90);
  UsartDebWrite (str);
  UsartDebWrite (" MHz\r\nHClock:   ");
  ValToStr (RCC_Clocks.HCLK_Frequency, str, 0x90);
  UsartDebWrite (str);
  UsartDebWrite (" MHz\r\nPClock1: ");
  ValToStr (RCC_Clocks.PCLK1_Frequency, str, 0x90);
  UsartDebWrite (str);
  UsartDebWrite (" MHz\r\nPClock2: ");
  ValToStr (RCC_Clocks.PCLK2_Frequency, str, 0x90);
  UsartDebWrite (str);
  UsartDebWrite (" MHz\r\n");
}

#ifdef _UseMPU6500
void InitMPU6050 (void)
{
  MPU6050.HI2C.I2Cx = MPU6050_I2C;
  MPU6050.HI2C.address = MPU6050_I2C_ADDR | cMPU6050_Device_0;
  MPU6050.HI2C.pinpack = MPU6050_I2C_PINPACK;
  if (MPU6050_Init (&MPU6050, Vars [cAccSense].Value, Vars [cGyroSense].Value) != cMPU6050_ResOk)
	UsartDebWrite ("MPU6050 Error\r\n");
}
#endif

#ifdef _UseEEP
void InitEEProm (void)
{
  HEEP.address = cI2CEEPAdr;
  HEEP.I2Cx = EEPI2C;
  HEEP.pinpack = cI2C_PinPack_1;
  InitI2C (&HEEP);
  InitEEPromData ();
}
#endif

void InitLEDs (void)
{
  InitLED (&HLED1, LED1_Port, LED1_Pin, cLEDBut_ActiveHigh);
}

void InitButtons (void)
{

}

void init (void)
{
  MODIFY_REG(AFIO->MAPR, AFIO_MAPR_SWJ_CFG, AFIO_MAPR_SWJ_CFG_JTAGDISABLE);
  MODIFY_REG (AFIO->MAPR, AFIO_MAPR_SWJ_CFG, AFIO_MAPR_SWJ_CFG_NOJNTRST);
  RCC_APB2PeriphClockCmd (RCC_APB2ENR_AFIOEN, ENABLE);
  GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR,ENABLE);
  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_CRC, ENABLE);
  DELAY_Init ();
  InitLEDs ();
  InitButtons ();
  InitRTC ();
#ifdef _UseUsart
  InitUsart (USART2, cUSART_Pinpack_1, cBaudrate);
#endif
#ifdef _UseEEP
  InitEEProm ();
#else
  DefaultVars ();
#endif
#ifdef _UseMPU6500
  InitMPU6050 ();
#endif
  //LCD_Init ();        // predefined init. doesnt match
  LCD_Handle_t myHLCD;
  myHLCD.LCDSPI.SPIx = SPI1;
  myHLCD.LCDSPI.pinpack = cSPI_PinPack_2;
  myHLCD.DMASPI_TXChan = DMA1_Channel3;
  myHLCD.DMASPI_TX_IRQ = DMA1_Channel3_IRQn;
  myHLCD.DMA_TX_Ready = DMA1_IT_TC3;
  myHLCD.LCD_CSPort = GPIOA;
  myHLCD.LCD_CSPin = GPIO_Pin_12;
  myHLCD.LCD_DCPort = GPIOB;
  myHLCD.LCD_DCPin = GPIO_Pin_6;
  myHLCD.LCD_RSTPort = GPIOB;
  myHLCD.LCD_RSTPin = GPIO_Pin_7;
  myHLCD.LCD_BLPort = GPIOA;
  myHLCD.LCD_BLPin = GPIO_Pin_11;
  LCD_Init_Custom (&myHLCD);        // custom init.

/*
  Touch_Handle_t TH;
  TH.CS_Port = GPIOA;
  TH.CS_Pin = GPIO_Pin_7;
  TH.PIRQ_Port = GPIOA;
  TH.PIRQ_Pin = GPIO_Pin_4;
  TH.DIN_Port = GPIOA;
  TH.DIN_Pin = GPIO_Pin_6;
  TH.DOUT_Port = GPIOA;
  TH.DOUT_Pin = GPIO_Pin_5;
  TH.DCLK_Port = GPIOB;
  TH.DCLK_Pin = GPIO_Pin_0;
  Touch_Init_Custom (&TH);          // custom init.
*/
  Touch_Init ();         // predefined init. matches
  InitVars ();
}

//-----------------------------------------------------------
// main (init and task creation)
//-----------------------------------------------------------
int main (void)
{
  init ();

  ClockInfo ();

#ifdef _UseUsart
  char  str [10];
  uns16 hs = xPortGetFreeHeapSize ();
  ValToStr (hs, str, 0x50);
  UsartDebWrite ("Heap: "); UsartDebWrite (str);
#endif

  vSemaphoreCreateBinary (FooterSyncSem);

  xTaskCreate (Ctrl_Task,   "CtrlTask", configMINIMAL_STACK_SIZE * 2, NULL, tskIDLE_PRIORITY + 3, NULL);
  xTaskCreate (Menu_Task,   "MenuTask", configMINIMAL_STACK_SIZE * 4, NULL, tskIDLE_PRIORITY + 2, NULL);
  xTaskCreate (Footer_Task, "FootTask", configMINIMAL_STACK_SIZE * 2, NULL, tskIDLE_PRIORITY + 1, NULL);

#ifdef _UseUsart
  hs = xPortGetFreeHeapSize ();
  ValToStr (hs, str, 0x50);
  UsartDebWrite ("\r\nHeap: "); UsartDebWrite (str);
  UsartDebWrite ("\r\nStarte Scheduler\r\n");
#endif

  vTaskStartScheduler (); // Order the scheduler to start scheduling our tasks

  for ( ; ; );  // never end up here
}
