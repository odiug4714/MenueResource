#ifndef MENUES_H
#define MENUES_H

void HandleFooter (void);
void MainMenu (void);

#endif
