#ifndef Vars_H
#define Vars_H

#include "basedefs.h"

// configure your hardware, uncomment to use !!!
//#define _Debug
//#define _PwrDown
//#define _UseUsart
//#define _UseEEP
//#define _UseMPU6500

// Variablenindices
#define cVarMax              48 // nr. of Vars !!!

#define cMagicNr              0 // reserved by system, MUST be index 0, always and forever!
#define cScrollBar            1 // reserved by system
#define cSysIdle              2 // reserved by system
#define cMenuStatus1          3 // bitfield reserved by system
#define cPassword1            4 // reserved by system
#define cPassword2            5 // reserved by system
#define cSysIdleMax           6 // reserved by system
#define Reserved7             7
#define Reserved8             8
#define cLayout               9 // reserved by system
#define cStunden             10
#define cMinuten             11
#define cSekunden            12
#define cAlStunden           13
#define cAlMinuten           14
#define cAlSekunden          15
#define cTag                 16
#define cMonat               17
#define cJahr                18
#define cStopWatchMin        19
#define cStopWatchSec        20
#define cTimeSleep           21
#define cRed                 22
#define cGreen               23
#define cBlue                24
#define cACCX                25
#define cACCY                26
#define cACCZ                27
#define cGyroX               28
#define cGyroY               29
#define cGyroZ               30
#define cMotion              31
#define cMotTime             32
#define cMotSense            33
#define cAccSense            34
#define cGyroSense           35
// Add your variables here !!!

// MenuStatus1-bits
#define cAlarm1              0
#define cAlarm2              1
#define cPassword            2
#define cPwrDown             3
#define cEEPOk               4
#define cShowPWKeys          5
// Add your variable bit numbers here !!!

// timers start with index 3
#define cTimerAlarm    3      // start timers with index 3
#define cSleepTime     12000  // 2 Minuten
#define cSleepTimer    4
#define cPWPlayTime    50     // 0.5 sec.
#define cPWPlayTimer   5

#define cMagicNrDef    0x6fd3 // change forces new EEP init.

typedef struct           // Softkey value
{
  int32 Value,           // value
        VMin,            // min value or index to a reference var if this var is a bitfield
        VMax;            // max value
  uns8  changed,         // value was changed
        bitnr;           // temporary value: 0 = normal Var, > 0 = bitfield for 32 bit values
} tVar;

void InitVars       (void);
void DefaultVars    (void);
void AddToVal       (uns8 varidx, int32 val, uns8 fzyk);
void SetValOnChg    (uns8 index, int32 val);
void SetValBitOnChg (uns8 index, uns8 bitnr, uns8 bitval);
void SetValChanged  (uns8 index, uns8 changed);

//----------------------------------------------------------------------------
// Userdefined Vars callback functions for menubase library module
//----------------------------------------------------------------------------
int32 GetVal        (uns8 index);
void  SetVal        (uns8 index, int32 val);
uns8  ValChanged    (uns8 index);
int32 GetValMin     (uns8 index);
void  SetValMin     (uns8 index, int32 val);
int32 GetValMax     (uns8 index);
void  SetValMax     (uns8 index, int32 val);
uns8  GetValBitNr   (uns8 index);
void  SetValBitNr   (uns8 index, uns8 bitnr);
uns8  ValBitChanged (uns8 index, uns8 bitnr);
uns8  ValBitSet     (uns8 index, uns8 bitnr);
void  SetValBit     (uns8 index, uns8 bitnr, uns8 bitval);

//-------------------- user code --------------------------------------------

#endif
