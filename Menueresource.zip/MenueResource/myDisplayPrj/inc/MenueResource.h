#ifndef __MENUERESOURCE_H
#define __MENUERESOURCE_H

// idea: this file could be automatically generated
//       by a graphical menue generator program

//----------------------------------------------------------------------------
// Menue-Indices
//----------------------------------------------------------------------------
// the indices follow the index of the menu lookup table
#define cMenuMainIdx     2
#define cMenuServiceIdx  3
#define cMenuUhrIdx      4
#define cMenuFarbenIdx   5
#define cMenuIMUIdx      6
#define cMenuPasswordIdx 7
#define cMenuStatusIdx   8
#define cMenuSystemIdx   9

//----------------------------------------------------------------------------
// Menue ressource strings
//----------------------------------------------------------------------------
static const char MenuPWRes [] =
"T:;"
"M:=,SO=0x4,X=1,Y=1,H=100,W=100;"
"M:=,SO=0x4,X=219,Y=1,H=100,W=100;"
"M:=,SO=0x4,X=1,Y=139,H=100,W=100;"
"M:=,SO=0x4,X=219,Y=139,H=100,W=100;"
"M:=,SO=0x4,X=110,Y=70,H=100,W=100";

static const char MenuMsgBoxRes [] =
"T:Warning,TY=12,X=70,Y=50,H=150,W=180,R=16;"
"M:<Msg>,TY=5,X=100,Y=90;"
"M:Yes=,TY=10,SO=0x46,X=90,Y=145,H=40,W=60;"
"M:No=,TY=10,SO=0x46,X=170,Y=145,H=40,W=60";

static const char MyMainMenuRes [] =
"T:MainMenue;"
"M: put your items here !!!,TY=5,Y=40;"
"M:Service=,TY=10,SO=0x6,X=5,Y=175,H=40,W=100,CA=Service;"
"M:Exit=,TY=10,SO=0x46,X=225,Y=175,H=40,W=90";

static const char MenuServiceRes [] =
"T:Service;"
"M:Clock =,TY=10,SO=0x5,CA=Clock;"
"M:Colors=,TY=10,SO=0x5,CA=Colors;"
"M: IMU  =,TY=10,SO=0x5,CA=IMU;"
"M:Passwd=,TY=10,SO=0x5,CA=Password;"
"M:Status=,TY=10,SO=0x5,CA=Status;"
"M:System=,TY=10,SO=0x5,X=105,Y=35,CA=System;"
"M:Save=,TY=10,SO=0x6,X=110,Y=175,H=40,W=100;"
"M:Exit=,TY=10,SO=0x46,X=215,Y=175,H=40,W=100";

static const char MenuClockRes [] =
"T:Clock;"
"M:Time,TY=5,Y=40;"
"M:Date,TY=5,Y=70;"
"M:Alarm,TY=5,Y=105;"
"M:Stopwatch   :  :,TY=5,Y=140;"
"M::   :,TY=5,X=116,Y=40;"
"M:=10,SO=0xc,FM=0x120,X=85,Y=40,W=50;"
"M:=11,SO=0xc,FM=0x120,X=131,Y=40,W=50;"
"M:=12,SO=0xc,FM=0x120,X=179,Y=40,W=50;"
"M::   :,TY=5,X=116,Y=70;"
"M:=16,SO=0xc,FM=0x120,X=85,Y=70,W=50;"
"M:=17,SO=0xc,FM=0x120,X=131,Y=70,W=50;"
"M:=18,SO=0xc,FM=0x120,X=179,Y=70,W=50;"
"M::   :,TY=5,X=116,Y=105;"
"M:=13,SO=0xc,FM=0x120,X=85,Y=105,W=50;"
"M:=14,SO=0xc,FM=0x120,X=131,Y=105,W=50;"
"M:=15,SO=0xc,FM=0x120,X=179,Y=105,W=50;"
"M:+=,TY=10,SO=0x86,X=278,Y=2,H=40,W=40;"
"M:-=,TY=10,SO=0x106,X=278,Y=45,H=40,W=40;"
"M:Set=,TY=10,SO=0x1006,X=258,Y=88,W=60,H=40;"
"M:Start=,TY=10,SO=0x6,X=5,Y=175,H=40,W=100;"
"M:Zero=,TY=10,SO=0x6,X=110,Y=175,H=40,W=100;"
"M:Exit=,TY=10,SO=0x46,X=215,Y=175,H=40,W=100;";

static const char MenuColorsRes [] =
"T:Colors;"
"M:Layout:=9,SO=0x80c,X=10,Y=40;"
"M:R:,SO=0x4,x=2,Y=60;"
"M:G:,SO=0x4,x=2,Y=85;"
"M:B:,SO=0x4,x=2,Y=110;"
"M:=22,TY=3,OO=0x1930,SO=0x800,X2=37,Y=60,H=16,W=115,CO=0x1F;"
"M:=23,TY=3,OO=0x1930,SO=0x800,X2=37,Y=85,H=16,W=115,CO=0x1F;"
"M:=24,TY=3,OO=0x1930,SO=0x800,X2=37,Y=110,H=16,W=115,CO=0x1F;"
"M:Speed=,TY=10,SO=0x6,X=5,Y=175,H=40,W=100;"
"M:+=,TY=10,SO=0x86,X=278,Y=5,H=40,W=40;"
"M:-=,TY=10,SO=0x106,X=278,Y=60,H=40,W=40;"
"M:Exit=,TY=10,SO=0x46,X=215,Y=175,H=40,W=100";

static const char MenuIMURes [] =
"T:IMU;"
"M: ACCX:,TY=5;"
"M: ACCY:,TY=5;"
"M: ACCZ:,TY=5;"
"M:GyroX:,TY=5;"
"M:GyroY:,TY=5;"
"M:GyroZ:,TY=5;"
"M:Motion:,TY=5;"
"M:=25,TY=2,OO=0x1350,X2=90,Y=35,H=16,W=220,CO=0x07e0;"
"M:=26,TY=2,OO=0x1350,X2=90,H=16,W=220,CO=0x07e0;"
"M:=27,TY=2,OO=0x1350,X2=90,H=16,W=220,CO=0x07e0;"
"M:=28,TY=2,OO=0x1350,X2=90,H=16,W=220,CO=0x07e0;"
"M:=29,TY=2,OO=0x1350,X2=90,H=16,W=220,CO=0x07e0;"
"M:=30,TY=2,OO=0x1350,X2=90,H=16,W=220,CO=0x07e0;"
"M:=31,TY=1,X2=110,CO=0xf980;"
"M:,TY=6,X=200,Y=32,X2=200,Y2=170,CO=0xffff;"
"M:0=,TY=5,X=197,Y=171,ZO=1;"
"M:Exit=,TY=10,SO=0x46,X=215,Y=175,H=40,W=100";

static const char MenuPasswordRes [] =
"T:Password;"
"M:Password1:=4,SO=0x0c,FM=0xb80;"
"M:Password2:=5,SO=0x40c,FM=0xb80;"
"M:,TY=8,R=0,Y=90,H=120,W=160,CO=0xfba0;" // rect
"M: =,TY=10,SO=0x6,X=10,Y=95,H=40,W=40;"   // SK2- SK5
"M: =,TY=10,SO=0x6,X=120,Y=95,H=40,W=40;"
"M: =,TY=10,SO=0x6,X=10,Y=165,H=40,W=40;"
"M: =,TY=10,SO=0x6,X=120,Y=165,H=40,W=40;"
"M:DEL=,TY=10,SO=0x6,X=258,Y=87,W=60,H=40;"
"M:Play=,TY=10,SO=0x1006,X=238,Y=131,W=80,H=40;"
"M:Exit=,TY=10,SO=0x46,X=215,Y=175,H=40,W=100;";

static const char MenuStatusRes [] =
"T:Status;"
"M:MenuStat:=3,TY=4,X2=150,FM=0xb80;"
"M:EEP ok=3,TY=1,FM=0x40,X2=150,BN=4,CO=0x07e0;"
"M:Exit=,TY=10,SO=0x46,X=225,Y=175,H=40,W=90";

static const char MenuSystemRes [] =
"T:System;"
"M:  Power down:=3,TY=1,SO=0x24,X2=180,BN=3,CO=0x001f;"
"M:    Password:=3,TY=1,SO=0x24,X2=180,BN=2,CO=0x001f;"
"M: Motion time:=32,SO=0x2c;"
"M:Motion sense:=33,SO=0x2c;"
"M:   Acc sense:=34,FM=0x30,SO=0x2c,TX= 2g| 4g| 8g|16g;"
"M:  Gyro sense:=35,FM=0x40,SO=0x2c,TX= 250| 500|1000|2000;"
"M:   max. Idle:=6,SO=0x2c,FM=0x50;"
"M:show PW keys:=3,TY=1,SO=0x24,X2=180,BN=5,CO=0x001f;"
"M:Sleep timer :=21,SO=0x2c,FM=0x50;"
"M:=1,TY=3,OO=0x2030,X2=290,Y=35,H=130,W=29,CO=0x001f;"   // scrollbar
"M:x 1=,TY=10,SO=0x206,X=5,Y=175,H=40,W=100;"
"M:+=,TY=10,SO=0x86,X=112,Y=175,H=40,W=50;"
"M:-=,TY=10,SO=0x106,X=169,Y=175,H=40,W=50;"
"M:Exit=,TY=10,SO=0x46,X=226,Y=175,H=40,W=90";

// Add your ressource strings here !!!

//----------------------------------------------------------------------------
// Menue callback function prototypes
//----------------------------------------------------------------------------
void CallBackMyMainMenue (void *pMH, tCBCallMode mode, uns8 SKey);
void CallBackService (void *pMH, tCBCallMode mode, uns8 SKey);
void CallBackColors (void *pMH, tCBCallMode mode, uns8 SKey);
void CallBackClock (void *pMH, tCBCallMode mode, uns8 SKey);
void CallBackPassword (void *pMH, tCBCallMode mode, uns8 SKey);
void CallBackSystem (void *pMH, tCBCallMode mode, uns8 SKey);

//----------------------------------------------------------------------------
// Menue-Resource-Lookuptable definition
//----------------------------------------------------------------------------
// Add your menue's callname, menu resource string and callback function here !!!
#define cMenuResTable \
{                                                         \
{ "PW",         MenuPWRes,        0                    }, \
{ "Warn",       MenuMsgBoxRes,    0                    }, \
{ "MainMenu",   MyMainMenuRes,    CallBackMyMainMenue  }, \
{ "Service",    MenuServiceRes,   CallBackService      }, \
{ "Clock",      MenuClockRes,     CallBackClock        }, \
{ "Colors",     MenuColorsRes,    CallBackColors       }, \
{ "IMU",        MenuIMURes,       0                    }, \
{ "Password",   MenuPasswordRes,  CallBackPassword     }, \
{ "Status",     MenuStatusRes,    0                    }, \
{ "System",     MenuSystemRes,    CallBackSystem       }, \
{ 0,            0,                0                    }  \
}

#endif
